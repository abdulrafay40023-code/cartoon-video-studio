// Content Script for https://chatgpt.com/* & https://chat.openai.com/* — Video Studio Auto Script Writer Bot (v3.6 Clean Button + Active Email Sync)
(function () {
  if (window.__vsChatGptBotV40Loaded) return;
  window.__vsChatGptBotV40Loaded = true;
  try {
    const existingOldPanel = document.getElementById('vsChatGptBotPanel');
    if (existingOldPanel) existingOldPanel.remove();
  } catch (e) {}

  const STUDIO_API_URL = 'https://cartoon-video-studio.vercel.app/api/tts';
  const PRECONNECTED_DEFAULT_EMAIL = 'abdulrafay40023@gmail.com';

  let isBusyWriting = false;
  let lastHandledJobId = '';
  let lastCompletedJobId = '';
  let lastCompletedScriptText = '';
  let isMinimized = false;

  const TAB_ID = (function () {
    try {
      let id = sessionStorage.getItem('vs_cgpt_tab_id');
      if (!id) {
        id = 'ctab_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
        sessionStorage.setItem('vs_cgpt_tab_id', id);
        sessionStorage.setItem('vs_cgpt_tab_created_at', String(Date.now()));
      }
      return id;
    } catch (e) {
      return 'ctab_' + Date.now();
    }
  })();
  const TAB_CREATED_AT = Number(sessionStorage.getItem('vs_cgpt_tab_created_at') || Date.now());

  function getTabEmail() {
    try {
      return String(sessionStorage.getItem('vs_cgpt_tab_email') || '').trim().toLowerCase();
    } catch (e) {
      return '';
    }
  }

  function setTabEmail(email, isManual = false) {
    const clean = String(email || '').trim().toLowerCase();
    try {
      if (clean) {
        sessionStorage.setItem('vs_cgpt_tab_email', clean);
        if (isManual) sessionStorage.setItem('vs_cgpt_tab_manual', '1');
      } else {
        sessionStorage.removeItem('vs_cgpt_tab_email');
      }
      heartbeatTabClaim(clean);
    } catch (e) {}
  }

  function readAllActiveTabClaims() {
    const now = Date.now();
    let map = {};
    try {
      const raw = localStorage.getItem('vs_cgpt_tab_claims_v3');
      if (raw) map = JSON.parse(raw) || {};
    } catch (e) {
      map = {};
    }
    const cleaned = {};
    for (const [tid, info] of Object.entries(map)) {
      if (info && typeof info === 'object' && now - Number(info.ts || 0) < 7500) {
        cleaned[tid] = info;
      }
    }
    return cleaned;
  }

  function heartbeatTabClaim(currentEmail) {
    try {
      const claims = readAllActiveTabClaims();
      const em = String(currentEmail !== undefined ? currentEmail : getTabEmail()).trim().toLowerCase();
      claims[TAB_ID] = {
        email: em,
        createdAt: TAB_CREATED_AT,
        manual: sessionStorage.getItem('vs_cgpt_tab_manual') === '1',
        ts: Date.now()
      };
      localStorage.setItem('vs_cgpt_tab_claims_v3', JSON.stringify(claims));
    } catch (e) {}
  }

  function resolveDistinctTabEmail(connectedEmailsList, boundEmail = '') {
    const cleanBound = String(boundEmail || '').trim().toLowerCase();
    const rawList = Array.isArray(connectedEmailsList)
      ? connectedEmailsList.map((e) => String(e || '').trim().toLowerCase()).filter((e) => e && e.includes('@'))
      : [];
    const validList = [];
    if (cleanBound && cleanBound.includes('@')) validList.push(cleanBound);
    for (let i = rawList.length - 1; i >= 0; i--) {
      if (!validList.includes(rawList[i])) validList.push(rawList[i]);
    }

    let myEmail = getTabEmail();
    const isMyManual = sessionStorage.getItem('vs_cgpt_tab_manual') === '1';
    if (!isMyManual && myEmail && validList.length > 0 && !validList.includes(myEmail)) {
      myEmail = '';
      setTabEmail('', false);
    }
    heartbeatTabClaim(myEmail);
    if (validList.length === 0) return myEmail;

    const claims = readAllActiveTabClaims();
    const claimedByOtherPriorityTabs = new Set();
    const claimedByAnyOtherTab = new Set();

    for (const [tid, info] of Object.entries(claims)) {
      if (tid === TAB_ID || !info || !info.email) continue;
      claimedByAnyOtherTab.add(info.email);
      const otherOlder = Number(info.createdAt || 0) < TAB_CREATED_AT || (Number(info.createdAt || 0) === TAB_CREATED_AT && tid < TAB_ID);
      if (info.manual || otherOlder) {
        claimedByOtherPriorityTabs.add(info.email);
      }
    }

    const completelyUnclaimed = validList.filter((em) => !claimedByAnyOtherTab.has(em) && em !== myEmail);
    if (!myEmail) {
      const firstFree = validList.find((em) => !claimedByAnyOtherTab.has(em)) || validList[0];
      if (firstFree) {
        setTabEmail(firstFree, false);
        return firstFree;
      }
    }
    if (!isMyManual && myEmail && claimedByOtherPriorityTabs.has(myEmail) && completelyUnclaimed.length > 0) {
      const nextDistinct = completelyUnclaimed[0];
      setTabEmail(nextDistinct, false);
      return nextDistinct;
    }
    return myEmail;
  }

  // Unthrottled sleep via MV3 background service worker (with safe elapsed-time fallback if extension wasn't reloaded yet)
  function sleep(ms) {
    return new Promise((resolve) => {
      const start = Date.now();
      let settled = false;
      const done = () => {
        if (!settled) {
          settled = true;
          resolve();
        }
      };
      try {
        chrome.runtime.sendMessage({ action: 'BG_SLEEP', ms }, (resp) => {
          const _err = chrome.runtime.lastError;
          const elapsed = Date.now() - start;
          if (resp && resp.ok && elapsed >= ms * 0.7) {
            done();
          } else {
            setTimeout(done, Math.max(0, ms - elapsed));
          }
        });
      } catch (e) {
        setTimeout(done, ms);
      }
      setTimeout(done, ms + 2500);
    });
  }

  let keepAliveAudioCtx = null;
  function ensureBackgroundKeepAliveActive() {
    try {
      if (!keepAliveAudioCtx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
          keepAliveAudioCtx = new AudioCtx();
          const osc = keepAliveAudioCtx.createOscillator();
          const gain = keepAliveAudioCtx.createGain();
          gain.gain.value = 0.00001;
          osc.connect(gain);
          gain.connect(keepAliveAudioCtx.destination);
          osc.start();
        }
      }
      if (keepAliveAudioCtx && keepAliveAudioCtx.state === 'suspended') {
        keepAliveAudioCtx.resume().catch(() => {});
      }
    } catch (e) {}
  }

  function createEl(tag, cssText, text) {
    const el = document.createElement(tag);
    if (cssText) el.style.cssText = cssText;
    if (text !== undefined && text !== null) el.textContent = text;
    return el;
  }

  async function directPostCloud(bodyObj) {
    try {
      const bgRes = await new Promise((resolve) => {
        let done = false;
        const timer = setTimeout(() => {
          if (!done) {
            done = true;
            resolve(null);
          }
        }, 7000);
        try {
          chrome.runtime.sendMessage({ action: 'CLOUD_API_POST', body: bodyObj }, (resp) => {
            const _err = chrome.runtime.lastError;
            if (!done) {
              done = true;
              clearTimeout(timer);
              resolve(resp && resp.ok && resp.data ? resp.data : null);
            }
          });
        } catch (e) {
          if (!done) {
            done = true;
            clearTimeout(timer);
            resolve(null);
          }
        }
      });
      if (bgRes) return bgRes;
    } catch (e) {}
    try {
      const resp = await fetch(STUDIO_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyObj)
      });
      if (!resp.ok) return null;
      return await resp.json();
    } catch (e) {
      return null;
    }
  }

  function isPromptOrMetaLine(text) {
    const t = String(text || '').trim();
    if (!t) return true;
    return (
      /^Write a complete, ultra-engaging/i.test(t) ||
      /^User's Chosen Topic Niche/i.test(t) ||
      /^Reference YouTube Channel/i.test(t) ||
      /^NO EXTERNAL REFERENCE CHANNEL/i.test(t) ||
      /^Target Length:\s*Approximately/i.test(t) ||
      /^Visual Style Context:/i.test(t) ||
      /^STRICT RULES:/i.test(t) ||
      /^\d+\.\s*(?:Output ONLY|Keep the subject|Start with a powerful|Every sentence must use)/i.test(t) ||
      /^=== LIVE YOUTUBE DATA API/i.test(t) ||
      /^Model the script's hook/i.test(t) ||
      /^ChatGPT can make mistakes/i.test(t) ||
      /^You said:?$/i.test(t) ||
      /^ChatGPT said:?$/i.test(t) ||
      /^Show more$/i.test(t) ||
      /^Show less$/i.test(t) ||
      /^Ask ChatGPT$/i.test(t) ||
      /^Instant$/i.test(t) ||
      /^Thinking$/i.test(t)
    );
  }

  function extractCleanParagraphsFromNode(node) {
    if (!node) return '';
    const pList = Array.from(node.querySelectorAll('p'))
      .map((p) => String(p.textContent || '').trim())
      .filter((t) => t.length > 0 && !isPromptOrMetaLine(t));
    if (pList.length > 0) {
      return pList.join('\n\n').trim();
    }
    const raw = String(node.innerText || node.textContent || '')
      .replace(/^ChatGPT said:\s*/i, '')
      .replace(/^You said:\s*/i, '')
      .trim();
    if (isPromptOrMetaLine(raw)) return '';
    return raw;
  }

  function extractScriptFromBodyInnerText() {
    try {
      const panel = document.getElementById('vsChatGptBotPanel');
      const prevDisplay = panel ? panel.style.display : '';
      if (panel) panel.style.display = 'none';
      const fullBodyText = String((document.querySelector('main') || document.body).innerText || '');
      if (panel) panel.style.display = prevDisplay;

      if (!fullBodyText || fullBodyText.length < 80) return '';

      let working = fullBodyText;

      // 1. Cut everything up to the end of our user prompt bubble
      const endOfPromptMarkers = [
        'ChatGPT said:',
        'Show more',
        'these viral YouTube videos!',
        'illustrations as a distinct scene.',
        'illustrated as a distinct scene.',
        'relatable everyday examples.'
      ];
      for (const marker of endOfPromptMarkers) {
        const idx = working.lastIndexOf(marker);
        if (idx !== -1) {
          working = working.slice(idx + marker.length);
          break;
        }
      }

      // 2. Cut footer / composer text at the bottom (never cut mid-script if floating "Ask ChatGPT" selection tooltip appears!)
      const footerMarkers = [
        '\nChatGPT can make mistakes',
        '\nVideo Studio — ChatGPT Script Bot'
      ];
      for (const fMarker of footerMarkers) {
        const fIdx = working.lastIndexOf(fMarker);
        if (fIdx !== -1) {
          working = working.slice(0, fIdx);
        }
      }
      const askIdx = working.lastIndexOf('\nAsk ChatGPT');
      if (askIdx !== -1 && askIdx > working.length - 160) {
        working = working.slice(0, askIdx);
      }

      const sidebarNoise = new Set([
        'new chat', 'search chats', 'library', 'plugins', 'explore', 'projects',
        'recents', 'scheduled', 'instant', 'plus', 'pro', 'show more', 'show less',
        'copy', 'edit', 'read aloud', 'good response', 'bad response'
      ]);

      const cleanLines = working
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => {
          if (!l || l.length < 3) return false;
          if (sidebarNoise.has(l.toLowerCase())) return false;
          if (isPromptOrMetaLine(l)) return false;
          return true;
        });

      const joined = cleanLines.join('\n\n').trim();
      return joined.length > 60 ? joined : '';
    } catch (e) {
      return '';
    }
  }

  function extractLatestAssistantTextOnPage(strictOnlyAfterLatestUser = false, preExistingSet = null) {
    // Layer 0: Strict Turn-Order Check (ONLY extract assistant turns that appear AFTER the LAST user prompt turn!)
    const roleNodes = Array.from(document.querySelectorAll('[data-message-author-role="user"], [data-message-author-role="assistant"]'));
    if (roleNodes.length > 0) {
      let lastUserIdx = -1;
      for (let i = roleNodes.length - 1; i >= 0; i--) {
        if (roleNodes[i].getAttribute('data-message-author-role') === 'user') {
          lastUserIdx = i;
          break;
        }
      }
      if (strictOnlyAfterLatestUser && lastUserIdx === -1) {
        return '';
      }
      if (lastUserIdx !== -1) {
        for (let i = roleNodes.length - 1; i > lastUserIdx; i--) {
          const el = roleNodes[i];
          if (el.getAttribute('data-message-author-role') !== 'assistant') continue;
          if (preExistingSet && preExistingSet.has(el)) continue;
          const mdNode = el.querySelector('.markdown') || el;
          const txt = extractCleanParagraphsFromNode(mdNode);
          if (txt.length > 60 && !isPromptOrMetaLine(txt)) {
            return txt;
          }
        }
        // If a user prompt turn exists at the bottom and ChatGPT hasn't added a new assistant turn below it yet, return empty!
        if (strictOnlyAfterLatestUser) {
          return '';
        }
      }
    }

    // Layer 1: Check explicit assistant & conversation-turn containers (div, article, section)
    const turnSelectors = [
      '[data-testid^="conversation-turn-"] [data-message-author-role="assistant"] .markdown',
      '[data-testid^="conversation-turn-"] [data-message-author-role="assistant"]',
      '[data-message-author-role="assistant"] .markdown',
      '[data-message-author-role="assistant"]',
      'div.agent-turn .markdown',
      '.markdown.prose',
      '.markdown',
      '[data-testid^="conversation-turn-"]',
      'article'
    ];
    for (const sel of turnSelectors) {
      const els = Array.from(document.querySelectorAll(sel));
      if (els.length > 0) {
        for (let i = els.length - 1; i >= 0; i--) {
          const el = els[i];
          if (preExistingSet && preExistingSet.has(el)) continue;
          if (el.id === 'vsChatGptBotPanel' || el.closest('#vsChatGptBotPanel')) continue;
          if (el.getAttribute('data-message-author-role') === 'user') continue;
          if (el.querySelector('[data-message-author-role="user"]') && !el.querySelector('[data-message-author-role="assistant"], .markdown')) {
            continue;
          }
          const txt = extractCleanParagraphsFromNode(el);
          if (txt.length > 60 && !isPromptOrMetaLine(txt)) {
            return txt;
          }
        }
      }
    }

    // Layer 2: Universal paragraph (<p>) scanner across document.body
    const root = document.querySelector('main') || document.body;
    if (root) {
      const allPs = Array.from(root.querySelectorAll('p'));
      let lastPromptIdx = -1;
      for (let i = 0; i < allPs.length; i++) {
        const p = allPs[i];
        const t = String(p.textContent || '').trim();
        if (
          p.closest('[data-message-author-role="user"]') ||
          /^Write a complete, ultra-engaging/i.test(t) ||
          /^STRICT RULES:/i.test(t) ||
          /^=== LIVE YOUTUBE DATA API/i.test(t) ||
          /relatable everyday examples\./i.test(t)
        ) {
          lastPromptIdx = i;
        }
      }

      if (strictOnlyAfterLatestUser && lastPromptIdx === -1) {
        return '';
      }

      const scriptParagraphs = [];
      for (let i = lastPromptIdx + 1; i < allPs.length; i++) {
        const p = allPs[i];
        if (preExistingSet && preExistingSet.has(p)) continue;
        if (
          p.closest('#vsChatGptBotPanel') ||
          p.closest('nav') ||
          p.closest('aside') ||
          p.closest('form') ||
          p.closest('#prompt-textarea') ||
          p.closest('[data-message-author-role="user"]')
        ) {
          continue;
        }
        const t = String(p.textContent || '').trim();
        if (!t || isPromptOrMetaLine(t)) continue;
        scriptParagraphs.push(t);
      }

      if (scriptParagraphs.length > 0) {
        const joinedPs = scriptParagraphs.join('\n\n').trim();
        if (joinedPs.length > 60) return joinedPs;
      }
    }

    if (strictOnlyAfterLatestUser) {
      return '';
    }

    // Layer 3: Direct visible text extraction from document.body.innerText (manual button fallback only)
    return extractScriptFromBodyInnerText();
  }

  async function pushCurrentChatGptScriptToStudio(manualClick = false) {
    const scriptTxt = extractLatestAssistantTextOnPage();
    if (!scriptTxt || scriptTxt.length < 60) {
      if (manualClick) setStatus('⚠️ Is page par abhi koi complete ChatGPT script nahi mili!');
      return false;
    }
    const stored = await chrome.storage.local.get(['studioUserEmail']);
    const email = getTabEmail() || stored.studioUserEmail || '';
    const wordCount = scriptTxt.split(/\s+/).filter(Boolean).length;
    setStatus(`✅ Script Sent (${wordCount} words) to Video Studio!`);
    if (email) {
      await directPostCloud({
        action: 'chatgpt_queue_complete',
        email,
        status: 'completed',
        script_text: scriptTxt,
        statusText: `✅ ChatGPT Script Ready (${wordCount} words)!`
      });
    }
    try {
      chrome.runtime.sendMessage({
        action: 'CHATGPT_SCRIPT_COMPLETED',
        job_id: lastHandledJobId || ('cgpt_' + Date.now()),
        topic: '',
        script_text: scriptTxt
      });
    } catch (e) {}
    return true;
  }

  function ensureChatGptBotUI() {
    let box = document.getElementById('vsChatGptBotPanel');
    if (box) return box;
    if (!document.body) return null;

    box = createEl(
      'div',
      [
        'position:fixed',
        'top:14px',
        'right:16px',
        'z-index:2147483647',
        'width:340px',
        'background:linear-gradient(145deg, #0b1120, #111827)',
        'border:2px solid #10b981',
        'border-radius:14px',
        'padding:11px 13px',
        'color:#f8fafc',
        'font-family:system-ui,-apple-system,sans-serif',
        'box-shadow:0 16px 40px rgba(0,0,0,0.75)',
        'display:block'
      ].join(';')
    );
    box.id = 'vsChatGptBotPanel';

    const headerRow = createEl('div', 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px;');
    const titleWrap = createEl('div', 'font-size:12.5px;font-weight:900;color:#34d399;display:flex;align-items:center;gap:6px;');
    titleWrap.appendChild(createEl('span', '', '✍️'));
    titleWrap.appendChild(createEl('span', '', 'Video Studio — ChatGPT Script Bot'));

    const minBtn = createEl(
      'button',
      'background:rgba(148,163,184,0.15);border:1px solid #475569;color:#cbd5e1;font-size:11px;font-weight:900;padding:1px 6px;border-radius:6px;cursor:pointer;',
      '—'
    );
    headerRow.appendChild(titleWrap);
    headerRow.appendChild(minBtn);
    box.appendChild(headerRow);

    const bodyWrap = createEl('div', 'display:block;');
    bodyWrap.id = 'vsChatGptBodyWrap';

    const emailCard = createEl('div', 'background:#050811;border:1px solid #1e293b;border-radius:9px;padding:7px 9px;margin-bottom:7px;');
    const emailLabelRow = createEl('div', 'font-size:10.5px;font-weight:800;color:#94a3b8;margin-bottom:4px;display:flex;align-items:center;justify-content:space-between;');
    emailLabelRow.appendChild(createEl('span', '', '👤 STUDIO GMAIL:'));
    const emailBadge = createEl('span', 'color:#34d399;font-weight:900;', '');
    emailBadge.id = 'vsChatGptEmailBadge';
    emailLabelRow.appendChild(emailBadge);

    const emailInputRow = createEl('div', 'display:flex;gap:5px;');
    const emailInput = createEl(
      'input',
      'flex:1;background:#0f172a;border:1px solid #334155;border-radius:6px;padding:5px 8px;color:#fff;font-size:11.5px;outline:none;'
    );
    emailInput.id = 'vsChatGptEmailInput';
    emailInput.type = 'email';
    emailInput.placeholder = 'Auto-Captured from Video Studio Tool...';

    const saveBtn = createEl(
      'button',
      'padding:5px 9px;border-radius:6px;border:none;background:#10b981;color:#fff;font-size:11px;font-weight:800;cursor:pointer;',
      'Connect'
    );
    const disconnectBtn = createEl(
      'button',
      'padding:5px 8px;border-radius:6px;border:1px solid rgba(239,68,68,0.6);background:rgba(239,68,68,0.2);color:#fca5a5;font-size:11px;font-weight:900;cursor:pointer;',
      '✖'
    );
    disconnectBtn.title = 'Remove / Disconnect current Gmail & enter another Gmail';
    emailInput.addEventListener('input', () => {
      emailInput.dataset.userEditing = '1';
    });
    emailInputRow.appendChild(emailInput);
    emailInputRow.appendChild(saveBtn);
    emailInputRow.appendChild(disconnectBtn);
    emailCard.appendChild(emailLabelRow);
    emailCard.appendChild(emailInputRow);
    bodyWrap.appendChild(emailCard);

    const actionsRow = createEl('div', 'display:flex;gap:5px;margin-bottom:7px;');
    const sendNowBtn = createEl(
      'button',
      'flex:1;padding:6px 8px;border-radius:7px;border:1px solid rgba(56,189,248,0.5);background:rgba(56,189,248,0.16);color:#7dd3fc;font-size:11px;font-weight:800;cursor:pointer;',
      '📤 Send Script to Studio'
    );
    sendNowBtn.onclick = () => pushCurrentChatGptScriptToStudio(true);

    const cleanBtn = createEl(
      'button',
      'padding:6px 10px;border-radius:7px;border:1px solid rgba(16,185,129,0.5);background:rgba(16,185,129,0.16);color:#6ee7b7;font-size:11px;font-weight:800;cursor:pointer;',
      '🧹 Clean'
    );
    cleanBtn.onclick = () => cleanResetChatGptBotState(true);

    actionsRow.appendChild(sendNowBtn);
    actionsRow.appendChild(cleanBtn);
    bodyWrap.appendChild(actionsRow);

    const statusEl = createEl(
      'div',
      'font-size:11.5px;color:#cbd5e1;line-height:1.4;',
      '🟢 Ready! Video Studio mein Topic select karein — ChatGPT khud script likh kar Studio bhej dega!'
    );
    statusEl.id = 'vsChatGptStatusText';
    bodyWrap.appendChild(statusEl);

    box.appendChild(bodyWrap);
    document.body.appendChild(box);

    const initialTabEmail = getTabEmail() || (PRECONNECTED_DEFAULT_EMAIL && PRECONNECTED_DEFAULT_EMAIL.includes('@') ? PRECONNECTED_DEFAULT_EMAIL.trim().toLowerCase() : '');
    if (initialTabEmail) {
      setTabEmail(initialTabEmail, false);
      emailInput.value = initialTabEmail;
      emailBadge.textContent = '● Connected';
      statusEl.textContent = `🟢 Connected (${initialTabEmail}) — Listening for viral topic script jobs from Video Studio...`;
    } else {
      emailBadge.textContent = '⚪ Waiting';
      statusEl.textContent = '⚪ Video Studio mein "🔌 Connect" dabayein (ya upar apni Studio Gmail likh kar Connect dabayein)!';
      try {
        chrome.storage.local.get(['studioUserEmail'], (st) => {
          const _err = chrome.runtime.lastError;
          if (st && st.studioUserEmail && st.studioUserEmail.includes('@')) {
            applyAutoCapturedChatGptEmailUI(st.studioUserEmail);
          }
        });
      } catch (e) {}
    }
    setTimeout(pollChatGptJobOnce, 300);

    minBtn.onclick = () => {
      isMinimized = !isMinimized;
      bodyWrap.style.display = isMinimized ? 'none' : 'block';
      minBtn.textContent = isMinimized ? '+' : '—';
    };

    const disconnectEmailHandler = async () => {
      try {
        sessionStorage.setItem('vs_cgpt_manual_disconnected', '1');
        sessionStorage.removeItem('vs_cgpt_tab_email');
        sessionStorage.removeItem('vs_cgpt_tab_manual');
        localStorage.removeItem('vs_cgpt_tab_claims_v3');
      } catch (e) {}
      try {
        await chrome.storage.local.remove(['studioUserEmail']);
      } catch (e) {}
      emailInput.value = '';
      emailInput.dataset.userEditing = '1';
      emailBadge.textContent = '⚪ Disconnected';
      emailBadge.style.color = '#fca5a5';
      statusEl.textContent = '⚪ Purani Gmail hata di gayi! Ab upar nayi Gmail likh kar Connect dabayein.';
      directPostCloud({ action: 'unbind_pc_email' }).catch(() => {});
      try { emailInput.focus(); } catch (e) {}
    };

    disconnectBtn.onclick = disconnectEmailHandler;

    saveBtn.onclick = async () => {
      const em = String(emailInput.value || '').trim().toLowerCase();
      if (!em || !em.includes('@')) {
        await disconnectEmailHandler();
        return;
      }
      try {
        sessionStorage.removeItem('vs_cgpt_manual_disconnected');
      } catch (e) {}
      delete emailInput.dataset.userEditing;
      setTabEmail(em, true);
      try {
        await chrome.storage.local.set({ studioUserEmail: em });
      } catch (e) {}
      emailBadge.textContent = '● Connected';
      emailBadge.style.color = '#34d399';
      statusEl.textContent = `🟢 Connected (${em}) — Ready to auto-write scripts!`;
      await directPostCloud({ action: 'bind_pc_email', email: em });
      pollChatGptJobOnce();
    };

    return box;
  }

  async function cleanResetChatGptBotState(showToast = true) {
    isBusyWriting = false;
    lastHandledJobId = 'cleaned_' + Date.now();
    try {
      const stopBtn = document.querySelector('button[data-testid="stop-button"], button[aria-label*="Stop streaming"], button[aria-label*="Stop generating"]');
      if (stopBtn && stopBtn.offsetParent !== null) stopBtn.click();
    } catch (e) {}
    const email = getTabEmail();
    if (email) {
      directPostCloud({ action: 'chatgpt_queue_stop', email, clean: true });
    }
    await pollChatGptJobOnce();
    const curEm = getTabEmail();
    if (showToast) {
      setStatus(curEm ? `✨ Cleaned & Reset! Connected (${curEm}) — Ready for new script job.` : '✨ Cleaned & Reset! Ready for new script job.');
    }
  }

  function setStatus(txt) {
    ensureChatGptBotUI();
    const el = document.getElementById('vsChatGptStatusText');
    if (el) el.textContent = txt;
  }

  function findChatGptEditor() {
    const selectors = [
      '#prompt-textarea',
      'div#prompt-textarea[contenteditable="true"]',
      'textarea[data-id="root"]',
      'div[contenteditable="true"][translate="no"]',
      'main div[contenteditable="true"]',
      'main textarea'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && (el.offsetParent !== null || document.hidden)) return el;
    }
    return null;
  }

  function triggerRealClick(el) {
    if (!el) return;
    try { el.focus(); } catch (e) {}
    const opts = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, buttons: 1 };
    try { el.dispatchEvent(new PointerEvent('pointerdown', opts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerup', opts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('click', opts)); } catch (e) {}
    try { el.click(); } catch (e) {}
  }

  function findChatGptSendButton(editorEl = null) {
    // 1. Check all explicit Send / Submit button selectors across ChatGPT Chat & Work modes
    const selectors = [
      '#composer-submit-button',
      'button[data-testid="send-button"]',
      'button[data-testid="composer-send-button"]',
      'button[data-testid*="send-button"]',
      'button[data-testid*="send"]',
      'button[data-testid*="submit"]',
      'button[aria-label="Send"]',
      'button[aria-label*="Send prompt"]',
      'button[aria-label*="Send message"]',
      'button[aria-label*="Send"]',
      'button[aria-label*="Submit"]',
      'form button[type="submit"]',
      'main button[type="submit"]'
    ];
    for (const sel of selectors) {
      const btns = Array.from(document.querySelectorAll(sel));
      for (const b of btns) {
        if (!b || b.closest('#vsChatGptBotPanel')) continue;
        const lbl = String((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || '')).toLowerCase();
        if (/stop|voice|dictate|microphone|attach|add|search|reason|project|file|plugin|desktop/i.test(lbl)) continue;
        if ((b.offsetParent !== null || document.hidden) && !b.disabled) return b;
      }
    }

    // 2. Geometric Composer Scan (handles ChatGPT "Work" mode & GPT-5.1 Terra blue up-arrow button!)
    const ed = editorEl || findChatGptEditor();
    if (ed) {
      let cur = ed.parentElement;
      for (let depth = 0; depth < 8 && cur && cur !== document.body; depth++) {
        const btns = Array.from(cur.querySelectorAll('button')).filter((b) => {
          if (!b || b.disabled || b.closest('#vsChatGptBotPanel')) return false;
          const lbl = String(
            (b.getAttribute('aria-label') || '') + ' ' +
            (b.getAttribute('data-testid') || '') + ' ' +
            (b.getAttribute('title') || '') + ' ' +
            (b.textContent || '')
          ).trim().toLowerCase();
          if (/plus|attach|upload|add|search|reason|think|voice|dictate|microphone|audio|speech|model|terra|medium|instant|choose project|files|plugins|open desktop|stop/i.test(lbl)) {
            return false;
          }
          // Send button in ChatGPT composer is an icon button (empty textContent) with an <svg>
          if (lbl.length > 18 && !/send|submit/i.test(lbl)) return false;
          return Boolean(b.querySelector('svg'));
        });
        if (btns.length > 0) {
          // Pick the rightmost bottom button inside the composer container (the blue ↑ circle button)
          btns.sort((a, b) => {
            const ra = a.getBoundingClientRect();
            const rb = b.getBoundingClientRect();
            return (rb.right + rb.bottom * 0.5) - (ra.right + ra.bottom * 0.5);
          });
          return btns[0];
        }
        cur = cur.parentElement;
      }
    }
    return null;
  }

  function isChatGptGenerating() {
    const stopSelectors = [
      'button[data-testid="stop-button"]',
      'button[data-testid="composer-stop-button"]',
      'button[aria-label*="Stop streaming"]',
      'button[aria-label*="Stop generating"]',
      'button[aria-label*="Stop response"]',
      'button[aria-label="Stop"]',
      '.result-streaming',
      '[data-testid*="streaming"]'
    ];
    for (const sel of stopSelectors) {
      const el = document.querySelector(sel);
      if (el && (el.offsetParent !== null || document.hidden)) return true;
    }
    return false;
  }

  function getEditorTextLength(editor) {
    if (!editor) return 0;
    const raw = editor.tagName === 'TEXTAREA' ? editor.value : (editor.innerText || editor.textContent || '');
    return String(raw || '').trim().length;
  }

  async function typeAndSendInChatGpt(promptText) {
    // If ChatGPT is on the "Work" tab instead of "Chat", switch to "Chat" or send directly in "Work"
    const editor = findChatGptEditor();
    if (!editor) return false;
    try { editor.focus(); } catch (e) {}
    await sleep(150);

    if (editor.tagName === 'TEXTAREA') {
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
      if (nativeSetter) nativeSetter.call(editor, promptText);
      else editor.value = promptText;
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      try {
        editor.focus();
        const sel = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(editor);
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('delete', false, null);
      } catch (e) {}

      let inserted = false;
      try {
        inserted = document.execCommand('insertText', false, promptText);
      } catch (e) {}

      if (!inserted || getEditorTextLength(editor) < 20) {
        try {
          const dt = new DataTransfer();
          dt.setData('text/plain', promptText);
          const pasteEv = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
          editor.dispatchEvent(pasteEv);
        } catch (e) {}
      }

      if (getEditorTextLength(editor) < 20) {
        editor.innerHTML = `<p>${promptText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>`;
        editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: promptText }));
      }
    }

    await sleep(500);

    // Click the Send button (and fallback to Enter / form.requestSubmit) until the composer empties or starts generating!
    for (let attempt = 0; attempt < 12; attempt++) {
      if (isChatGptGenerating() || getEditorTextLength(editor) < 40) {
        return true;
      }
      const sendBtn = findChatGptSendButton(editor);
      if (sendBtn) {
        triggerRealClick(sendBtn);
      }
      await sleep(350);
      if (isChatGptGenerating() || getEditorTextLength(editor) < 40) {
        return true;
      }
      // Also try form requestSubmit and Enter keydown on ProseMirror editor
      try {
        const frm = editor.closest('form');
        if (frm && typeof frm.requestSubmit === 'function') frm.requestSubmit();
      } catch (e) {}
      try {
        editor.focus();
        editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, shiftKey: false, ctrlKey: false, metaKey: false, bubbles: true, cancelable: true }));
        editor.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, shiftKey: false, bubbles: true, cancelable: true }));
        editor.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, shiftKey: false, bubbles: true, cancelable: true }));
      } catch (e) {}
      await sleep(450);
    }

    return true;
  }

  async function executeChatGptScriptJob(job) {
    const promptToSend = (job && (job.chatgpt_prompt || job.prompt) || '').trim();
    if (isBusyWriting || !job || !promptToSend) return;
    if (job.job_id && job.job_id === lastHandledJobId) return;
    isBusyWriting = true;
    lastHandledJobId = job.job_id || ('cgpt_' + Date.now());
    ensureBackgroundKeepAliveActive();
    try {
      chrome.runtime.sendMessage({ action: 'ACTIVATE_SENDER_TAB' }, () => {
        const _err = chrome.runtime.lastError;
      });
    } catch (e) {}

    try {
      const stored = await chrome.storage.local.get(['studioUserEmail']);
      const email = job.email || getTabEmail() || stored.studioUserEmail || '';
      const topicShort = (job.topic || 'Selected Topic').substring(0, 48);
      setStatus(`✍️ Writing viral script in ChatGPT for: "${topicShort}..."`);

      if (email) {
        directPostCloud({
          action: 'chatgpt_queue_complete',
          job_id: lastHandledJobId,
          email,
          status: 'running',
          script_text: '',
          statusText: `✍️ ChatGPT is now Writing the full script for "${topicShort}"...`
        });
      }

      const preExistingSet = new WeakSet(
        Array.from(document.querySelectorAll('[data-message-author-role="assistant"], [data-testid^="conversation-turn-"], .markdown, article, main p'))
      );
      const beforeText = extractLatestAssistantTextOnPage(false);
      const sent = await typeAndSendInChatGpt(promptToSend);
      if (!sent) {
        isBusyWriting = false;
        return;
      }

      await sleep(1800);
      const startWait = Date.now();
      let finalScript = '';
      let lastSeenText = '';
      let stableTicks = 0;
      let lastCloudSyncAt = 0;
      const targetMinWords = Math.max(450, Math.round((Number(job.duration_mins) || 10) * 115));

      while (Date.now() - startWait < 240000) {
        const curText = extractLatestAssistantTextOnPage(true, preExistingSet);
        const isNewReply = Boolean(
          curText &&
          curText !== beforeText &&
          (!beforeText || curText.slice(0, 120) !== beforeText.slice(0, 120)) &&
          curText.length > 60
        );

        if (isNewReply) {
          const wordCount = curText.split(/\s+/).filter(Boolean).length;
          setStatus(`✍️ Writing in ChatGPT (${wordCount} words written)...`);

          if (email && Date.now() - lastCloudSyncAt > 2500) {
            lastCloudSyncAt = Date.now();
            directPostCloud({
              action: 'chatgpt_queue_complete',
              job_id: lastHandledJobId,
              email,
              status: 'running',
              script_text: curText,
              statusText: `✍️ ChatGPT Writing Script (${wordCount} words written so far)...`
            });
          }

          if (curText === lastSeenText) {
            stableTicks++;
          } else {
            lastSeenText = curText;
            stableTicks = 0;
          }

          const generatingNow = isChatGptGenerating();
          const endsWithSentencePunct = /[.!?"'”’)\]]\s*$/.test(curText.trim());
          if (!generatingNow) {
            if (
              (wordCount >= targetMinWords && endsWithSentencePunct && stableTicks >= 6) ||
              (endsWithSentencePunct && curText.length > 400 && stableTicks >= 12) ||
              (curText.length > 400 && stableTicks >= 20)
            ) {
              finalScript = curText;
              break;
            }
          } else if (curText.length > 400 && endsWithSentencePunct && stableTicks >= 30) {
            finalScript = curText;
            break;
          }
        }
        await sleep(900);
      }

      // Final 1.5s settle check to guarantee the very last paragraph/sentence is 100% captured
      await sleep(1500);
      const finalCheckText = extractLatestAssistantTextOnPage(true, preExistingSet);
      if (finalCheckText && finalCheckText !== beforeText && finalCheckText.length >= (finalScript || lastSeenText).length) {
        finalScript = finalCheckText;
      } else if (!finalScript && lastSeenText && lastSeenText.length > 100) {
        finalScript = lastSeenText;
      }

      if (finalScript && finalScript.length > 60) {
        const totalWords = finalScript.split(/\s+/).filter(Boolean).length;
        lastCompletedJobId = lastHandledJobId;
        lastCompletedScriptText = finalScript;
        setStatus(`✅ Script Completed (${totalWords} words)! Sent to Video Studio!`);
        if (email) {
          const completePayload = {
            action: 'chatgpt_queue_complete',
            job_id: lastHandledJobId,
            email,
            status: 'completed',
            script_text: finalScript,
            statusText: `✅ ChatGPT Script Ready (${totalWords} words)!`
          };
          await directPostCloud(completePayload);
          setTimeout(() => { directPostCloud(completePayload).catch(() => {}); }, 600);
        }
        try {
          chrome.runtime.sendMessage({
            action: 'CHATGPT_SCRIPT_COMPLETED',
            job_id: lastHandledJobId,
            topic: job.topic || '',
            script_text: finalScript
          });
        } catch (e) {}
      }
    } finally {
      isBusyWriting = false;
    }
  }

  function applyAutoCapturedChatGptEmailUI(capturedEmail, forceFromStudio = false) {
    const clean = String(capturedEmail || '').trim().toLowerCase();
    if (!clean || !clean.includes('@')) return;
    if (!forceFromStudio && sessionStorage.getItem('vs_cgpt_manual_disconnected') === '1') {
      return;
    }
    if (forceFromStudio) {
      try { sessionStorage.removeItem('vs_cgpt_manual_disconnected'); } catch (e) {}
    }
    setTabEmail(clean, false);
    const inp = document.getElementById('vsChatGptEmailInput');
    const bdg = document.getElementById('vsChatGptEmailBadge');
    const st = document.getElementById('vsChatGptStatusText');
    const isUserTyping = inp && (document.activeElement === inp || inp.dataset.userEditing === '1');
    if (inp && (!isUserTyping || forceFromStudio) && inp.value !== clean) {
      inp.value = clean;
      if (forceFromStudio) delete inp.dataset.userEditing;
    }
    if (bdg && (!isUserTyping || forceFromStudio)) {
      bdg.textContent = '● Connected';
      bdg.style.color = '#34d399';
    }
    if (st && !isBusyWriting && (!isUserTyping || forceFromStudio)) {
      st.textContent = `🟢 Connected (${clean}) — Listening for viral topic script jobs from Video Studio...`;
    }
  }

  async function pollChatGptJobOnce() {
    ensureChatGptBotUI();
    if (isBusyWriting) return;
    if (sessionStorage.getItem('vs_cgpt_manual_disconnected') === '1') return;
    try {
      let email = getTabEmail();
      if (!email) {
        try {
          const stEm = await chrome.storage.local.get(['studioUserEmail']);
          if (stEm && stEm.studioUserEmail && String(stEm.studioUserEmail).includes('@')) {
            email = String(stEm.studioUserEmail).trim().toLowerCase();
            applyAutoCapturedChatGptEmailUI(email);
          }
        } catch (e) {}
      }
      heartbeatTabClaim(email);

      const res = await directPostCloud({ action: 'chatgpt_queue_poll', email, from_extension: true });
      const serverBoundEmail = (res && res.bound_email && res.bound_email.includes('@')) ? String(res.bound_email).trim().toLowerCase() : '';
      if (!email) {
        if (res && Array.isArray(res.connected_emails) && res.connected_emails.length > 0) {
          const distinctEmail = resolveDistinctTabEmail(res.connected_emails, serverBoundEmail);
          if (distinctEmail) {
            email = distinctEmail;
            applyAutoCapturedChatGptEmailUI(email);
            const res2 = await directPostCloud({ action: 'chatgpt_queue_poll', email, from_extension: true });
            if (res2) Object.assign(res, res2);
          }
        } else if (serverBoundEmail) {
          const distinctEmail = resolveDistinctTabEmail([serverBoundEmail], serverBoundEmail);
          if (distinctEmail) {
            email = distinctEmail;
            applyAutoCapturedChatGptEmailUI(email);
          }
        }
      } else {
        applyAutoCapturedChatGptEmailUI(email);
      }
      if (!email) return;

      const job = res && res.job ? res.job : null;
      if (job && job.email && String(job.email).trim().toLowerCase() !== email) {
        return;
      }
      if (job && job.active && job.status === 'queued' && (job.chatgpt_prompt || job.prompt) && job.job_id !== lastHandledJobId) {
        executeChatGptScriptJob(job);
      } else if (job && job.job_id && job.job_id === lastCompletedJobId && lastCompletedScriptText && job.status !== 'completed') {
        const totalWords = lastCompletedScriptText.split(/\s+/).filter(Boolean).length;
        await directPostCloud({
          action: 'chatgpt_queue_complete',
          job_id: lastCompletedJobId,
          email,
          status: 'completed',
          script_text: lastCompletedScriptText,
          statusText: `✅ ChatGPT Script Ready (${totalWords} words)!`
        });
      }
    } catch (e) {}
  }

  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req && req.action === 'BG_HEARTBEAT_TICK') {
      ensureBackgroundKeepAliveActive();
      if (!isBusyWriting) {
        pollChatGptJobOnce();
      }
      sendResponse({ ok: true });
      return true;
    }
    if (req && req.action === 'START_CHATGPT_SCRIPT_JOB' && req.job) {
      executeChatGptScriptJob(req.job);
      sendResponse({ ok: true });
      return true;
    }
    if (req && req.action === 'CLEAN_RESET_BOT_UI') {
      cleanResetChatGptBotState(false);
      sendResponse({ ok: true });
      return true;
    }
    if (req && req.action === 'SYNC_EMAIL_FROM_STUDIO' && req.email) {
      applyAutoCapturedChatGptEmailUI(req.email, true);
      pollChatGptJobOnce();
      sendResponse({ ok: true });
      return true;
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureChatGptBotUI);
  } else {
    ensureChatGptBotUI();
  }
  setInterval(ensureChatGptBotUI, 1500);
  setInterval(pollChatGptJobOnce, 2500);
})();
