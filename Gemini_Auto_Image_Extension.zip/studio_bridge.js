// Content script injected into Video Studio (cartoon-video-studio.vercel.app)
(function () {
  const DELETED_OFFICE2_SCENES = [110, 135, 137, 138, 139];
  const PURGE_FLAG_KEY = 'vs_purged_office2_110_135_137_138_v7';

  function parseAllPromptsFromStudioDom() {
    try {
      let raw = '';
      const box = document.getElementById('generatedPromptsBox');
      if (box && box.value && box.value.trim()) {
        raw = box.value.trim();
      }
      if (!raw) {
        // Fallback: check localStorage draft keys
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.includes('draft')) {
            try {
              const obj = JSON.parse(localStorage.getItem(k) || '{}');
              if (obj && obj.promptsText && String(obj.promptsText).includes('Image 1')) {
                raw = String(obj.promptsText).trim();
                break;
              }
            } catch (e) {}
          }
        }
      }
      if (!raw) return [];
      const blocks = raw
        .split(/\n*(?=(?:^|\n)Image\s+\d+\b)/i)
        .map((b) => b.trim())
        .filter(Boolean);
      const list = [];
      for (let i = 0; i < blocks.length; i++) {
        const b = blocks[i];
        const numMatch = b.match(/^Image\s+(\d+)\b/i);
        const scMatch = b.match(/Script:\s*(.+?)(?:\n+\s*Prompt:|$)/is);
        const prMatch = b.match(/Prompt:\s*([\s\S]+)$/i);
        const sceneNum = numMatch && numMatch[1] ? parseInt(numMatch[1], 10) : i + 1;
        const scriptText = scMatch && scMatch[1] ? scMatch[1].replace(/\s+/g, ' ').trim() : '';
        const promptText = prMatch && prMatch[1] ? prMatch[1].replace(/\s+/g, ' ').trim() : b;
        const hasCharPrompt = /\*\*CHARACTER CONSISTENCY PROMPT/i.test(b);
        const isWorldScene = /without main character/i.test(b) || (!hasCharPrompt && /\*\*Style:\*\*/i.test(b));
        const fullBlockText = b.replace(/^Image\s+\d+\s*/i, '').trim();
        if (promptText) {
          list.push({
            sceneNum,
            scriptText,
            promptText,
            fullBlockText,
            hasCharPrompt,
            isWorldScene
          });
        }
      }
      return list.sort((a, b) => (Number(a.sceneNum) || 0) - (Number(b.sceneNum) || 0));
    } catch (e) {
      return [];
    }
  }

  function purgeDeletedOffice2ScenesInStudioStorageOnce() {
    try {
      if (localStorage.getItem(PURGE_FLAG_KEY) === '1') return;
      const toRemove = new Set(DELETED_OFFICE2_SCENES);
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('vs_saved_scenes_')) {
          try {
            const arr = JSON.parse(localStorage.getItem(k) || '[]');
            if (Array.isArray(arr)) {
              const filtered = arr.map(Number).filter((n) => n > 0 && !toRemove.has(n));
              localStorage.setItem(k, JSON.stringify(filtered));
            }
          } catch (e) {}
        }
      }
      localStorage.setItem(PURGE_FLAG_KEY, '1');
    } catch (e) {}
  }

  function syncFullPromptsToExtensionBackground() {
    try {
      purgeDeletedOffice2ScenesInStudioStorageOnce();
      const allPrompts = parseAllPromptsFromStudioDom();
      if (!allPrompts || allPrompts.length === 0) return;
      const fInput = document.getElementById('botCustomFolderNameInput');
      const fmtSel = document.getElementById('botFileNameFormatSelect');
      const folderName = (fInput && fInput.value && fInput.value.trim()) || 'office 2';
      const fileNameFormat = (fmtSel && fmtSel.value) || '1';
      chrome.runtime.sendMessage(
        {
          action: 'SYNC_FULL_PROMPTS_FROM_STUDIO',
          folderName,
          fileNameFormat,
          allPrompts,
          grandTotal: allPrompts.length
        },
        () => {
          const _err = chrome.runtime.lastError;
        }
      );
    } catch (e) {}
  }

  function announceExtensionReady() {
    try {
      document.documentElement.dataset.geminiBotInstalled = 'true';
      window.postMessage({ source: 'GEMINI_AUTO_BOT_EXT', type: 'EXT_READY' }, '*');
    } catch (e) {}
  }

  purgeDeletedOffice2ScenesInStudioStorageOnce();
  announceExtensionReady();
  setTimeout(syncFullPromptsToExtensionBackground, 300);
  setInterval(announceExtensionReady, 2000);

  window.addEventListener('message', (event) => {
    if (!event.data || event.data.source !== 'VIDEO_STUDIO_PAGE') return;

    if (event.data.type === 'SYNC_STUDIO_USER_EMAIL' && event.data.email) {
      const cleanEm = String(event.data.email).trim().toLowerCase();
      chrome.runtime.sendMessage(
        {
          action: 'SET_STUDIO_EMAIL',
          email: cleanEm
        },
        (resp) => {
          window.postMessage(
            {
              source: 'GEMINI_AUTO_BOT_EXT',
              type: 'STUDIO_EMAIL_SYNCED_ACK',
              email: cleanEm,
              resp: resp || { ok: true }
            },
            '*'
          );
        }
      );
    } else if (event.data.type === 'START_GEMINI_IMAGE_BATCH') {
      purgeDeletedOffice2ScenesInStudioStorageOnce();
      const payload = Object.assign({}, event.data.payload || {});
      const domPrompts = parseAllPromptsFromStudioDom();
      if (domPrompts.length > 0) {
        payload.allPrompts = domPrompts;
        // Always pass full sorted prompts list so the extension checks every scene 1..N against savedScenesByFolder
        payload.prompts = domPrompts;
        payload.grandTotal = Math.max(Number(payload.grandTotal) || 0, domPrompts.length);
      }
      chrome.runtime.sendMessage(
        {
          action: 'START_BATCH',
          payload: payload
        },
        (resp) => {
          window.postMessage(
            {
              source: 'GEMINI_AUTO_BOT_EXT',
              type: 'BATCH_STARTED_ACK',
              resp: resp || { ok: true }
            },
            '*'
          );
        }
      );
    } else if (event.data.type === 'STOP_GEMINI_IMAGE_BATCH') {
      chrome.runtime.sendMessage({ action: 'STOP_BATCH' });
    } else if (event.data.type === 'CLEAN_GEMINI_IMAGE_BATCH') {
      chrome.runtime.sendMessage({ action: 'CLEAN_RESET_BOT', email: event.data.email || '' });
    } else if (event.data.type === 'SAVE_SCENE_TO_PC_FOLDER' && event.data.payload) {
      chrome.runtime.sendMessage(
        Object.assign({ action: 'SAVE_GENERATED_IMAGE', downloadOnly: true }, event.data.payload),
        () => {
          const _err = chrome.runtime.lastError;
        }
      );
    } else if (event.data.type === 'START_CHATGPT_SCRIPT_JOB') {
      chrome.runtime.sendMessage(
        {
          action: 'START_CHATGPT_SCRIPT',
          payload: event.data.payload
        },
        (resp) => {
          window.postMessage(
            {
              source: 'GEMINI_AUTO_BOT_EXT',
              type: 'CHATGPT_JOB_ACK',
              resp: resp || { ok: true }
            },
            '*'
          );
        }
      );
    }
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.action === 'EXTRACT_FULL_PROMPTS_FROM_STUDIO_DOM') {
      purgeDeletedOffice2ScenesInStudioStorageOnce();
      const allPrompts = parseAllPromptsFromStudioDom();
      const fInput = document.getElementById('botCustomFolderNameInput');
      const fmtSel = document.getElementById('botFileNameFormatSelect');
      sendResponse({
        ok: true,
        allPrompts,
        folderName: (fInput && fInput.value && fInput.value.trim()) || 'office 2',
        fileNameFormat: (fmtSel && fmtSel.value) || '1'
      });
      return true;
    }
    if (
      msg.type === 'GEMINI_BOT_IMAGE_READY' ||
      msg.type === 'GEMINI_BOT_PROGRESS' ||
      msg.type === 'GEMINI_BOT_BATCH_DONE' ||
      msg.type === 'CHATGPT_SCRIPT_READY'
    ) {
      window.postMessage(
        Object.assign({ source: 'GEMINI_AUTO_BOT_EXT' }, msg),
        '*'
      );
    }
    sendResponse({ ok: true });
    return true;
  });
})();
