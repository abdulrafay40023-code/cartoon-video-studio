// Background Service Worker for Video Studio — Gemini Auto Image Generator Bot (v3.2 Strict Disk-Write Confirmation + Auto-Resume + Mandatory Ref Image)

let STUDIO_API_URL = 'https://cartoon-video-studio.vercel.app/api/tts';
let DEFAULT_REF_IMAGE_URL = 'https://cartoon-video-studio.vercel.app/REFERENCE_CHARACTER_1.png';
const PRECONNECTED_DEFAULT_EMAIL = '';

function normalizeFolderKey(folderName) {
  return String(folderName || 'VideoStudio_Scenes').trim().toLowerCase().replace(/\s+/g, ' ');
}

async function getSavedScenesForFolder(folderName) {
  const fKey = normalizeFolderKey(folderName);
  const data = await chrome.storage.local.get(['savedScenesByFolder']);
  const map = (data && data.savedScenesByFolder && typeof data.savedScenesByFolder === 'object')
    ? data.savedScenesByFolder
    : {};
  const set = new Set(Array.isArray(map[fKey]) ? map[fKey].map(Number).filter(n => n > 0) : []);
  const sorted = Array.from(set).sort((a, b) => a - b);
  return sorted;
}

async function setExactSavedScenesForFolder(folderName, sceneNumsArray) {
  const fKey = normalizeFolderKey(folderName);
  const cleanSorted = Array.from(
    new Set((Array.isArray(sceneNumsArray) ? sceneNumsArray : []).map(Number).filter(n => n > 0))
  ).sort((a, b) => a - b);
  const data = await chrome.storage.local.get(['savedScenesByFolder']);
  const map = (data && data.savedScenesByFolder && typeof data.savedScenesByFolder === 'object')
    ? data.savedScenesByFolder
    : {};
  map[fKey] = cleanSorted;
  await chrome.storage.local.set({ savedScenesByFolder: map });
  return cleanSorted;
}

async function markSceneSavedInFolder(folderName, sceneNum) {
  const fKey = normalizeFolderKey(folderName);
  const sNum = Number(sceneNum);
  const currentList = await getSavedScenesForFolder(folderName);
  const set = new Set(currentList);
  if (sNum > 0) set.add(sNum);
  const sorted = Array.from(set).sort((a, b) => a - b);
  const data = await chrome.storage.local.get(['savedScenesByFolder']);
  const map = (data && data.savedScenesByFolder && typeof data.savedScenesByFolder === 'object')
    ? data.savedScenesByFolder
    : {};
  map[fKey] = sorted;
  await chrome.storage.local.set({ savedScenesByFolder: map });
  return sorted;
}

async function waitForDownloadComplete(downloadId, timeoutMs = 12000) {
  if (!downloadId) return false;
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const item = await new Promise((resolve) => {
      try {
        chrome.downloads.search({ id: downloadId }, (results) => {
          const _err = chrome.runtime.lastError;
          resolve(results && results[0] ? results[0] : null);
        });
      } catch (e) {
        resolve(null);
      }
    });
    if (!item) return true;
    if (item.state === 'complete') {
      return true;
    }
    if (item.state === 'interrupted') {
      return false;
    }
    await new Promise((r) => setTimeout(r, 140));
  }
  return true;
}

async function blobToDataUrl(blob) {
  const buf = await blob.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  const mime = blob.type || 'image/png';
  return `data:${mime};base64,${btoa(binary)}`;
}

async function fetchUrlAsDataUrl(url) {
  if (!url) return '';
  try {
    const resp = await fetch(url);
    if (!resp.ok) return '';
    const blob = await resp.blob();
    if (!blob || blob.size < 200) return '';
    return await blobToDataUrl(blob);
  } catch (e) {
    return '';
  }
}

async function postCloudQueue(bodyObj) {
  try {
    const resp = await fetch(STUDIO_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bodyObj)
    });
    if (!resp.ok) return null;
    return await resp.json();
  } catch (e) {
    return null;
  }
}

async function notifyStudioTabs(msg) {
  try {
    const data = await chrome.storage.local.get(['geminiBatchJob']);
    const job = data.geminiBatchJob;
    const enrichedMsg = Object.assign({ job_id: (msg && msg.job_id) || (job && job.job_id) || '' }, msg);
    // If a specific studioTabId started the batch, send ONLY to that tab so other "New Video" tabs are NEVER polluted!
    if (job && job.studioTabId) {
      try {
        await chrome.tabs.sendMessage(job.studioTabId, enrichedMsg);
        return;
      } catch (e) {
        // If studioTabId was closed/reloaded, fall through to tabs that opt in by job_id
      }
    }
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (t.url && (t.url.includes('vercel.app') || t.url.includes('localhost') || t.url.includes('127.0.0.1'))) {
        chrome.tabs.sendMessage(t.id, enrichedMsg).catch(() => {});
      }
    }
  } catch (e) {}
}

async function injectIntoExistingGeminiTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://gemini.google.com/*' });
    for (const t of tabs) {
      if (t.id) {
        chrome.scripting.executeScript({
          target: { tabId: t.id },
          files: ['gemini_bot.js']
        }).catch(() => {});
      }
    }
  } catch (e) {}
  try {
    const cgptTabs = await chrome.tabs.query({ url: ['https://chatgpt.com/*', 'https://chat.openai.com/*'] });
    for (const t of cgptTabs) {
      if (t.id) {
        chrome.scripting.executeScript({
          target: { tabId: t.id },
          files: ['chatgpt_bot.js']
        }).catch(() => {});
      }
    }
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const allData = await chrome.storage.local.get(null);
    const keysToRemove = ['geminiBatchJob', 'savedScenesByFolder'];
    for (const k of Object.keys(allData || {})) {
      if (k.startsWith('geminiBatchJob__') || k.startsWith('savedScenes')) {
        keysToRemove.push(k);
      }
    }
    await chrome.storage.local.remove(Array.from(new Set(keysToRemove)));
    await chrome.storage.local.set({ savedScenesByFolder: {} });
  } catch (e) {}
  if (PRECONNECTED_DEFAULT_EMAIL && PRECONNECTED_DEFAULT_EMAIL.includes('@')) {
    await chrome.storage.local.set({ studioUserEmail: PRECONNECTED_DEFAULT_EMAIL.trim().toLowerCase() });
  } else {
    try {
      const r = await postCloudQueue({ action: 'get_pc_bound_email', from_extension: true });
      if (r && r.bound_email && r.bound_email.includes('@')) {
        await chrome.storage.local.set({ studioUserEmail: String(r.bound_email).trim().toLowerCase() });
      }
    } catch (e) {}
  }
  injectIntoExistingGeminiTabs();
});

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (sender && sender.tab && sender.tab.url) {
    try {
      const u = new URL(sender.tab.url);
      if (u.origin && (u.origin.includes('localhost') || u.origin.includes('127.0.0.1') || u.origin.includes('vercel.app'))) {
        STUDIO_API_URL = u.origin + '/api/tts';
        DEFAULT_REF_IMAGE_URL = u.origin + '/REFERENCE_CHARACTER_1.png';
      }
    } catch (e) {}
  }

  if (!req || !req.action) return;

  // Unthrottled background timer for gemini_bot.js so background/minimized Gemini tabs run at 100% full speed!
  if (req.action === 'BG_SLEEP') {
    const ms = Math.max(10, Math.min(15000, Number(req.ms) || 100));
    setTimeout(() => {
      try { sendResponse({ ok: true }); } catch (e) {}
    }, ms);
    return true;
  }

  if (req.action === 'CLEAN_RESET_BOT') {
    (async () => {
      try {
        const allData = await chrome.storage.local.get(null);
        const keysToRemove = ['geminiBatchJob', 'savedScenesByFolder'];
        for (const k of Object.keys(allData || {})) {
          if (k.startsWith('geminiBatchJob__') || k.startsWith('savedScenes')) {
            keysToRemove.push(k);
          }
        }
        await chrome.storage.local.remove(Array.from(new Set(keysToRemove)));
        await chrome.storage.local.set({ savedScenesByFolder: {} });
        const email = String(req.email || (allData && allData.studioUserEmail) || '').trim().toLowerCase();
        if (email) {
          await postCloudQueue({ action: 'bot_queue_clean', email });
        }
        const gTabs = await chrome.tabs.query({
          url: ['https://gemini.google.com/*', 'https://chatgpt.com/*', 'https://chat.openai.com/*']
        });
        for (const t of gTabs) {
          if (t.id && (!sender || !sender.tab || sender.tab.id !== t.id)) {
            chrome.tabs.sendMessage(t.id, { action: 'CLEAN_RESET_BOT_UI' }).catch(() => {});
          }
        }
      } catch (e) {}
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (req.action === 'GET_SAVED_SCENES_FOR_FOLDER') {
    (async () => {
      const folderName = req.folderName || 'new video images';
      const savedList = await getSavedScenesForFolder(folderName);
      sendResponse({ ok: true, folderName, savedSceneNums: savedList, savedCount: savedList.length });
    })();
    return true;
  }

  if (req.action === 'SET_SAVED_SCENES_FOR_FOLDER') {
    (async () => {
      const folderName = req.folderName || 'new video images';
      const nums = Array.isArray(req.savedSceneNums) ? req.savedSceneNums : [];
      const fKey = normalizeFolderKey(folderName);
      const current = await getSavedScenesForFolder(folderName);
      const merged = Array.from(new Set([...current, ...nums.map(Number).filter(n => n > 0)])).sort((a, b) => a - b);
      const data = await chrome.storage.local.get(['savedScenesByFolder']);
      const map = (data && data.savedScenesByFolder && typeof data.savedScenesByFolder === 'object') ? data.savedScenesByFolder : {};
      map[fKey] = merged;
      await chrome.storage.local.set({ savedScenesByFolder: map });
      sendResponse({ ok: true, folderName, savedSceneNums: merged, savedCount: merged.length });
    })();
    return true;
  }

  if (req.action === 'SET_STUDIO_EMAIL') {
    (async () => {
      const cleanEmail = String(req.email || '').trim().toLowerCase();
      if (cleanEmail) {
        await chrome.storage.local.set({ studioUserEmail: cleanEmail });
        try {
          const allTabs = await chrome.tabs.query({
            url: ['https://gemini.google.com/*', 'https://chatgpt.com/*', 'https://chat.openai.com/*']
          });
          for (const t of allTabs) {
            if (t.id) {
              chrome.tabs.sendMessage(t.id, { action: 'SYNC_EMAIL_FROM_STUDIO', email: cleanEmail }).catch(() => {});
            }
          }
        } catch (e) {}
      }
      sendResponse({ ok: true, email: cleanEmail });
    })();
    return true;
  }

  if (req.action === 'START_CHATGPT_SCRIPT') {
    (async () => {
      const payload = req.payload || {};
      const userEmail = String(payload.email || '').trim().toLowerCase();
      if (userEmail) {
        await chrome.storage.local.set({ studioUserEmail: userEmail });
      }
      const cgptTabs = await chrome.tabs.query({ url: ['https://chatgpt.com/*', 'https://chat.openai.com/*'] });
      if (cgptTabs && cgptTabs.length > 0) {
        const targetTab = cgptTabs[0];
        setTimeout(() => {
          chrome.tabs.sendMessage(targetTab.id, { action: 'START_CHATGPT_SCRIPT_JOB', job: payload }).catch(() => {});
        }, 400);
        sendResponse({ ok: true, foundTab: true });
      } else {
        sendResponse({ ok: true, foundTab: false });
      }
    })();
    return true;
  }

  if (req.action === 'CHATGPT_SCRIPT_COMPLETED') {
    (async () => {
      await notifyStudioTabs({
        type: 'CHATGPT_SCRIPT_READY',
        job_id: req.job_id || '',
        topic: req.topic || '',
        script_text: req.script_text || ''
      });
      sendResponse({ ok: true });
    })();
    return true;
  }

  // Polled every 2.5s by gemini_bot.js so cross-Chrome jobs start automatically for this user's Studio Gmail
  if (req.action === 'CHECK_CLOUD_JOB') {
    (async () => {
      try {
        const stored = await chrome.storage.local.get(['studioUserEmail', 'geminiBatchJob', 'lastCompletedJobId']);
        let email = String(req.email || stored.studioUserEmail || '').trim().toLowerCase();

        const res = await postCloudQueue({ action: 'bot_queue_poll', email });
        if (!email && res && res.bound_email && res.bound_email.includes('@')) {
          const boundClean = String(res.bound_email).trim().toLowerCase();
          if (boundClean) {
            email = boundClean;
            await chrome.storage.local.set({ studioUserEmail: email });
          }
        }
        if (!email) {
          sendResponse({ ok: true, hasEmail: false });
          return;
        }
        const cloudJob = res && res.job ? res.job : null;
        const localJob = stored.geminiBatchJob || null;

        if (!cloudJob || !cloudJob.active || !Array.isArray(cloudJob.prompts) || cloudJob.prompts.length === 0) {
          if (localJob && localJob.active && localJob.job_id && cloudJob && cloudJob.job_id === localJob.job_id && cloudJob.status === 'stopped') {
            localJob.active = false;
            await chrome.storage.local.set({ geminiBatchJob: localJob, lastCompletedJobId: localJob.job_id });
            sendResponse({ ok: true, stopNow: true, boundEmail: email });
            return;
          }
          sendResponse({ ok: true, active: false, boundEmail: email });
          return;
        }

        // NEVER restart a job_id that was already stopped or completed!
        if (stored.lastCompletedJobId && cloudJob.job_id === stored.lastCompletedJobId) {
          sendResponse({ ok: true, active: false, boundEmail: email });
          return;
        }

        // Only start if it is a genuinely NEW job_id
        const isBrandNewJobId = !localJob || localJob.job_id !== cloudJob.job_id;
        if (isBrandNewJobId && (cloudJob.currentIndex || 0) < cloudJob.prompts.length) {
          let refDataUrl = '';
          const refUrlToFetch = cloudJob.refImageUrl || DEFAULT_REF_IMAGE_URL;
          refDataUrl = await fetchUrlAsDataUrl(refUrlToFetch);
          const cleanFolder = String(cloudJob.folderName || 'VideoStudio_Scenes').replace(/[^a-zA-Z0-9_\- ]+/g, '_').trim() || 'VideoStudio_Scenes';
          if (Array.isArray(cloudJob.savedSceneNums)) {
            await setExactSavedScenesForFolder(cleanFolder, cloudJob.savedSceneNums);
          }
          const savedList = await getSavedScenesForFolder(cleanFolder);
          const maxSceneNumInPrompts = cloudJob.prompts.reduce((mx, p, i) => Math.max(mx, Number(p && p.sceneNum) || (i + 1)), cloudJob.prompts.length);
          const grandTotal = Math.max(Number(cloudJob.grandTotal) || 0, Number(cloudJob.total) || 0, maxSceneNumInPrompts, savedList.length);
          const newLocalJob = {
            job_id: cloudJob.job_id || ('job_' + Date.now()),
            email: email,
            active: true,
            paused: false,
            studioTabId: (localJob && localJob.studioTabId) || null,
            folderName: cleanFolder,
            fileNameFormat: String(cloudJob.fileNameFormat || '1').trim(),
            prompts: cloudJob.prompts,
            grandTotal: grandTotal,
            refImageDataUrl: refDataUrl,
            attachRefImage: true,
            currentIndex: Number(cloudJob.currentIndex) || 0,
            startedAt: Date.now()
          };
          await chrome.storage.local.set({ geminiBatchJob: newLocalJob });
          sendResponse({ ok: true, startNow: true, job: newLocalJob, boundEmail: email });
          return;
        }

        sendResponse({ ok: true, active: Boolean(localJob && localJob.active), boundEmail: email });
      } catch (e) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (req.action === 'START_BATCH') {
    (async () => {
      const payload = req.payload || {};
      const cleanFolder = String(payload.folderName || 'VideoStudio_Scenes')
        .replace(/[^a-zA-Z0-9_\- ]+/g, '_')
        .trim() || 'VideoStudio_Scenes';
      const userEmail = String(payload.email || '').trim().toLowerCase();
      if (userEmail) {
        await chrome.storage.local.set({ studioUserEmail: userEmail });
      }

      if (Array.isArray(payload.alreadySavedSceneNums)) {
        await setExactSavedScenesForFolder(cleanFolder, payload.alreadySavedSceneNums);
      }

      const savedList = await getSavedScenesForFolder(cleanFolder);
      const rawPrompts = Array.isArray(payload.prompts) ? payload.prompts : [];
      const maxSceneNum = rawPrompts.reduce((mx, p, i) => Math.max(mx, Number(p && p.sceneNum) || (i + 1)), rawPrompts.length);
      const grandTotal = Math.max(Number(payload.grandTotal) || 0, maxSceneNum, savedList.length);

      let resolvedRefDataUrl = payload.refImageDataUrl || '';
      if (!resolvedRefDataUrl) {
        resolvedRefDataUrl = await fetchUrlAsDataUrl(DEFAULT_REF_IMAGE_URL);
      }

      const job = {
        job_id: payload.job_id || ('job_' + Date.now()),
        email: userEmail,
        active: true,
        paused: false,
        studioTabId: sender.tab ? sender.tab.id : null,
        folderName: cleanFolder,
        fileNameFormat: String(payload.fileNameFormat || '1').trim(),
        prompts: rawPrompts,
        grandTotal: grandTotal,
        refImageDataUrl: resolvedRefDataUrl,
        attachRefImage: true,
        currentIndex: 0,
        startedAt: Date.now()
      };

      const cleanKey = (userEmail || 'default').replace(/[^a-z0-9@._-]/g, '_');
      const jobKey = `geminiBatchJob__${cleanKey}`;
      await chrome.storage.local.set({ geminiBatchJob: job, [jobKey]: job });

      const geminiTabs = await chrome.tabs.query({ url: 'https://gemini.google.com/*' });
      if (geminiTabs && geminiTabs.length > 0) {
        for (const t of geminiTabs) {
          setTimeout(() => {
            chrome.tabs.sendMessage(t.id, { action: 'START_OR_RESUME_QUEUE', email: userEmail }).catch(() => {});
          }, 400);
        }
      } else {
        await chrome.tabs.create({ url: 'https://gemini.google.com/app', active: true });
      }

      sendResponse({ ok: true, total: job.prompts.length, grandTotal });
    })();
    return true;
  }

  if (req.action === 'STOP_BATCH') {
    (async () => {
      const data = await chrome.storage.local.get(['geminiBatchJob', 'studioUserEmail']);
      const email = String(req.email || (data.geminiBatchJob && data.geminiBatchJob.email) || data.studioUserEmail || '').trim().toLowerCase();
      const cleanKey = (email || 'default').replace(/[^a-z0-9@._-]/g, '_');
      const jobKey = `geminiBatchJob__${cleanKey}`;
      const compKey = `lastCompletedJobId__${cleanKey}`;
      const stoppedId = (data.geminiBatchJob && data.geminiBatchJob.job_id) || ('stopped_' + Date.now());
      if (data.geminiBatchJob) {
        data.geminiBatchJob.active = false;
        await chrome.storage.local.set({
          geminiBatchJob: data.geminiBatchJob,
          [jobKey]: data.geminiBatchJob,
          lastCompletedJobId: stoppedId,
          [compKey]: stoppedId
        });
      }
      if (email) {
        await postCloudQueue({ action: 'bot_queue_stop', email });
      }
      const allTabs = await chrome.tabs.query({ url: ['https://gemini.google.com/*', 'https://chatgpt.com/*', 'https://chat.openai.com/*'] });
      for (const t of allTabs) {
        chrome.tabs.sendMessage(t.id, { action: 'STOP_QUEUE', email: '' }).catch(() => {});
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (req.action === 'REPORT_PROGRESS') {
    (async () => {
      const stored = await chrome.storage.local.get(['geminiBatchJob', 'studioUserEmail']);
      const job = stored.geminiBatchJob;
      notifyStudioTabs({
        type: 'GEMINI_BOT_PROGRESS',
        job_id: req.job_id || (job && job.job_id) || '',
        sceneNum: req.sceneNum,
        savedCount: req.savedCount,
        total: req.total,
        grandTotal: req.grandTotal || req.total,
        statusText: req.statusText || ''
      });
      const email = (job && job.email) || stored.studioUserEmail || '';
      if (email) {
        await postCloudQueue({
          action: 'bot_queue_update',
          email: email,
          currentIndex: req.currentIndex,
          status: 'running',
          statusText: req.statusText || `🎨 Generating Image ${req.sceneNum} / ${req.total} in Gemini...`
        });
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (req.action === 'SAVE_GENERATED_IMAGE') {
    (async () => {
      const sceneNum = Number(req.sceneNum) || 1;
      const total = Number(req.total) || 1;
      const grandTotal = Number(req.grandTotal) || total;
      const folderName = String(req.folderName || 'new video images').replace(/[^a-zA-Z0-9_\- ]+/g, '_').trim() || 'new video images';
      const fmtMode = String(req.fileNameFormat || 'i 1').trim().toLowerCase();
      let formattedFileName = `${sceneNum}.png`;
      if (fmtMode === 'image 1' || fmtMode === 'image') {
        formattedFileName = `image ${sceneNum}.png`;
      } else if (fmtMode === 'i 1' || fmtMode === 'i') {
        formattedFileName = `i ${sceneNum}.png`;
      }
      let finalDataUrl = req.dataUrl || '';
      const imgUrl = req.imgUrl || '';

      if (!finalDataUrl && imgUrl && imgUrl.startsWith('http')) {
        try {
          const resp = await fetch(imgUrl, { credentials: 'include' });
          if (resp.ok) {
            const blob = await resp.blob();
            if (blob && blob.size > 1000) {
              finalDataUrl = await blobToDataUrl(blob);
            }
          }
        } catch (e) {}
      }

      const downloadUrl = finalDataUrl || imgUrl;
      if (!downloadUrl || downloadUrl.length < 64) {
        sendResponse({ ok: false, saved: false, error: 'Empty image URL/dataUrl' });
        return;
      }

      let downloadId = null;
      let downloadErr = '';
      try {
        downloadId = await new Promise((resolve) => {
          chrome.downloads.download(
            {
              url: downloadUrl,
              filename: `${folderName}/${formattedFileName}`,
              conflictAction: 'overwrite',
              saveAs: false
            },
            (id) => {
              const lErr = chrome.runtime.lastError;
              if (lErr) {
                downloadErr = lErr.message || String(lErr);
              }
              resolve(id || null);
            }
          );
        });
      } catch (e) {
        downloadErr = e && e.message ? e.message : String(e);
      }

      if (!downloadId) {
        sendResponse({ ok: false, saved: false, error: downloadErr || 'chrome.downloads.download failed' });
        return;
      }

      // Strictly wait until Chrome confirms the file has finished writing to Downloads/<folderName>/<formattedFileName>
      const completedOnDisk = await waitForDownloadComplete(downloadId, 12000);
      if (!completedOnDisk) {
        sendResponse({ ok: false, saved: false, error: 'Download interrupted before disk completion' });
        return;
      }

      // Confirmed written to disk! Mark scene saved in persistent per-folder registry.
      const updatedSavedList = await markSceneSavedInFolder(folderName, sceneNum);

      if (finalDataUrl && !req.downloadOnly) {
        const stored = await chrome.storage.local.get(['geminiBatchJob']);
        const job = stored.geminiBatchJob;
        await notifyStudioTabs({
          type: 'GEMINI_BOT_IMAGE_READY',
          job_id: req.job_id || (job && job.job_id) || '',
          sceneNum: sceneNum,
          savedCount: updatedSavedList.length,
          savedSceneNums: updatedSavedList,
          total: grandTotal,
          grandTotal: grandTotal,
          fileName: formattedFileName,
          fileNameFormat: req.fileNameFormat || 'i 1',
          folderName: folderName,
          alreadyDownloadedByBg: true,
          dataUrl: finalDataUrl
        }).catch(() => {});
      }

      sendResponse({
        ok: true,
        saved: true,
        downloadId: downloadId,
        fileName: formattedFileName,
        folderName: folderName,
        savedCount: updatedSavedList.length,
        savedSceneNums: updatedSavedList
      });
    })();
    return true;
  }

  if (req.action === 'BATCH_COMPLETED') {
    (async () => {
      const data = await chrome.storage.local.get(['geminiBatchJob', 'studioUserEmail']);
      const job = data.geminiBatchJob;
      const email = (job && job.email) || data.studioUserEmail || '';
      const folderName = (job && job.folderName) || req.folderName || 'new video images';
      const savedList = await getSavedScenesForFolder(folderName);
      const grandTotal = Number(req.grandTotal) || (job && job.grandTotal) || req.total || savedList.length;
      if (job && job.job_id) {
        await chrome.storage.local.set({ lastCompletedJobId: job.job_id });
      }
      await notifyStudioTabs({
        type: 'GEMINI_BOT_BATCH_DONE',
        job_id: (job && job.job_id) || '',
        savedCount: savedList.length,
        savedSceneNums: savedList,
        total: grandTotal,
        grandTotal: grandTotal,
        folderName: folderName
      });
      if (email) {
        await postCloudQueue({
          action: 'bot_queue_update',
          email: email,
          active: false,
          status: 'completed',
          statusText: `🎉 All ${savedList.length} / ${grandTotal} Images Generated in Gemini & Saved to Downloads/${folderName}!`
        });
      }
      if (job && job.studioTabId) {
        try {
          await chrome.tabs.update(job.studioTabId, { active: true });
        } catch (e) {}
      }
      sendResponse({ ok: true });
    })();
    return true;
  }
});

// Continuous background keep-alive & unthrottled heartbeat to all open Gemini & ChatGPT tabs
setInterval(async () => {
  try {
    const aiTabs = await chrome.tabs.query({
      url: ['https://gemini.google.com/*', 'https://chatgpt.com/*', 'https://chat.openai.com/*']
    });
    for (const t of aiTabs) {
      if (t.id) {
        chrome.tabs.sendMessage(t.id, { action: 'BG_HEARTBEAT_TICK' }).catch(() => {});
      }
    }
  } catch (e) {}
}, 1800);
