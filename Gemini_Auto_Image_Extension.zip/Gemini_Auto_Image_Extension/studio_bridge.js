// Content script injected into Video Studio (editing-tool-main.vercel.app)
(function () {
  function announceExtensionReady() {
    try {
      document.documentElement.dataset.geminiBotInstalled = 'true';
      window.postMessage({ source: 'GEMINI_AUTO_BOT_EXT', type: 'EXT_READY' }, '*');
    } catch (e) {}
  }

  announceExtensionReady();
  setInterval(announceExtensionReady, 2000);

  window.addEventListener('message', (event) => {
    if (!event.data || event.data.source !== 'VIDEO_STUDIO_PAGE') return;

    if (event.data.type === 'SYNC_STUDIO_USER_EMAIL' && event.data.email) {
      const cleanEm = String(event.data.email).trim().toLowerCase();
      chrome.runtime.sendMessage(
        {
          action: 'SET_STUDIO_EMAIL',
          email: cleanEm
        },
        (resp) => {
          window.postMessage(
            {
              source: 'GEMINI_AUTO_BOT_EXT',
              type: 'STUDIO_EMAIL_SYNCED_ACK',
              email: cleanEm,
              resp: resp || { ok: true }
            },
            '*'
          );
        }
      );
    } else if (event.data.type === 'START_GEMINI_IMAGE_BATCH') {
      chrome.runtime.sendMessage(
        {
          action: 'START_BATCH',
          payload: event.data.payload
        },
        (resp) => {
          window.postMessage(
            {
              source: 'GEMINI_AUTO_BOT_EXT',
              type: 'BATCH_STARTED_ACK',
              resp: resp || { ok: true }
            },
            '*'
          );
        }
      );
    } else if (event.data.type === 'STOP_GEMINI_IMAGE_BATCH') {
      chrome.runtime.sendMessage({ action: 'STOP_BATCH' });
    } else if (event.data.type === 'CLEAN_GEMINI_IMAGE_BATCH') {
      chrome.runtime.sendMessage({ action: 'CLEAN_RESET_BOT', email: event.data.email || '' });
    } else if (event.data.type === 'SAVE_SCENE_TO_PC_FOLDER' && event.data.payload) {
      chrome.runtime.sendMessage(
        Object.assign({ action: 'SAVE_GENERATED_IMAGE', downloadOnly: true }, event.data.payload),
        () => {
          const _err = chrome.runtime.lastError;
        }
      );
    } else if (event.data.type === 'START_CHATGPT_SCRIPT_JOB') {
      chrome.runtime.sendMessage(
        {
          action: 'START_CHATGPT_SCRIPT',
          payload: event.data.payload
        },
        (resp) => {
          window.postMessage(
            {
              source: 'GEMINI_AUTO_BOT_EXT',
              type: 'CHATGPT_JOB_ACK',
              resp: resp || { ok: true }
            },
            '*'
          );
        }
      );
    }
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;
    if (
      msg.type === 'GEMINI_BOT_IMAGE_READY' ||
      msg.type === 'GEMINI_BOT_PROGRESS' ||
      msg.type === 'GEMINI_BOT_BATCH_DONE' ||
      msg.type === 'CHATGPT_SCRIPT_READY'
    ) {
      window.postMessage(
        Object.assign({ source: 'GEMINI_AUTO_BOT_EXT' }, msg),
        '*'
      );
    }
    sendResponse({ ok: true });
    return true;
  });
})();
