// Content Script for https://gemini.google.com/* — Video Studio Auto Image Bot (v3.6 Clean Button + Strict Save-Before-Next + Auto-Resume + Mandatory Reference Image)
(function () {
  // Prevent duplicate execution of v3.6, and replace any older panel mounted in this tab immediately!
  if (window.__vsGeminiBotV40Loaded) return;
  window.__vsGeminiBotV40Loaded = true;
  try {
    const existingOldPanel = document.getElementById('vsGeminiBotPanel');
    if (existingOldPanel) existingOldPanel.remove();
  } catch (e) {}

  const STUDIO_API_URL = 'https://cartoon-video-studio.vercel.app/api/tts';
  const DEFAULT_REF_IMAGE_URL = 'https://cartoon-video-studio.vercel.app/REFERENCE_CHARACTER_1.png';
  const PRECONNECTED_DEFAULT_EMAIL = 'abdulrafay40023@gmail.com';

  let isLoopRunning = false;
  let isRecoveringChatImages = false;
  let stopRequested = false;
  let pauseRequested = false;
  let pauseStartedAt = 0;
  let skipCurrentRequested = false;
  let isMinimized = false;
  let lastKnownCompleted = 0;
  let lastKnownTotal = 0;

  // Per-Tab Unique Identity
  const TAB_ID = (function () {
    try {
      let id = sessionStorage.getItem('vs_gemini_tab_id');
      if (!id) {
        id = 'gtab_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
        sessionStorage.setItem('vs_gemini_tab_id', id);
        sessionStorage.setItem('vs_gemini_tab_created_at', String(Date.now()));
      }
      return id;
    } catch (e) {
      return 'gtab_' + Date.now();
    }
  })();
  const TAB_CREATED_AT = Number(sessionStorage.getItem('vs_gemini_tab_created_at') || Date.now());

  function normalizeFolderKey(folderName) {
    return String(folderName || 'VideoStudio_Scenes').trim().toLowerCase().replace(/\s+/g, ' ');
  }

  async function getSavedSceneSetForFolder(folderName) {
    const fKey = normalizeFolderKey(folderName);
    try {
      const data = await chrome.storage.local.get(['savedScenesByFolder']);
      const map = (data && data.savedScenesByFolder && typeof data.savedScenesByFolder === 'object')
        ? data.savedScenesByFolder
        : {};
      const set = new Set(Array.isArray(map[fKey]) ? map[fKey].map(Number).filter(n => n > 0) : []);
      return set;
    } catch (e) {
      return new Set();
    }
  }

  async function markSceneSavedLocally(folderName, sceneNum) {
    const fKey = normalizeFolderKey(folderName);
    const set = await getSavedSceneSetForFolder(folderName);
    if (Number(sceneNum) > 0) set.add(Number(sceneNum));
    const sorted = Array.from(set).sort((a, b) => a - b);
    try {
      const data = await chrome.storage.local.get(['savedScenesByFolder']);
      const map = (data && data.savedScenesByFolder && typeof data.savedScenesByFolder === 'object')
        ? data.savedScenesByFolder
        : {};
      map[fKey] = sorted;
      await chrome.storage.local.set({ savedScenesByFolder: map });
    } catch (e) {}
    return set;
  }

  function getTabEmail() {
    try {
      return String(sessionStorage.getItem('vs_gemini_tab_email') || '').trim().toLowerCase();
    } catch (e) {
      return '';
    }
  }

  function setTabEmail(email, isManual = false) {
    const clean = String(email || '').trim().toLowerCase();
    try {
      if (clean) {
        sessionStorage.setItem('vs_gemini_tab_email', clean);
        if (isManual) sessionStorage.setItem('vs_gemini_tab_manual', '1');
      } else {
        sessionStorage.removeItem('vs_gemini_tab_email');
      }
      heartbeatTabClaim(clean);
    } catch (e) {}
  }

  function readAllActiveTabClaims() {
    const now = Date.now();
    let map = {};
    try {
      const raw = localStorage.getItem('vs_gemini_tab_claims_v3');
      if (raw) map = JSON.parse(raw) || {};
    } catch (e) {
      map = {};
    }
    const cleaned = {};
    for (const [tid, info] of Object.entries(map)) {
      if (info && typeof info === 'object' && now - Number(info.ts || 0) < 7500) {
        cleaned[tid] = info;
      }
    }
    return cleaned;
  }

  function heartbeatTabClaim(currentEmail) {
    try {
      const claims = readAllActiveTabClaims();
      const em = String(currentEmail !== undefined ? currentEmail : getTabEmail()).trim().toLowerCase();
      claims[TAB_ID] = {
        email: em,
        createdAt: TAB_CREATED_AT,
        manual: sessionStorage.getItem('vs_gemini_tab_manual') === '1',
        ts: Date.now()
      };
      localStorage.setItem('vs_gemini_tab_claims_v3', JSON.stringify(claims));
    } catch (e) {}
  }

  function resolveDistinctTabEmail(connectedEmailsList, boundEmail = '') {
    const cleanBound = String(boundEmail || '').trim().toLowerCase();
    const rawList = Array.isArray(connectedEmailsList)
      ? connectedEmailsList.map((e) => String(e || '').trim().toLowerCase()).filter((e) => e && e.includes('@'))
      : [];
    const validList = [];
    if (cleanBound && cleanBound.includes('@')) validList.push(cleanBound);
    for (let i = rawList.length - 1; i >= 0; i--) {
      if (!validList.includes(rawList[i])) validList.push(rawList[i]);
    }

    let myEmail = getTabEmail();
    const isMyManual = sessionStorage.getItem('vs_gemini_tab_manual') === '1';
    if (!isMyManual && myEmail && validList.length > 0 && !validList.includes(myEmail)) {
      myEmail = '';
      setTabEmail('', false);
    }
    heartbeatTabClaim(myEmail);
    if (validList.length === 0) return myEmail;

    const claims = readAllActiveTabClaims();

    const claimedByOtherPriorityTabs = new Set();
    const claimedByAnyOtherTab = new Set();
    for (const [tid, info] of Object.entries(claims)) {
      if (tid === TAB_ID || !info || !info.email) continue;
      claimedByAnyOtherTab.add(info.email);
      const otherOlder = Number(info.createdAt || 0) < TAB_CREATED_AT || (Number(info.createdAt || 0) === TAB_CREATED_AT && tid < TAB_ID);
      if (info.manual || otherOlder) {
        claimedByOtherPriorityTabs.add(info.email);
      }
    }

    const completelyUnclaimed = validList.filter((em) => !claimedByAnyOtherTab.has(em) && em !== myEmail);

    if (!myEmail) {
      const firstFree = validList.find((em) => !claimedByAnyOtherTab.has(em)) || validList[0];
      if (firstFree) {
        setTabEmail(firstFree, false);
        return firstFree;
      }
    }

    if (!isMyManual && myEmail && claimedByOtherPriorityTabs.has(myEmail) && completelyUnclaimed.length > 0) {
      const nextDistinct = completelyUnclaimed[0];
      setTabEmail(nextDistinct, false);
      return nextDistinct;
    }

    return myEmail;
  }

  function getTabJobStorageKey(email) {
    const clean = String(email || getTabEmail() || 'default').trim().toLowerCase().replace(/[^a-z0-9@._-]/g, '_');
    return `geminiBatchJob__${clean}`;
  }

  function getTabCompletedJobStorageKey(email) {
    const clean = String(email || getTabEmail() || 'default').trim().toLowerCase().replace(/[^a-z0-9@._-]/g, '_');
    return `lastCompletedJobId__${clean}`;
  }

  function sleep(ms) {
    const waitMs = Math.max(10, Number(ms) || 50);
    return new Promise((resolve) => {
      if (stopRequested) return resolve();
      const start = Date.now();
      let settled = false;
      let checkTimer = null;
      let fallbackTimer = null;
      const done = () => {
        if (!settled) {
          settled = true;
          if (checkTimer) clearInterval(checkTimer);
          if (fallbackTimer) clearTimeout(fallbackTimer);
          resolve();
        }
      };
      fallbackTimer = setTimeout(done, waitMs + 40);
      checkTimer = setInterval(() => {
        if (stopRequested) done();
      }, 50);
      try {
        chrome.runtime.sendMessage({ action: 'BG_SLEEP', ms: waitMs }, (resp) => {
          const _err = chrome.runtime.lastError;
          const elapsed = Date.now() - start;
          if (resp && resp.ok && elapsed >= waitMs * 0.7) {
            done();
          }
        });
      } catch (e) {}
    });
  }

  let keepAliveAudioCtx = null;
  let keepAliveOsc = null;
  function startSilentAudioKeepAlive() {
    try {
      if (keepAliveAudioCtx && keepAliveAudioCtx.state === 'running') return;
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      if (!keepAliveAudioCtx) {
        keepAliveAudioCtx = new AudioCtx();
        const gain = keepAliveAudioCtx.createGain();
        gain.gain.value = 0.00001;
        keepAliveOsc = keepAliveAudioCtx.createOscillator();
        keepAliveOsc.frequency.value = 20;
        keepAliveOsc.connect(gain);
        gain.connect(keepAliveAudioCtx.destination);
        keepAliveOsc.start();
      }
      if (keepAliveAudioCtx.state === 'suspended') {
        keepAliveAudioCtx.resume().catch(() => {});
      }
    } catch (e) {}
  }

  function stopSilentAudioKeepAlive() {
    try {
      if (keepAliveOsc) {
        keepAliveOsc.stop();
        keepAliveOsc.disconnect();
        keepAliveOsc = null;
      }
      if (keepAliveAudioCtx) {
        keepAliveAudioCtx.close().catch(() => {});
        keepAliveAudioCtx = null;
      }
    } catch (e) {}
  }

  function createEl(tag, cssText, text) {
    const el = document.createElement(tag);
    if (cssText) el.style.cssText = cssText;
    if (text !== undefined && text !== null) el.textContent = text;
    return el;
  }

  async function directPostCloud(bodyObj) {
    try {
      const bgRes = await new Promise((resolve) => {
        let done = false;
        const timer = setTimeout(() => {
          if (!done) {
            done = true;
            resolve(null);
          }
        }, 7000);
        try {
          chrome.runtime.sendMessage({ action: 'CLOUD_API_POST', body: bodyObj }, (resp) => {
            const _err = chrome.runtime.lastError;
            if (!done) {
              done = true;
              clearTimeout(timer);
              resolve(resp && resp.ok && resp.data ? resp.data : null);
            }
          });
        } catch (e) {
          if (!done) {
            done = true;
            clearTimeout(timer);
            resolve(null);
          }
        }
      });
      if (bgRes) return bgRes;
    } catch (e) {}
    try {
      const resp = await fetch(STUDIO_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyObj)
      });
      if (!resp.ok) return null;
      return await resp.json();
    } catch (e) {
      return null;
    }
  }

  async function fetchUrlAsDataUrl(url) {
    if (!url) return '';
    try {
      const resp = await fetch(url);
      if (!resp.ok) return '';
      const blob = await resp.blob();
      if (!blob || blob.size < 200) return '';
      return await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result || '');
        reader.onerror = () => resolve('');
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      return '';
    }
  }

  function clickGeminiStopButtonIfGenerating() {
    const stopSelectors = [
      'button[aria-label*="Stop response"]',
      'button[aria-label*="Stop generating"]',
      'button[aria-label*="Stop"]',
      '.stop-icon'
    ];
    for (const sel of stopSelectors) {
      const el = document.querySelector(sel);
      if (el && (el.offsetParent !== null || document.hidden)) {
        const btn = el.closest('button') || el;
        try { btn.click(); } catch (e) {}
        return true;
      }
    }
    return false;
  }

  function formatSceneFileName(sceneNum, formatMode) {
    const n = Number(sceneNum) || 1;
    const fmt = String(formatMode || 'i 1').trim().toLowerCase();
    if (fmt === 'image 1' || fmt === 'image') return `image ${n}.png`;
    if (fmt === 'i 1' || fmt === 'i') return `i ${n}.png`;
    return `${n}.png`;
  }

  const SHOT_ROTATION_STYLES = [
    'wide-angle establishing shot',
    'close-up focal detail angle',
    'over-the-shoulder POV shot',
    'dramatic side-profile angle',
    'low-angle upward perspective',
    'high-angle top-down perspective',
    'three-quarter medium shot',
    'foreground object focus angle'
  ];

  const WHITE_CHAR_CONSISTENCY_TEMPLATE = `**CHARACTER CONSISTENCY PROMPT (STRICT 100% PURE PAPER-WHITE #FFFFFF SKIN TONE)**

Use the newly uploaded reference image in THIS message as the ONLY reference for the main character (completely ignore any peach/human-skin images from earlier turns in this chat). Keep him 100% IDENTICAL to the attached reference image in every detail:
- **SKIN TONE:** 100% PURE PAPER-WHITE (#FFFFFF) unshaded flat white cartoon skin on his face, neck, ears, and hands (pure white #FFFFFF like paper — NEVER peach, NEVER flesh-colored, NEVER beige/tan/warm human skin).
- **EYES & FACE:** Simple solid black vertical oval dot eyes (NO white sclera, NO pupils, NO irises, NO anime eyes, NO realistic eyes), thin black eyebrows, simple line nose, subtle smile, dark brown wavy hair, and clean black cartoon outlines.

**Style:** Polished 2D cartoon character (pure #FFFFFF white skin + solid black oval dot eyes) placed in detailed semi-realistic painted backgrounds, cinematic lighting, soft cel shading, and warm natural colors. Secondary/background characters have normal human skin tones, while the main character MUST have pure paper-white (#FFFFFF) skin.

**Continuity:** Change only the pose, facial expression, environment, and outfit when the story requires it. Maintain the exact same pure-white-skin cartoon character identity across all scenes.

**Format:** 16:9 landscape, cinematic composition, clear foreground and background, suitable for YouTube storytelling.

**Negative rules:** NO peach/flesh/human skin tone on the main character, NO anime eyes, NO white sclera in the main character's eyes, NO character redesign, NO photorealism, NO 3D, NO distorted hands, NO extra fingers, NO watermarks, and NO unrequested text.`;

  const WORLD_SCENE_STYLE_TEMPLATE = `**Style:** Polished 2D illustration with detailed semi-realistic painted backgrounds, clean black outlines, cinematic lighting, soft cel shading, and warm natural colors.

**Format:** 16:9 landscape, cinematic composition, clear foreground and background, suitable for YouTube storytelling.

**Negative rules:** No photorealism, 3D, distorted hands, extra fingers, watermarks, or unrequested text.`;

  function buildFullPromptMessageWithScript(item, idx) {
    const sceneNum = item.sceneNum || (idx + 1);
    const fullBlock = String(item.fullBlockText || '').trim();

    if (fullBlock) {
      if (/^Image\s+\d+\b/i.test(fullBlock)) {
        return fullBlock;
      }
      return `Image ${sceneNum}\n\n${fullBlock}`;
    }

    const scriptLine = String(item.scriptText || '').trim();
    let rawPrompt = String(item.promptText || '').trim();

    rawPrompt = rawPrompt
      .replace(/^Prompt:\s*/i, '')
      .replace(/\(\s*\d+\s*[–\-to]+\s*\d+\s*s(?:ec(?:ond)?s?)?\s*\)/gi, '')
      .replace(/\s{2,}/g, ' ')
      .trim();

    const shotLabel = SHOT_ROTATION_STYLES[(sceneNum - 1) % SHOT_ROTATION_STYLES.length];
    if (!/^Create the image\b/i.test(rawPrompt)) {
      rawPrompt = rawPrompt.replace(/^(?:Create|Generate)\s+a\s+(?:brand-new\s+)?static\s+16:9[^:]*:\s*/i, '').trim();
      rawPrompt = `Create the image in 16:9 widescreen 2D cartoon illustration (${shotLabel}, completely different camera angle and scene from previous image): ${rawPrompt}`;
    }

    if (scriptLine) {
      return `Image ${sceneNum}\n\n${WHITE_CHAR_CONSISTENCY_TEMPLATE}\n\n**SCENE:**\nScript: ${scriptLine}\nPrompt: ${rawPrompt}`;
    }
    return `Image ${sceneNum}\n\n${WHITE_CHAR_CONSISTENCY_TEMPLATE}\n\n**SCENE:**\nPrompt: ${rawPrompt}`;
  }

  // TrustedTypes-safe DOM builder (NO innerHTML anywhere)
  function ensureBotUI() {
    let box = document.getElementById('vsGeminiBotPanel');
    if (box) return box;
    if (!document.body) return null;

    box = createEl(
      'div',
      [
        'position:fixed',
        'top:14px',
        'right:16px',
        'z-index:2147483647',
        'width:368px',
        'background:linear-gradient(145deg, #0b1120, #111827)',
        'border:2px solid #38bdf8',
        'border-radius:14px',
        'padding:12px 14px',
        'color:#f8fafc',
        'font-family:system-ui,-apple-system,sans-serif',
        'box-shadow:0 16px 40px rgba(0,0,0,0.75)',
        'display:block'
      ].join(';')
    );
    box.id = 'vsGeminiBotPanel';

    const headerRow = createEl('div', 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;');
    const titleWrap = createEl('div', 'font-size:13px;font-weight:900;color:#38bdf8;display:flex;align-items:center;gap:6px;');
    titleWrap.appendChild(createEl('span', '', '🎬'));
    titleWrap.appendChild(createEl('span', '', 'Video Studio — Gemini Image Bot'));

    const rightControls = createEl('div', 'display:flex;align-items:center;gap:5px;');
    const countPill = createEl(
      'span',
      'background:rgba(16,185,129,0.2);border:1px solid #10b981;color:#34d399;font-size:11px;font-weight:800;padding:2px 8px;border-radius:999px;',
      `${lastKnownCompleted} / ${lastKnownTotal}`
    );
    countPill.id = 'vsBotCountPill';

    const minBtn = createEl(
      'button',
      'background:rgba(148,163,184,0.15);border:1px solid #475569;color:#cbd5e1;font-size:11px;font-weight:900;padding:1px 6px;border-radius:6px;cursor:pointer;',
      '—'
    );
    minBtn.id = 'vsBotMinBtn';
    minBtn.title = 'Minimize / Expand';

    rightControls.appendChild(countPill);
    rightControls.appendChild(minBtn);
    headerRow.appendChild(titleWrap);
    headerRow.appendChild(rightControls);
    box.appendChild(headerRow);

    const bodyWrap = createEl('div', 'display:block;');
    bodyWrap.id = 'vsBotBodyWrap';

    const emailCard = createEl('div', 'background:#050811;border:1px solid #1e293b;border-radius:9px;padding:8px 9px;margin-bottom:8px;');
    const emailLabelRow = createEl('div', 'font-size:10.5px;font-weight:800;color:#94a3b8;margin-bottom:5px;display:flex;align-items:center;justify-content:space-between;');
    emailLabelRow.appendChild(createEl('span', '', '👤 APNI STUDIO GMAIL (Jis se Tool Login hai):'));
    const emailBadge = createEl('span', 'color:#34d399;font-weight:900;', '');
    emailBadge.id = 'vsBotEmailBadge';
    emailLabelRow.appendChild(emailBadge);

    const emailInputRow = createEl('div', 'display:flex;gap:5px;');
    const emailInput = createEl(
      'input',
      'flex:1;background:#0f172a;border:1px solid #334155;border-radius:6px;padding:6px 8px;color:#fff;font-size:11.5px;outline:none;'
    );
    emailInput.id = 'vsBotStudioEmailInput';
    emailInput.type = 'email';
    emailInput.placeholder = 'Auto-Captured from Video Studio Tool...';

    const saveEmailBtn = createEl(
      'button',
      'padding:6px 10px;border-radius:6px;border:none;background:#10b981;color:#fff;font-size:11px;font-weight:800;cursor:pointer;',
      'Connect'
    );
    saveEmailBtn.id = 'vsBotSaveEmailBtn';

    const disconnectEmailBtn = createEl(
      'button',
      'padding:6px 8px;border-radius:6px;border:1px solid rgba(239,68,68,0.6);background:rgba(239,68,68,0.2);color:#fca5a5;font-size:11px;font-weight:900;cursor:pointer;',
      '✖'
    );
    disconnectEmailBtn.title = 'Remove / Disconnect current Gmail & enter another Gmail';
    emailInput.addEventListener('input', () => {
      emailInput.dataset.userEditing = '1';
    });

    emailInputRow.appendChild(emailInput);
    emailInputRow.appendChild(saveEmailBtn);
    emailInputRow.appendChild(disconnectEmailBtn);
    emailCard.appendChild(emailLabelRow);
    emailCard.appendChild(emailInputRow);
    bodyWrap.appendChild(emailCard);

    const statusTextEl = createEl(
      'div',
      'font-size:11.8px;color:#cbd5e1;line-height:1.45;margin-bottom:8px;',
      '⚪ Video Studio se Auto-Generate start karein ya Connect dabayein.'
    );
    statusTextEl.id = 'vsBotStatusText';
    bodyWrap.appendChild(statusTextEl);

    const barOuter = createEl('div', 'width:100%;height:7px;background:#1e293b;border-radius:999px;overflow:hidden;margin-bottom:9px;');
    const barFill = createEl('div', 'width:0%;height:100%;background:linear-gradient(90deg,#38bdf8,#10b981);transition:width 0.3s;');
    barFill.id = 'vsBotBarFill';
    barOuter.appendChild(barFill);
    bodyWrap.appendChild(barOuter);

    const btnRow = createEl('div', 'display:flex;align-items:center;gap:6px;');
    const pauseBtn = createEl(
      'button',
      'flex:1;padding:7px 8px;border-radius:8px;border:1px solid #f59e0b;background:rgba(245,158,11,0.18);color:#fbbf24;font-size:11.5px;font-weight:800;cursor:pointer;text-align:center;',
      '▶️ Resume'
    );
    pauseBtn.id = 'vsBotPauseBtn';

    const stopBtn = createEl(
      'button',
      'flex:1;padding:7px 8px;border-radius:8px;border:1px solid #ef4444;background:rgba(239,68,68,0.18);color:#f87171;font-size:11.5px;font-weight:800;cursor:pointer;text-align:center;',
      '🛑 Stop'
    );
    stopBtn.id = 'vsBotStopBtn';

    const cleanBtn = createEl(
      'button',
      'padding:7px 11px;border-radius:8px;border:1px solid #a855f7;background:rgba(168,85,247,0.22);color:#e9d5ff;font-size:11.5px;font-weight:900;cursor:pointer;text-align:center;',
      '🧹 Reset'
    );
    cleanBtn.id = 'vsBotCleanBtn';
    cleanBtn.title = 'Clean & Reset Bot Counter (0 / 0) and Clear Old Queue';

    btnRow.appendChild(pauseBtn);
    btnRow.appendChild(stopBtn);
    btnRow.appendChild(cleanBtn);
    bodyWrap.appendChild(btnRow);

    box.appendChild(bodyWrap);
    document.body.appendChild(box);

    const savedEm = getTabEmail();
    const isManuallyDisconnected = sessionStorage.getItem('vs_bot_manual_disconnected') === '1';
    if (savedEm && !isManuallyDisconnected) {
      emailInput.value = savedEm;
      emailBadge.textContent = '● Connected';
      emailBadge.style.color = '#34d399';
    } else {
      emailBadge.textContent = '⚪ Not Connected';
      emailBadge.style.color = '#94a3b8';
      chrome.storage.local.get(['studioUserEmail'], (st) => {
        if (st && st.studioUserEmail && !emailInput.value) {
          emailInput.value = st.studioUserEmail;
        }
      });
    }

    minBtn.onclick = () => {
      isMinimized = !isMinimized;
      bodyWrap.style.display = isMinimized ? 'none' : 'block';
      minBtn.textContent = isMinimized ? '+' : '—';
    };

    const disconnectGemEmailHandler = async () => {
      try {
        sessionStorage.setItem('vs_bot_manual_disconnected', '1');
        sessionStorage.removeItem('vs_bot_tab_email');
        sessionStorage.removeItem('vs_bot_tab_manual');
        localStorage.removeItem('vs_gemini_tab_claims_v3');
      } catch (e) {}
      try {
        await chrome.storage.local.remove(['studioUserEmail']);
      } catch (e) {}
      emailInput.value = '';
      emailInput.dataset.userEditing = '1';
      emailBadge.textContent = '⚪ Disconnected';
      emailBadge.style.color = '#fca5a5';
      updateBotUI('⚪ Purani Gmail hata di gayi! Ab upar nayi Gmail likh kar Connect dabayein.', 0, 0, true);
      directPostCloud({ action: 'unbind_pc_email' }).catch(() => {});
      try { emailInput.focus(); } catch (e) {}
    };

    disconnectEmailBtn.onclick = disconnectGemEmailHandler;

    saveEmailBtn.onclick = async () => {
      const email = String(emailInput.value || '').trim().toLowerCase();
      if (!email || !email.includes('@')) {
        await disconnectGemEmailHandler();
        return;
      }
      try {
        sessionStorage.removeItem('vs_bot_manual_disconnected');
      } catch (e) {}
      delete emailInput.dataset.userEditing;
      setTabEmail(email, true);
      await chrome.storage.local.set({ studioUserEmail: email });
      emailBadge.textContent = '● Connected';
      emailBadge.style.color = '#34d399';
      await directPostCloud({ action: 'bind_pc_email', email });
      updateBotUI(`🟢 Connected (${email}) — Ready!`, lastKnownCompleted, lastKnownTotal, true);
      checkCloudQueueOnce();
    };

    pauseBtn.onclick = async () => {
      if (!isLoopRunning) {
        pauseRequested = false;
        pauseStartedAt = 0;
        stopRequested = false;
        pauseBtn.textContent = '⏸️ Pause';
        const email = getTabEmail() || String(emailInput.value || '').trim().toLowerCase();
        const jobKey = getTabJobStorageKey(email);
        const stData = await chrome.storage.local.get([jobKey, 'geminiBatchJob']);
        const job = stData[jobKey] || stData.geminiBatchJob;
        if (job) {
          job.active = true;
          job.paused = false;
          await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job });
        }
        processQueue();
        return;
      }
      pauseRequested = !pauseRequested;
      pauseStartedAt = pauseRequested ? Date.now() : 0;
      pauseBtn.textContent = pauseRequested ? '▶️ Resume' : '⏸️ Pause';
      if (pauseRequested) {
        updateBotUI(`⏸️ Paused at ${lastKnownCompleted} / ${lastKnownTotal} Saved (Auto-resumes in 8s)...`, lastKnownCompleted, lastKnownTotal, true);
      }
    };

    skipBtn.onclick = () => {
      skipCurrentRequested = true;
    };

    stopBtn.onclick = async () => {
      stopRequested = true;
      pauseRequested = false;
      pauseStartedAt = 0;
      isLoopRunning = false;
      try { sessionStorage.removeItem('vs_gemini_auto_resume_on_load'); } catch (e) {}
      pauseBtn.textContent = '▶️ Resume / Start';
      clickGeminiStopButtonIfGenerating();
      stopSilentAudioKeepAlive();

      const email = getTabEmail() || String(emailInput.value || '').trim().toLowerCase();
      const jobKey = getTabJobStorageKey(email);
      const compKey = getTabCompletedJobStorageKey(email);
      const stData = await chrome.storage.local.get([jobKey, 'geminiBatchJob']);
      const tabJob = stData[jobKey] || stData.geminiBatchJob;
      const stoppedId = (tabJob && tabJob.job_id) || ('stopped_' + Date.now());
      const updateObj = { [compKey]: stoppedId, lastCompletedJobId: stoppedId };
      if (tabJob) {
        tabJob.active = false;
        updateObj[jobKey] = tabJob;
        updateObj['geminiBatchJob'] = tabJob;
      }
      await chrome.storage.local.set(updateObj);
      if (email) {
        directPostCloud({ action: 'bot_queue_stop', email, active: false });
      }
      updateBotUI(`🛑 Stopped immediately by user. All progress saved.`, lastKnownCompleted, lastKnownTotal, true);
    };

    cleanBtn.onclick = async () => {
      await cleanResetBotState(true);
    };

    return box;
  }

  async function cleanResetBotState(isManualClick = false) {
    stopRequested = true;
    pauseRequested = false;
    pauseStartedAt = 0;
    skipCurrentRequested = false;
    clickGeminiStopButtonIfGenerating();

    lastKnownCompleted = 0;
    lastKnownTotal = 0;

    const emailInputEl = document.getElementById('vsBotStudioEmailInput');
    const email = getTabEmail() || String((emailInputEl && emailInputEl.value) || '').trim().toLowerCase();
    const jobKey = getTabJobStorageKey(email);
    const compKey = getTabCompletedJobStorageKey(email);

    try {
      const allData = await chrome.storage.local.get(null);
      const keysToRemove = ['geminiBatchJob', 'savedScenesByFolder', jobKey];
      for (const k of Object.keys(allData || {})) {
        if (k.startsWith('geminiBatchJob__') || k.startsWith('savedScenes')) {
          keysToRemove.push(k);
        }
      }
      await chrome.storage.local.remove(Array.from(new Set(keysToRemove)));
      await chrome.storage.local.set({
        savedScenesByFolder: {},
        [compKey]: 'cleaned_' + Date.now()
      });
    } catch (e) {}

    try {
      sessionStorage.removeItem('vs_gemini_auto_resume_on_load');
    } catch (e) {}

    try {
      chrome.runtime.sendMessage({ action: 'CLEAN_RESET_BOT', email });
    } catch (e) {}

    if (email) {
      directPostCloud({ action: 'bot_queue_clean', email });
    }

    const startBtnEl = document.getElementById('vsBotRecoverChatBtn');
    if (startBtnEl) {
      startBtnEl.disabled = false;
      startBtnEl.textContent = '🚀 Start / Resume Auto Image Generation';
    }
    const pauseBtnEl = document.getElementById('vsBotPauseBtn');
    if (pauseBtnEl) {
      pauseBtnEl.textContent = '▶️ Resume';
    }
    updateBotUI(
      isManualClick
        ? '✨ Bot 100% Clean & Reset Ho Gaya Hai (0 / 0)! Ab Video Studio se nayi video ke prompts bhejein.'
        : '🟢 Ready! Video Studio se Auto-Generate start karein.',
      0,
      0,
      true
    );
  }

  function updateBotUI(statusText, completedCount, totalCount, visible = true) {
    const box = ensureBotUI();
    if (!box) return;
    box.style.display = visible ? 'block' : 'none';
    if (typeof completedCount === 'number' && completedCount >= 0) lastKnownCompleted = completedCount;
    if (typeof totalCount === 'number' && totalCount >= 0) lastKnownTotal = totalCount;

    const st = document.getElementById('vsBotStatusText');
    const pill = document.getElementById('vsBotCountPill');
    const bar = document.getElementById('vsBotBarFill');
    const pauseBtn = document.getElementById('vsBotPauseBtn');
    if (st) st.textContent = statusText;
    if (pill) {
      pill.textContent = `${lastKnownCompleted} / ${lastKnownTotal}`;
    }
    if (bar) {
      const pct = lastKnownTotal > 0 ? Math.min(100, Math.round((lastKnownCompleted / lastKnownTotal) * 100)) : 0;
      bar.style.width = `${pct}%`;
    }
    if (pauseBtn) {
      if (!isLoopRunning || pauseRequested) {
        pauseBtn.textContent = '▶️ Resume';
      } else {
        pauseBtn.textContent = '⏸️ Pause';
      }
    }
  }

  function findGeminiEditor() {
    const selectors = [
      'rich-textarea div.ql-editor[contenteditable="true"]',
      'div.ql-editor[contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]',
      'rich-textarea div[contenteditable="true"]',
      'div[contenteditable="true"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && (el.offsetParent !== null || document.hidden)) return el;
    }
    return null;
  }

  function findGeminiSendButton() {
    if (isGeminiStillGenerating()) return null;
    const selectors = [
      'button.send-button',
      'button[aria-label*="Send message"]',
      'button[aria-label*="Send"]',
      'button[mattooltip*="Send"]',
      '.send-button-container button'
    ];
    for (const sel of selectors) {
      const btns = document.querySelectorAll(sel);
      for (const b of btns) {
        if (!b || (b.offsetParent === null && !document.hidden) || b.disabled || b.getAttribute('aria-disabled') === 'true') {
          continue;
        }
        const aria = String(b.getAttribute('aria-label') || b.getAttribute('mattooltip') || b.title || b.textContent || '').toLowerCase();
        if (aria.includes('stop') || b.querySelector('.stop-icon')) {
          continue;
        }
        return b;
      }
    }
    return null;
  }

  function isGeminiStillGenerating() {
    const stopSelectors = [
      'button[aria-label*="Stop response"]',
      'button[aria-label*="Stop generating"]',
      'button[aria-label*="Stop"]',
      '.stop-icon'
    ];
    for (const sel of stopSelectors) {
      const el = document.querySelector(sel);
      if (el && (el.offsetParent !== null || document.hidden)) return true;
    }
    try {
      const responses = document.querySelectorAll('model-response');
      if (responses.length > 0) {
        const lastResp = responses[responses.length - 1];
        const spinners = lastResp.querySelectorAll('mat-progress-spinner, mat-spinner, [role="progressbar"], .loading-placeholder, .image-loading');
        for (const sp of spinners) {
          if (sp && (sp.offsetParent !== null || document.hidden)) return true;
        }
        const genContainers = lastResp.querySelectorAll('generated-image, single-image');
        for (const gc of genContainers) {
          const imgs = gc.querySelectorAll('img');
          let hasLoadedImg = false;
          for (const im of imgs) {
            if (im.complete && (im.naturalWidth || im.width || 0) >= 200) {
              hasLoadedImg = true;
              break;
            }
          }
          if (!hasLoadedImg) return true;
        }
      }
    } catch (e) {}
    return false;
  }

  // Detect Gemini Rate-Limit / Quota Reset / Generation Refusal so the bot IMMEDIATELY pauses instead of wasting prompts!
  function detectGeminiRateLimitOrError(minResponseCount = 0) {
    try {
      // Check global snackbars / toasts / banners
      const toasts = document.querySelectorAll('simple-snack-bar, .mat-mdc-snack-bar-label, [role="alert"], [role="status"], .error-message');
      for (const t of toasts) {
        const txt = String(t.innerText || t.textContent || '').trim();
        if (
          /reached your (?:image generation )?limit|limit (?:will )?reset|quota exceeded|too many requests|try again later|something went wrong/i.test(txt)
        ) {
          return txt.slice(0, 140);
        }
      }

      const responses = document.querySelectorAll('model-response');
      if (responses.length <= minResponseCount) return '';
      if (isGeminiStillGenerating()) return '';

      const lastResp = responses[responses.length - 1];
      if (!lastResp) return '';

      // If lastResp actually has a generated image, it's NOT an error
      const hasGenImg = findGeneratedImageInResponse(lastResp);
      if (hasGenImg) return '';

      const respText = String(lastResp.innerText || lastResp.textContent || '').trim();
      if (!respText) return '';

      const limitPatterns = [
        /reached your (?:image generation )?limit/i,
        /limit (?:will )?reset/i,
        /you(?:'ve| have) reached/i,
        /can(?:'t|not) generate more images/i,
        /unable to (?:create|generate)/i,
        /can(?:'t|not) create (?:that|images)/i,
        /too many requests/i,
        /quota/i,
        /try again (?:later|in|after|tomorrow)/i,
        /something went wrong/i,
        /i'm still learning how to generate/i,
        /against my safety guidelines/i
      ];
      for (const pat of limitPatterns) {
        if (pat.test(respText)) {
          return respText.replace(/\s+/g, ' ').slice(0, 150);
        }
      }
    } catch (e) {}
    return '';
  }

  let cachedRefDataUrlKey = '';
  let cachedRefFileObj = null;
  let bundledWhiteCharRefDataUrl = '';

  async function getGuaranteedWhiteCharRefDataUrl(job) {
    if (job && job.refImageDataUrl && String(job.refImageDataUrl).startsWith('data:image/')) {
      return job.refImageDataUrl;
    }
    if (bundledWhiteCharRefDataUrl) return bundledWhiteCharRefDataUrl;
    try {
      const localExtUrl = chrome.runtime.getURL('white_char_ref.jpg');
      const dUrl = await fetchUrlAsDataUrl(localExtUrl);
      if (dUrl && dUrl.startsWith('data:image/')) {
        bundledWhiteCharRefDataUrl = dUrl;
        return bundledWhiteCharRefDataUrl;
      }
    } catch (e) {}
    try {
      const dUrl = await fetchUrlAsDataUrl(DEFAULT_REF_IMAGE_URL);
      if (dUrl && dUrl.startsWith('data:image/')) {
        bundledWhiteCharRefDataUrl = dUrl;
        return bundledWhiteCharRefDataUrl;
      }
    } catch (e) {}
    return '';
  }

  async function pasteReferenceImageIntoEditor(editor, dataUrl) {
    try {
      let file = cachedRefFileObj;
      if (!file || cachedRefDataUrlKey !== dataUrl) {
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        const ext = (blob.type && blob.type.includes('jpeg')) ? 'jpg' : 'png';
        file = new File([blob], `WHITE_SKIN_CHARACTER_REF.${ext}`, { type: blob.type || 'image/jpeg' });
        cachedRefDataUrlKey = dataUrl;
        cachedRefFileObj = file;
      }
      try {
        editor.focus();
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
          sel.collapseToEnd();
        }
      } catch (e) {}

      const dt = new DataTransfer();
      dt.items.add(file);
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: dt
      });
      editor.dispatchEvent(pasteEvent);

      for (let w = 0; w < 18; w++) {
        await sleep(140);
        const previewEl = document.querySelector(
          'uploader-file-preview, .file-preview, [data-test-id*="file-preview"], .attachment-preview, rich-textarea img, .input-area img'
        );
        const uploadSpinner = document.querySelector(
          'uploader-file-preview mat-progress-spinner, uploader-file-preview [role="progressbar"], .file-preview mat-progress-spinner'
        );
        if (previewEl && !uploadSpinner && w >= 6) {
          break;
        }
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  async function setEditorTextAndSend(editor, text, refDataUrl = '', shouldAttachRef = false) {
    const safeSingleLineText = String(text || '')
      .replace(/\r?\n+/g, '   ')
      .replace(/\s{4,}/g, '   ')
      .trim();

    try { editor.focus(); } catch (e) {}
    await sleep(60);

    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
    } catch (e) {}

    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, safeSingleLineText);
    } catch (e) {}

    const curEditorText = String(editor.textContent || '').trim();
    if (!inserted || curEditorText.length < Math.max(40, safeSingleLineText.length * 0.75)) {
      editor.textContent = safeSingleLineText;
      editor.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: safeSingleLineText }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
    }

    await sleep(120);

    // Attach reference image AFTER text insertion so selectAll+delete NEVER wipes the image!
    if (shouldAttachRef && refDataUrl) {
      await pasteReferenceImageIntoEditor(editor, refDataUrl);
      const afterPasteText = String(editor.textContent || '').trim();
      if (afterPasteText.length < Math.max(40, safeSingleLineText.length * 0.75)) {
        editor.textContent = safeSingleLineText;
        editor.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: safeSingleLineText }));
        editor.dispatchEvent(new Event('change', { bubbles: true }));
      }
      await sleep(250);
    } else {
      await sleep(220);
    }

    for (let waitTry = 0; waitTry < 32; waitTry++) {
      const sendBtn = findGeminiSendButton();
      if (sendBtn) {
        sendBtn.click();
        return true;
      }
      await sleep(140);
    }

    editor.dispatchEvent(
      new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      })
    );
    return true;
  }

  function collectAllCandidateImages(rootEl = document) {
    const results = [];
    const seenEls = new Set();

    function addImg(img) {
      if (!img || seenEls.has(img)) return;
      seenEls.add(img);
      try {
        if (img.loading === 'lazy' || img.getAttribute('loading') === 'lazy') {
          img.loading = 'eager';
          img.removeAttribute('loading');
        }
        if (img.decoding !== 'sync') {
          img.decoding = 'sync';
        }
      } catch (e) {}
      results.push(img);
    }

    rootEl.querySelectorAll('img').forEach(addImg);
    rootEl.querySelectorAll('model-response, generated-image, single-image, [data-test-id*="image"]').forEach((host) => {
      if (host.shadowRoot) {
        host.shadowRoot.querySelectorAll('img').forEach(addImg);
      }
    });
    if (rootEl.shadowRoot) {
      rootEl.shadowRoot.querySelectorAll('img').forEach(addImg);
    }
    return results;
  }

  function getExistingGeneratedImageSrcs() {
    const set = new Set();
    const imgs = collectAllCandidateImages();
    for (const img of imgs) {
      if (img.src) set.add(img.src);
    }
    return set;
  }

  function isLikelyGeneratedSceneImageElement(img) {
    if (!img || !img.src) return false;
    const s = String(img.src);
    if (s.includes('googleusercontent.com/a/') || s.includes('avatar') || s.includes('icon') || s.includes('logo') || s.endsWith('.svg')) {
      return false;
    }
    const rect = img.getBoundingClientRect ? img.getBoundingClientRect() : { width: 0, height: 0 };
    const w = Math.max(img.naturalWidth || 0, img.width || 0, rect.width || 0);
    const h = Math.max(img.naturalHeight || 0, img.height || 0, rect.height || 0);
    if (img.complete && w >= 220 && h >= 130) {
      return true;
    }
    const inGeneratedContainer = Boolean(
      img.closest('generated-image, single-image, [data-test-id*="image"], .generated-image, .image-container, model-response')
    );
    if (inGeneratedContainer && (w === 0 || w >= 200) && (s.startsWith('blob:') || s.startsWith('data:image/') || s.includes('googleusercontent.com') || s.includes('ggpht.com'))) {
      return true;
    }
    return false;
  }

  function findGeneratedImageInResponse(respEl) {
    if (!respEl) return null;
    const imgs = collectAllCandidateImages(respEl);
    for (let i = imgs.length - 1; i >= 0; i--) {
      const img = imgs[i];
      if (!img || !img.src) continue;
      if (img.closest('#vsGeminiBotPanel, user-query, .user-query-container, .query-content, .input-area, uploader-file-preview')) continue;
      if (isLikelyGeneratedSceneImageElement(img)) {
        return img;
      }
    }
    return null;
  }

  function findNewlyGeneratedImage(beforeSet) {
    try {
      const responses = document.querySelectorAll('model-response, generated-image, single-image');
      if (responses.length > 0) {
        const lastResp = responses[responses.length - 1];
        if (lastResp && typeof lastResp.scrollIntoView === 'function') {
          lastResp.scrollIntoView({ block: 'end' });
        }
      }
    } catch (e) {}

    const imgs = collectAllCandidateImages();
    for (let i = imgs.length - 1; i >= 0; i--) {
      const img = imgs[i];
      if (!img || !img.src) continue;
      if (beforeSet.has(img.src)) continue;
      if (img.closest('#vsGeminiBotPanel, user-query, .user-query-container, .query-content, .input-area, uploader-file-preview')) continue;
      if (isLikelyGeneratedSceneImageElement(img)) {
        return img;
      }
    }
    return null;
  }

  function encodeSourceToSafePngDataUrl(sourceElOrBmp, srcW, srcH) {
    const scales = [
      { maxW: 1280, maxH: 720 },
      { maxW: 1024, maxH: 576 },
      { maxW: 896, maxH: 504 }
    ];
    let lastDataUrl = '';
    for (const sc of scales) {
      let targetW = srcW || 1280;
      let targetH = srcH || 720;
      if (targetW > sc.maxW || targetH > sc.maxH) {
        const ratio = Math.min(sc.maxW / targetW, sc.maxH / targetH);
        targetW = Math.max(200, Math.round(targetW * ratio));
        targetH = Math.max(120, Math.round(targetH * ratio));
      }
      const canvas = document.createElement('canvas');
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(sourceElOrBmp, 0, 0, targetW, targetH);
      const pngDataUrl = canvas.toDataURL('image/png');
      if (pngDataUrl && pngDataUrl.startsWith('data:image/png;base64,')) {
        lastDataUrl = pngDataUrl;
        if (pngDataUrl.length < 1650000) {
          return pngDataUrl;
        }
      }
    }
    return lastDataUrl;
  }

  async function extractImageAsDataUrl(imgEl) {
    if (!imgEl) return '';
    try {
      let blob = null;
      if (imgEl.src && imgEl.src.startsWith('data:image/')) {
        const r = await fetch(imgEl.src);
        blob = await r.blob();
      } else if (imgEl.src) {
        const resp = await fetch(imgEl.src, { credentials: 'include' });
        if (resp.ok) {
          blob = await resp.blob();
        }
      }
      if (blob && blob.size > 6000 && typeof createImageBitmap === 'function') {
        const bmp = await createImageBitmap(blob);
        if (bmp.width >= 200 && bmp.height >= 120) {
          const w = bmp.width || imgEl.naturalWidth || 1280;
          const h = bmp.height || imgEl.naturalHeight || 720;
          const pngDataUrl = encodeSourceToSafePngDataUrl(bmp, w, h);
          if (typeof bmp.close === 'function') bmp.close();
          if (pngDataUrl) return pngDataUrl;
        } else if (typeof bmp.close === 'function') {
          bmp.close();
          return '';
        }
      }
    } catch (e) {}

    try {
      const w = imgEl.naturalWidth || imgEl.width || 0;
      const h = imgEl.naturalHeight || imgEl.height || 0;
      if (w < 200 || h < 120) return '';
      return encodeSourceToSafePngDataUrl(imgEl, w, h);
    } catch (e) {
      return '';
    }
  }

  // Strictly saves an image via background.js chrome.downloads.download and WAITS for confirmed disk save!
  async function saveImageToDiskAndConfirm(opts) {
    const {
      imgEl,
      initialDataUrl,
      sceneNum,
      grandTotal,
      folderName,
      fileNameFormat,
      jobId,
      userEmail
    } = opts;

    let dataUrl = initialDataUrl || '';
    for (let attempt = 1; attempt <= 3; attempt++) {
      if (!dataUrl && imgEl) {
        dataUrl = await extractImageAsDataUrl(imgEl);
      }
      if (!dataUrl && imgEl && !imgEl.src) {
        await sleep(400);
        continue;
      }

      const saveResp = await new Promise((resolve) => {
        try {
          chrome.runtime.sendMessage(
            {
              action: 'SAVE_GENERATED_IMAGE',
              job_id: jobId || '',
              sceneNum: Number(sceneNum),
              total: Number(grandTotal) || 161,
              grandTotal: Number(grandTotal) || 161,
              folderName: folderName || 'new video images',
              fileNameFormat: fileNameFormat || 'i 1',
              imgUrl: (imgEl && imgEl.src) || '',
              dataUrl: dataUrl || ''
            },
            (resp) => {
              const _err = chrome.runtime.lastError;
              resolve(resp || { ok: false, saved: false });
            }
          );
        } catch (e) {
          resolve({ ok: false, saved: false });
        }
      });

      if (saveResp && saveResp.ok && saveResp.saved) {
        const updatedSet = await markSceneSavedLocally(folderName, sceneNum);
        if (userEmail) {
          const fmtFileName = formatSceneFileName(sceneNum, fileNameFormat || 'i 1');
          directPostCloud({
            action: 'bot_queue_update',
            email: userEmail,
            sceneNum: Number(sceneNum),
            savedSceneNums: Array.from(updatedSet),
            grandTotal: Number(grandTotal) || 161,
            folderName: folderName || 'new video images',
            dataUrl: dataUrl || '',
            status: 'running',
            statusText: `✅ Saved & Synced ${fmtFileName} in Downloads/${folderName} (${updatedSet.size} / ${grandTotal} Saved)`
          });
        }
        return saveResp;
      }

      // Wait briefly and re-extract before retry
      await sleep(500);
      if (imgEl) {
        dataUrl = await extractImageAsDataUrl(imgEl);
      }
    }
    return { ok: false, saved: false };
  }

  // Parse all (sceneNum -> model-response element) pairs currently mounted in the open Gemini chat DOM
  function collectChatSceneResponsePairsInDom() {
    const map = new Map();
    const nodes = Array.from(
      document.querySelectorAll('user-query, .user-query-container, [data-test-id*="user-query"], model-response')
    );
    let currentSceneNum = null;
    for (const node of nodes) {
      const tag = String(node.tagName || '').toLowerCase();
      if (tag === 'model-response') {
        let sNum = currentSceneNum;
        if (!sNum) {
          const container = node.closest('.conversation-container, [class*="conversation-turn"]') || node.parentElement;
          if (container) {
            const uq = container.querySelector('user-query, .user-query-container, .query-text');
            if (uq) {
              const m = String(uq.innerText || uq.textContent || '').match(/\bImage\s+(\d{1,4})\b/i);
              if (m) sNum = parseInt(m[1], 10);
            }
          }
        }
        if (sNum && sNum > 0) {
          const newHasImg = Boolean(
            findGeneratedImageInResponse(node) || node.querySelector('generated-image, single-image')
          );
          if (!map.has(sNum) || newHasImg) {
            map.set(sNum, node);
          }
        }
      } else {
        const txt = String(node.innerText || node.textContent || '');
        const m = txt.match(/\bImage\s+(\d{1,4})\b/i);
        if (m) {
          currentSceneNum = parseInt(m[1], 10);
        }
      }
    }
    return map;
  }

  function getScrollableChatAncestors() {
    const list = [];
    const seen = new Set();
    function add(el) {
      if (!el || seen.has(el)) return;
      seen.add(el);
      list.push(el);
    }
    const sampleTurn = document.querySelector('model-response, user-query, .user-query-container');
    let cur = sampleTurn ? sampleTurn.parentElement : null;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      if (cur.scrollHeight > cur.clientHeight + 20) {
        add(cur);
      }
      cur = cur.parentElement;
    }
    document
      .querySelectorAll('infinite-scroller.chat-history, infinite-scroller, [data-test-id="chat-history-container"], main')
      .forEach(add);
    if (document.scrollingElement) add(document.scrollingElement);
    return list;
  }

  // Pull full prompts from cloud if local job only has a partial queue, and sort prompts strictly 1..N
  async function ensureFullSortedPromptsInJob(job, userEmail) {
    if (!job) return job;
    try {
      const expectedTotal = Math.max(Number(job.grandTotal) || 0, Array.isArray(job.prompts) ? job.prompts.length : 0);
      if (userEmail && (!Array.isArray(job.prompts) || job.prompts.length === 0 || (expectedTotal > 0 && job.prompts.length < expectedTotal))) {
        const res = await directPostCloud({ action: 'bot_queue_poll', email: userEmail });
        const cJob = res && res.job ? res.job : null;
        if (cJob && (!job.job_id || cJob.job_id === job.job_id)) {
          const cloudFull = Array.isArray(cJob.allPrompts) && cJob.allPrompts.length > 0
            ? cJob.allPrompts
            : (Array.isArray(cJob.prompts) ? cJob.prompts : []);
          if (cloudFull.length > 0) {
            const byScene = new Map();
            if (Array.isArray(job.prompts)) {
              job.prompts.forEach((p, idx) => {
                const sn = Number(p && p.sceneNum) || (idx + 1);
                byScene.set(sn, p);
              });
            }
            cloudFull.forEach((p, idx) => {
              const sn = Number(p && p.sceneNum) || (idx + 1);
              if (!byScene.has(sn)) byScene.set(sn, p);
            });
            job.prompts = Array.from(byScene.entries())
              .sort((a, b) => a[0] - b[0])
              .map((entry) => entry[1]);
          }
          if (!job.refImageDataUrl && cJob.refImageUrl) {
            job.refImageDataUrl = await fetchUrlAsDataUrl(cJob.refImageUrl);
            job.attachRefImage = true;
          }
        }
      }
      if (Array.isArray(job.prompts) && job.prompts.length > 1) {
        const byScene = new Map();
        job.prompts.forEach((p, idx) => {
          const sn = Number(p && p.sceneNum) || (idx + 1);
          if (!byScene.has(sn)) byScene.set(sn, p);
        });
        job.prompts = Array.from(byScene.entries())
          .sort((a, b) => a[0] - b[0])
          .map((entry) => entry[1]);
      }
    } catch (e) {}
    return job;
  }

  // Scan the ENTIRE open Gemini chat, save any generated images that are NOT saved in Downloads/<folderName> WITHOUT regenerating,
  // and optionally auto-continue generating remaining images right after!
  async function scanAndSaveExistingChatImages(manualTrigger = false, autoContinueAfterSave = false) {
    if (isRecoveringChatImages) return 0;
    isRecoveringChatImages = true;
    const recoverBtn = document.getElementById('vsBotRecoverChatBtn');
    if (recoverBtn) {
      recoverBtn.disabled = true;
      recoverBtn.textContent = '⏳ Scanning Full Chat & Saving Unsaved Images...';
    }

    let newlySavedCount = 0;
    try {
      const userEmail = getTabEmail();
      const jobKey = getTabJobStorageKey(userEmail);
      const stData = await chrome.storage.local.get([jobKey, 'geminiBatchJob']);
      let job = stData[jobKey] || stData.geminiBatchJob || null;
      if (job) {
        job = await ensureFullSortedPromptsInJob(job, userEmail);
      }

      const folderName = (job && job.folderName) || 'new video images';
      const fileNameFormat = (job && job.fileNameFormat) || '1';
      const jobId = (job && job.job_id) || '';

      let savedSet = await getSavedSceneSetForFolder(folderName);
      const grandTotal = Math.max(
        Number(job && job.grandTotal) || 0,
        (job && Array.isArray(job.prompts) ? job.prompts.length : 0),
        savedSet.size,
        1
      );

      async function saveCurrentlyMountedUnsavedTurns() {
        const pairsMap = collectChatSceneResponsePairsInDom();
        const mountedUnsaved = Array.from(pairsMap.keys())
          .filter((sNum) => !savedSet.has(sNum))
          .sort((a, b) => a - b);

        for (const sNum of mountedUnsaved) {
          if (stopRequested) break;
          if (savedSet.has(sNum)) continue;
          const respEl = pairsMap.get(sNum);
          if (!respEl || !respEl.isConnected) continue;

          try {
            respEl.scrollIntoView({ behavior: 'instant', block: 'center' });
          } catch (e) {}

          let imgEl = null;
          for (let w = 0; w < 12; w++) {
            await sleep(220);
            imgEl = findGeneratedImageInResponse(respEl);
            if (imgEl && imgEl.complete && (imgEl.naturalWidth || imgEl.width || 0) >= 200) {
              break;
            }
          }
          if (!imgEl) continue;

          const fmtFileName = formatSceneFileName(sNum, fileNameFormat);
          updateBotUI(
            `💾 Saving Chat Image ${sNum} (${fmtFileName}) to Downloads/${folderName} (Bina Dubara Banaye)...`,
            savedSet.size,
            grandTotal,
            true
          );

          const saveRes = await saveImageToDiskAndConfirm({
            imgEl,
            initialDataUrl: '',
            sceneNum: sNum,
            grandTotal,
            folderName,
            fileNameFormat,
            jobId,
            userEmail
          });

          if (saveRes && saveRes.ok && saveRes.saved) {
            savedSet.add(sNum);
            newlySavedCount++;
            updateBotUI(
              `✅ Saved Chat Image ${fmtFileName}! (${savedSet.size} / ${grandTotal} Saved in Downloads/${folderName})`,
              savedSet.size,
              grandTotal,
              true
            );
            await sleep(180);
          }
        }
      }

      await saveCurrentlyMountedUnsavedTurns();

      let unchangedSteps = 0;
      const maxScrollSteps = manualTrigger ? 42 : 28;
      for (let step = 0; step < maxScrollSteps; step++) {
        if (stopRequested || savedSet.size >= grandTotal) break;

        const beforeSig = Array.from(collectChatSceneResponsePairsInDom().keys()).join(',');
        const scrollers = getScrollableChatAncestors();
        const topTurn = document.querySelector('user-query, .user-query-container, model-response');

        if (topTurn) {
          try {
            topTurn.scrollIntoView({ behavior: 'instant', block: 'start' });
          } catch (e) {}
        }

        let anyScrolled = false;
        for (const sc of scrollers) {
          if (sc && sc.scrollTop > 5) {
            const prevTop = sc.scrollTop;
            sc.scrollTop = Math.max(0, sc.scrollTop - Math.max(950, Math.floor((sc.clientHeight || 700) * 0.9)));
            try {
              sc.dispatchEvent(new Event('scroll', { bubbles: true }));
              sc.dispatchEvent(new WheelEvent('wheel', { deltaY: -900, bubbles: true }));
            } catch (e) {}
            if (sc.scrollTop < prevTop) anyScrolled = true;
          }
        }

        await sleep(480);
        await saveCurrentlyMountedUnsavedTurns();

        const afterSig = Array.from(collectChatSceneResponsePairsInDom().keys()).join(',');
        if (afterSig === beforeSig && !anyScrolled) {
          unchangedSteps++;
          if (unchangedSteps >= 3) break;
        } else {
          unchangedSteps = 0;
        }
      }

      try {
        const scrollers = getScrollableChatAncestors();
        for (const sc of scrollers) {
          if (sc && sc.scrollHeight > sc.clientHeight) {
            sc.scrollTop = sc.scrollHeight;
          }
        }
        const allResps = document.querySelectorAll('model-response, user-query');
        if (allResps.length > 0) {
          allResps[allResps.length - 1].scrollIntoView({ behavior: 'instant', block: 'end' });
        }
      } catch (e) {}

      if (userEmail) {
        directPostCloud({
          action: 'bot_queue_update',
          email: userEmail,
          savedSceneNums: Array.from(savedSet),
          grandTotal: grandTotal,
          folderName: folderName,
          status: 'running',
          statusText: `✅ ${savedSet.size} / ${grandTotal} Images Saved in Downloads/${folderName}`
        });
      }

      if (newlySavedCount > 0) {
        updateBotUI(
          `✅ ${newlySavedCount} Unsaved Chat Images Saved to Downloads/${folderName}! Total Saved: ${savedSet.size} / ${grandTotal}.`,
          savedSet.size,
          grandTotal,
          true
        );
      } else {
        updateBotUI(
          `✅ ${savedSet.size} / ${grandTotal} Images Saved in Downloads/${folderName}.`,
          savedSet.size,
          grandTotal,
          true
        );
      }

      if (autoContinueAfterSave && !stopRequested && savedSet.size < grandTotal) {
        isRecoveringChatImages = false;
        if (recoverBtn) {
          recoverBtn.disabled = false;
          recoverBtn.textContent = '🚀 Start / Resume Auto Image Generation';
        }
        if (job) {
          job.active = true;
          job.paused = false;
          job.currentIndex = 0;
          await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job });
        }
        pauseRequested = false;
        pauseStartedAt = 0;
        stopRequested = false;
        if (!isLoopRunning) {
          processQueue(true);
        }
        return newlySavedCount;
      }

      return newlySavedCount;
    } catch (e) {
      return newlySavedCount;
    } finally {
      isRecoveringChatImages = false;
      if (recoverBtn) {
        recoverBtn.disabled = false;
        recoverBtn.textContent = '🚀 Start / Resume Auto Image Generation';
      }
    }
  }

  function scrollToBottomOfGeminiChat() {
    try {
      const scrollers = getScrollableChatAncestors();
      for (const sc of scrollers) {
        if (sc && sc.scrollHeight > sc.clientHeight) {
          sc.scrollTop = sc.scrollHeight;
        }
      }
      const allTurns = document.querySelectorAll('model-response, user-query');
      if (allTurns.length > 0) {
        allTurns[allTurns.length - 1].scrollIntoView({ behavior: 'instant', block: 'end' });
      }
    } catch (e) {}
  }

  function tryStartFreshGeminiChatInPlace() {
    try {
      const newChatSelectors = [
        'a[href="/app"]',
        'a[href^="https://gemini.google.com/app"]',
        '[data-test-id="new-chat-button"]',
        'button[aria-label*="New chat"]',
        'button[mattooltip*="New chat"]'
      ];
      for (const sel of newChatSelectors) {
        const el = document.querySelector(sel);
        if (el && (el.offsetParent !== null || document.hidden)) {
          el.click();
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  async function processQueue() {
    if (isLoopRunning) return;
    isLoopRunning = true;
    stopRequested = false;
    startSilentAudioKeepAlive();

    const retryCountsByScene = new Map();

    try {
      ensureBotUI();
      scrollToBottomOfGeminiChat();

      let editor = null;
      for (let t = 0; t < 35; t++) {
        editor = findGeminiEditor();
        if (editor) break;
        await sleep(300);
      }
      if (!editor) {
        isLoopRunning = false;
        stopSilentAudioKeepAlive();
        return;
      }

      let didEnsureFullPrompts = false;

      while (!stopRequested) {
        if (pauseRequested) {
          if (!pauseStartedAt) pauseStartedAt = Date.now();
          // Auto-Resume Watchdog: if paused for >= 7 seconds without Stop, automatically resume!
          if (Date.now() - pauseStartedAt >= 7000) {
            pauseRequested = false;
            pauseStartedAt = 0;
            updateBotUI(`▶️ Auto-Resumed at ${lastKnownCompleted} / ${lastKnownTotal} Saved — Continuing...`, lastKnownCompleted, lastKnownTotal, true);
          } else {
            await sleep(400);
            continue;
          }
        }

        const userEmail = getTabEmail();
        const jobKey = getTabJobStorageKey(userEmail);
        const compKey = getTabCompletedJobStorageKey(userEmail);
        const stored = await chrome.storage.local.get([jobKey, 'geminiBatchJob']);
        let job = stored[jobKey] || stored.geminiBatchJob;

        if (!job || !job.active) {
          break;
        }

        if (!didEnsureFullPrompts) {
          didEnsureFullPrompts = true;
          job = await ensureFullSortedPromptsInJob(job, userEmail);
        }

        if (!Array.isArray(job.prompts) || job.prompts.length === 0) {
          break;
        }

        const folderName = job.folderName || 'VideoStudio_Scenes';
        const fileNameFormat = job.fileNameFormat || '1';
        const savedSet = await getSavedSceneSetForFolder(folderName);
        const maxSceneNumInPrompts = job.prompts.reduce((mx, p, i) => Math.max(mx, Number(p && p.sceneNum) || (i + 1)), job.prompts.length);
        const grandTotal = Math.max(Number(job.grandTotal) || 0, maxSceneNumInPrompts, savedSet.size);

        // Strictly find the first unsaved image (1..N) in sequential order
        const firstUnsavedIdx = job.prompts.findIndex((candidateItem, idxPos) => {
          const candidateSceneNum = Number(candidateItem && candidateItem.sceneNum) || (idxPos + 1);
          return !savedSet.has(candidateSceneNum);
        });
        job.currentIndex = firstUnsavedIdx >= 0 ? firstUnsavedIdx : job.prompts.length;
        await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job });

        if (job.currentIndex >= job.prompts.length) {
          job.active = false;
          try { sessionStorage.removeItem('vs_gemini_auto_resume_on_load'); } catch (e) {}
          await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job, [compKey]: job.job_id || '' });
          updateBotUI(
            `✅ All ${savedSet.size} / ${grandTotal} Images Generated, Confirmed Saved to Downloads/${folderName} & Synced to Studio!`,
            savedSet.size,
            grandTotal,
            true
          );
          if (userEmail) {
            await directPostCloud({
              action: 'bot_queue_update',
              email: userEmail,
              savedSceneNums: Array.from(savedSet),
              grandTotal: grandTotal,
              folderName: folderName,
              active: false,
              status: 'completed',
              statusText: `🎉 All ${savedSet.size} / ${grandTotal} Images Generated in Gemini & Saved to Downloads/${folderName}!`
            });
          }
          chrome.runtime.sendMessage({
            action: 'BATCH_COMPLETED',
            email: userEmail,
            total: grandTotal,
            grandTotal: grandTotal,
            folderName: folderName
          });
          break;
        }

        const idx = job.currentIndex;
        const item = job.prompts[idx];
        const sceneNum = Number(item.sceneNum) || (idx + 1);
        const fmtFileName = formatSceneFileName(sceneNum, fileNameFormat);
        skipCurrentRequested = false;

        const startBtnEl = document.getElementById('vsBotRecoverChatBtn');
        if (startBtnEl) {
          startBtnEl.textContent = `🚀 Running: Image ${sceneNum} / ${grandTotal} (Downloads/${folderName})`;
        }

        scrollToBottomOfGeminiChat();

        // Wait if Gemini is still finishing any previous response before pasting the next prompt
        for (let wPrev = 0; wPrev < 25; wPrev++) {
          if (!isGeminiStillGenerating() || stopRequested) break;
          await sleep(400);
        }

        const statusMsg = `🎨 Generating Image ${sceneNum} (${fmtFileName}) — [${savedSet.size} / ${grandTotal} Saved in Downloads/${folderName}]...`;
        updateBotUI(statusMsg, savedSet.size, grandTotal, true);

        if (userEmail) {
          directPostCloud({
            action: 'bot_queue_update',
            email: userEmail,
            currentIndex: idx,
            savedSceneNums: Array.from(savedSet),
            grandTotal: grandTotal,
            folderName: folderName,
            status: 'running',
            statusText: statusMsg
          });
        }
        chrome.runtime.sendMessage({
          action: 'REPORT_PROGRESS',
          job_id: job.job_id,
          currentIndex: idx,
          sceneNum: sceneNum,
          savedCount: savedSet.size,
          total: grandTotal,
          grandTotal: grandTotal,
          statusText: statusMsg
        });

        editor = findGeminiEditor();
        if (!editor) {
          await sleep(500);
          continue;
        }

        // MANDATORY RULE: Always attach the Reference Image with EVERY SINGLE PROMPT (1..N)!
        const refDataUrlToAttach = await getGuaranteedWhiteCharRefDataUrl(job);
        if (refDataUrlToAttach) {
          updateBotUI(`🧑 Attaching Reference Image + Exact Prompt for Image ${sceneNum} (${savedSet.size} / ${grandTotal} Saved)...`, savedSet.size, grandTotal, true);
        }

        if (stopRequested) break;

        const beforeImgs = getExistingGeneratedImageSrcs();
        const beforeRespCount = document.querySelectorAll('model-response').length;
        const fullPromptToSend = buildFullPromptMessageWithScript(item, idx);
        await setEditorTextAndSend(editor, fullPromptToSend, refDataUrlToAttach, Boolean(refDataUrlToAttach));

        let foundImg = null;
        let extractedDataUrl = '';
        let hitLimitOrError = '';
        const startWait = Date.now();
        await sleep(1200);

        while (Date.now() - startWait < 95000 && !stopRequested && !skipCurrentRequested) {
          if (pauseRequested) {
            if (!pauseStartedAt) pauseStartedAt = Date.now();
            if (Date.now() - pauseStartedAt >= 7000) {
              pauseRequested = false;
              pauseStartedAt = 0;
            } else {
              await sleep(400);
              continue;
            }
          }
          const candidate = findNewlyGeneratedImage(beforeImgs);
          if (candidate) {
            await sleep(450);
            const verifyCand = findNewlyGeneratedImage(beforeImgs) || candidate;
            const dUrl = await extractImageAsDataUrl(verifyCand);
            if (dUrl) {
              foundImg = verifyCand;
              extractedDataUrl = dUrl;
              break;
            }
          }

          // Check if Gemini displayed a rate limit / quota reset / error message
          if (Date.now() - startWait > 4500) {
            const errTxt = detectGeminiRateLimitOrError(beforeRespCount);
            if (errTxt) {
              hitLimitOrError = errTxt;
              break;
            }
          }

          if (Date.now() - startWait > 55000 && !isGeminiStillGenerating()) {
            await sleep(800);
            const lateCand = findNewlyGeneratedImage(beforeImgs);
            if (lateCand) {
              const dUrl = await extractImageAsDataUrl(lateCand);
              if (dUrl) {
                foundImg = lateCand;
                extractedDataUrl = dUrl;
              }
            }
            break;
          }
          await sleep(450);
        }

        if (stopRequested) break;

        // If user clicked Skip manually
        if (skipCurrentRequested) {
          job.currentIndex = idx + 1;
          await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job });
          continue;
        }

        // 1. STRICT STOP & RATE LIMIT / ERROR HANDLING
        if (hitLimitOrError || !foundImg) {
          clickGeminiStopButtonIfGenerating();

          const isRateLimit = /limit|quota|too many requests|try again (?:tomorrow|later|in)|can(?:'t|not) (?:generate|create) (?:more )?images|unable to (?:create|generate)/i.test(String(hitLimitOrError || ''));

          // REQUIREMENT: Agar image limit ya quota hit ho jaye -> STOP IMMEDIATELY!
          if (isRateLimit) {
            stopRequested = true;
            pauseRequested = false;
            pauseStartedAt = 0;
            isLoopRunning = false;
            stopSilentAudioKeepAlive();
            try { sessionStorage.removeItem('vs_gemini_auto_resume_on_load'); } catch (e) {}

            job.active = false;
            await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job });

            const limitMsg = `🛑 Gemini Image Limit Reached: "${hitLimitOrError || 'Daily/Hourly Limit'}". Automation STOPPED cleanly.`;
            updateBotUI(limitMsg, savedSet.size, grandTotal, true);

            if (userEmail) {
              await directPostCloud({
                action: 'bot_queue_update',
                email: userEmail,
                currentIndex: idx,
                savedSceneNums: Array.from(savedSet),
                grandTotal: grandTotal,
                folderName: folderName,
                active: false,
                status: 'stopped_limit',
                statusText: limitMsg
              });
            }
            break;
          }

          // REQUIREMENT: Agar image nahi bani (limit error nahi hai, koi doosra issue hai):
          // Pehli dfa nahi bani -> Dubara try karey (Attempt 2).
          // Phir bhi nahi bani -> Ek dafa aur karey (Attempt 3).
          // Agar 3 dafa try karke bhi nahi bani -> STOP ho jaye taake loop na banei!
          const attemptCount = (retryCountsByScene.get(sceneNum) || 0) + 1;
          retryCountsByScene.set(sceneNum, attemptCount);

          if (attemptCount >= 3) {
            stopRequested = true;
            pauseRequested = false;
            pauseStartedAt = 0;
            isLoopRunning = false;
            stopSilentAudioKeepAlive();
            try { sessionStorage.removeItem('vs_gemini_auto_resume_on_load'); } catch (e) {}

            job.active = false;
            await chrome.storage.local.set({ [jobKey]: job, geminiBatchJob: job });

            const failMsg = `🛑 Image ${sceneNum} 3 dafa try karne ke baad bhi nahi ban saki (${hitLimitOrError || 'No image generated'}). Loop se bachne ke liye Automation STOP kar di gayi hai.`;
            updateBotUI(failMsg, savedSet.size, grandTotal, true);

            if (userEmail) {
              await directPostCloud({
                action: 'bot_queue_update',
                email: userEmail,
                currentIndex: idx,
                savedSceneNums: Array.from(savedSet),
                grandTotal: grandTotal,
                folderName: folderName,
                active: false,
                status: 'stopped_failed',
                statusText: failMsg
              });
            }
            break;
          }

          // Abhi retries baqi hain (Attempt 1 ya 2): 5s wait karein aur retry karein
          pauseRequested = true;
          pauseStartedAt = Date.now();

          for (let rem = 5; rem >= 1; rem--) {
            if (stopRequested) break;
            const retryMsg = `⏳ Image ${sceneNum} nahi bani (${hitLimitOrError || 'temporary delay'}). Dubara koshish (Attempt #${attemptCount + 1} of 3) ${rem}s mein ho rahi hai...`;
            updateBotUI(retryMsg, savedSet.size, grandTotal, true);
            await sleep(1000);
          }

          pauseRequested = false;
          pauseStartedAt = 0;

          if (stopRequested) break;

          editor = findGeminiEditor();
          continue;
        }

        // STRICT RULE: Save the generated image to disk and WAIT for confirmed disk completion BEFORE moving to next image!
        updateBotUI(
          `💾 Saving Image ${sceneNum} (${fmtFileName}) to Downloads/${folderName} — Waiting for Strict Disk Confirmation...`,
          savedSet.size,
          grandTotal,
          true
        );

        const saveResult = await saveImageToDiskAndConfirm({
          imgEl: foundImg,
          initialDataUrl: extractedDataUrl,
          sceneNum: sceneNum,
          grandTotal: grandTotal,
          folderName: folderName,
          fileNameFormat: fileNameFormat,
          jobId: job.job_id,
          userEmail: userEmail
        });

        if (!saveResult || !saveResult.ok || !saveResult.saved) {
          const failSaveMsg = `⏳ Image ${sceneNum} (${fmtFileName}) save retry ho rahi hai 4s mein (${savedSet.size} / ${grandTotal} Saved)...`;
          updateBotUI(failSaveMsg, savedSet.size, grandTotal, true);
          await sleep(4000);
          continue;
        }

        // Confirmed saved to disk in selected folder! Now and ONLY now mark saved and move to the next image.
        retryCountsByScene.delete(sceneNum);
        savedSet.add(sceneNum);
        const latestStored = await chrome.storage.local.get([jobKey]);
        const updatedJob = latestStored[jobKey] || job;
        updatedJob.currentIndex = idx + 1;
        await chrome.storage.local.set({ [jobKey]: updatedJob, geminiBatchJob: updatedJob });

        updateBotUI(
          `✅ Confirmed Saved ${fmtFileName} (${savedSet.size} / ${grandTotal} Saved in Downloads/${folderName}) — Starting Next Image...`,
          savedSet.size,
          grandTotal,
          true
        );

        await sleep(600);
      }
    } finally {
      isLoopRunning = false;
      stopSilentAudioKeepAlive();
    }
  }

  function applyAutoCapturedEmailUI(capturedEmail, forceFromStudio = false) {
    const clean = String(capturedEmail || '').trim().toLowerCase();
    if (!clean || !clean.includes('@')) return;
    if (!forceFromStudio && sessionStorage.getItem('vs_bot_manual_disconnected') === '1') {
      return;
    }
    if (forceFromStudio) {
      try { sessionStorage.removeItem('vs_bot_manual_disconnected'); } catch (e) {}
    }
    setTabEmail(clean, false);
    const inp = document.getElementById('vsBotStudioEmailInput');
    const bdg = document.getElementById('vsBotEmailBadge');
    const isUserTyping = inp && (document.activeElement === inp || inp.dataset.userEditing === '1');
    if (inp && (!isUserTyping || forceFromStudio) && inp.value !== clean) {
      inp.value = clean;
      if (forceFromStudio) delete inp.dataset.userEditing;
    }
    if (bdg && (!isUserTyping || forceFromStudio)) {
      bdg.textContent = '● Connected';
      bdg.style.color = '#34d399';
    }
  }

  let initialCloudJobIdOnPageLoad = null;
  let hasCheckedInitialCloudJob = false;

  let isCheckingCloudQueue = false;
  async function checkCloudQueueDirectFallback() {
    ensureBotUI();
    if (isCheckingCloudQueue) return;
    isCheckingCloudQueue = true;
    try {
      let email = getTabEmail();
      if (!email) {
        try {
          const stEm = await chrome.storage.local.get(['studioUserEmail']);
          if (stEm && stEm.studioUserEmail && String(stEm.studioUserEmail).includes('@')) {
            email = String(stEm.studioUserEmail).trim().toLowerCase();
            applyAutoCapturedEmailUI(email);
          }
        } catch (e) {}
      }
      heartbeatTabClaim(email);

      const res = await directPostCloud({ action: 'bot_queue_poll', email });
      const serverBoundEmail = (res && res.bound_email && res.bound_email.includes('@')) ? String(res.bound_email).trim().toLowerCase() : '';
      if (!email) {
        if (res && Array.isArray(res.connected_emails) && res.connected_emails.length > 0) {
          const distinctEmail = resolveDistinctTabEmail(res.connected_emails, serverBoundEmail);
          if (distinctEmail) {
            email = distinctEmail;
            applyAutoCapturedEmailUI(email);
            const res2 = await directPostCloud({ action: 'bot_queue_poll', email });
            if (res2) Object.assign(res, res2);
          }
        } else if (serverBoundEmail) {
          const distinctEmail = resolveDistinctTabEmail([serverBoundEmail], serverBoundEmail);
          if (distinctEmail) {
            email = distinctEmail;
            applyAutoCapturedEmailUI(email);
          }
        }
      } else {
        applyAutoCapturedEmailUI(email);
      }
      if (!email) return;

      const jobKey = getTabJobStorageKey(email);
      const compKey = getTabCompletedJobStorageKey(email);
      const stored = await chrome.storage.local.get([jobKey, compKey]);
      const cloudJob = res && res.job ? res.job : null;
      const localJob = stored[jobKey] || null;
      const lastCompletedId = stored[compKey] || '';

      if (!hasCheckedInitialCloudJob) {
        hasCheckedInitialCloudJob = true;
        initialCloudJobIdOnPageLoad = cloudJob && cloudJob.job_id ? cloudJob.job_id : '';
      }

      if (cloudJob && cloudJob.email && String(cloudJob.email).trim().toLowerCase() !== email) {
        return;
      }

      if (!cloudJob || !cloudJob.active || !Array.isArray(cloudJob.prompts) || cloudJob.prompts.length === 0) {
        if (localJob && localJob.active && localJob.job_id && cloudJob && cloudJob.job_id === localJob.job_id && cloudJob.status === 'stopped') {
          localJob.active = false;
          await chrome.storage.local.set({ [jobKey]: localJob, [compKey]: localJob.job_id });
          if (isLoopRunning) {
            stopRequested = true;
            clickGeminiStopButtonIfGenerating();
            updateBotUI(`🛑 Stopped from Video Studio (${lastKnownCompleted} / ${lastKnownTotal}).`, lastKnownCompleted, lastKnownTotal, true);
          }
        }
        return;
      }

      if (lastCompletedId && cloudJob.job_id === lastCompletedId) {
        return;
      }

      const isBrandNewJobAfterLoad =
        (!localJob || localJob.job_id !== cloudJob.job_id) &&
        cloudJob.job_id !== initialCloudJobIdOnPageLoad;

      if (isBrandNewJobAfterLoad && (cloudJob.currentIndex || 0) < cloudJob.prompts.length) {
        let refDataUrl = '';
        const refUrlToFetch = cloudJob.refImageUrl || DEFAULT_REF_IMAGE_URL;
        refDataUrl = await fetchUrlAsDataUrl(refUrlToFetch);
        const cleanFolder = String(cloudJob.folderName || 'VideoStudio_Scenes').replace(/[^a-zA-Z0-9_\- ]+/g, '_').trim() || 'VideoStudio_Scenes';
        if (Array.isArray(cloudJob.savedSceneNums)) {
          const fKey = normalizeFolderKey(cleanFolder);
          const stMap = await chrome.storage.local.get(['savedScenesByFolder']);
          const map = (stMap && stMap.savedScenesByFolder && typeof stMap.savedScenesByFolder === 'object') ? stMap.savedScenesByFolder : {};
          map[fKey] = cloudJob.savedSceneNums.map(Number).filter(n => n > 0).sort((a, b) => a - b);
          await chrome.storage.local.set({ savedScenesByFolder: map });
        }
        const savedSet = await getSavedSceneSetForFolder(cleanFolder);
        const maxSceneNum = cloudJob.prompts.reduce((mx, p, i) => Math.max(mx, Number(p && p.sceneNum) || (i + 1)), cloudJob.prompts.length);
        const grandTotal = Math.max(Number(cloudJob.grandTotal) || 0, maxSceneNum, savedSet.size);

        const newLocalJob = {
          job_id: cloudJob.job_id || ('job_' + Date.now()),
          email: email,
          active: true,
          paused: false,
          studioTabId: null,
          folderName: cleanFolder,
          fileNameFormat: String(cloudJob.fileNameFormat || '1').trim(),
          prompts: cloudJob.prompts,
          grandTotal: grandTotal,
          refImageDataUrl: refDataUrl,
          attachRefImage: true,
          currentIndex: Number(cloudJob.currentIndex) || 0,
          startedAt: Date.now()
        };
        await chrome.storage.local.set({ [jobKey]: newLocalJob, geminiBatchJob: newLocalJob });
        stopRequested = false;
        pauseRequested = false;
        pauseStartedAt = 0;
        if (!isLoopRunning) {
          processQueue();
        }
      }
    } catch (e) {
    } finally {
      isCheckingCloudQueue = false;
    }
  }

  function checkCloudQueueOnce() {
    ensureBotUI();
    checkCloudQueueDirectFallback();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.action === 'BG_HEARTBEAT_TICK') {
      checkCloudQueueOnce();
      sendResponse({ ok: true });
    } else if (msg.action === 'START_OR_RESUME_QUEUE') {
      stopRequested = false;
      pauseRequested = false;
      pauseStartedAt = 0;
      processQueue();
      sendResponse({ ok: true });
    } else if (msg.action === 'STOP_QUEUE') {
      stopRequested = true;
      pauseRequested = false;
      pauseStartedAt = 0;
      isLoopRunning = false;
      try { sessionStorage.removeItem('vs_gemini_auto_resume_on_load'); } catch (e) {}
      clickGeminiStopButtonIfGenerating();
      stopSilentAudioKeepAlive();
      const email = getTabEmail();
      const jobKey = getTabJobStorageKey(email);
      chrome.storage.local.get([jobKey, 'geminiBatchJob'], (stData) => {
        const j = (stData && (stData[jobKey] || stData.geminiBatchJob));
        if (j) {
          j.active = false;
          chrome.storage.local.set({ [jobKey]: j, geminiBatchJob: j });
        }
      });
      updateBotUI('🛑 Stopped immediately by Studio command.', lastKnownCompleted, lastKnownTotal, true);
      sendResponse({ ok: true });
    } else if (msg.action === 'CLEAN_RESET_BOT_UI') {
      cleanResetBotState(false);
      sendResponse({ ok: true });
    } else if (msg.action === 'SYNC_EMAIL_FROM_STUDIO' && msg.email) {
      applyAutoCapturedEmailUI(msg.email, true);
      checkCloudQueueOnce();
      sendResponse({ ok: true });
    }
    return true;
  });

  ensureBotUI();
  setInterval(ensureBotUI, 1500);

  setTimeout(async () => {
    ensureBotUI();
    try {
      const email = getTabEmail();
      const jobKey = getTabJobStorageKey(email);
      const stored = await chrome.storage.local.get([jobKey, 'geminiBatchJob']);
      const job = stored[jobKey] || stored.geminiBatchJob || null;
      const isJobActive = Boolean(job && job.active && Array.isArray(job.prompts) && job.prompts.length > 0);
      if (!isJobActive) {
        const startBtnEl = document.getElementById('vsBotRecoverChatBtn');
        if (startBtnEl) {
          startBtnEl.textContent = '🚀 Start / Resume Auto Image Generation';
        }
        updateBotUI('🟢 Ready! Video Studio se Auto-Generate start karein.', 0, 0, true);
        return;
      }
      const folderName = (job && job.folderName) || 'VideoStudio_Scenes';
      const savedSet = await getSavedSceneSetForFolder(folderName);
      const grandTotal = Math.max(
        Number(job && job.grandTotal) || 0,
        (job && Array.isArray(job.prompts) ? job.prompts.length : 0),
        savedSet.size
      );
      let nextScene = 1;
      for (let s = 1; s <= Math.max(1, grandTotal); s++) {
        if (!savedSet.has(s)) {
          nextScene = s;
          break;
        }
      }
      const startBtnEl = document.getElementById('vsBotRecoverChatBtn');
      if (startBtnEl) {
        startBtnEl.textContent = grandTotal > 0
          ? `🚀 Start / Resume From Image ${nextScene} (${savedSet.size} / ${grandTotal} Saved)`
          : '🚀 Start / Resume Auto Image Generation';
      }
      updateBotUI(
        grandTotal > 0
          ? `🟢 Ready (${savedSet.size} / ${grandTotal} Saved in Downloads/${folderName})!`
          : '🟢 Ready! Video Studio se Auto-Generate start karein.',
        savedSet.size,
        grandTotal,
        true
      );

      // If this tab was just opened by START_BATCH or reloaded by Auto-Resume self-healing, start immediately!
      const autoResumeFlag = sessionStorage.getItem('vs_gemini_auto_resume_on_load') === '1';
      const isFreshBatchTab = Boolean(job && job.active && !job.paused && Date.now() - Number(job.startedAt || 0) < 90000);
      if (autoResumeFlag || isFreshBatchTab) {
        try { sessionStorage.removeItem('vs_gemini_auto_resume_on_load'); } catch (e) {}
        stopRequested = false;
        pauseRequested = false;
        pauseStartedAt = 0;
        processQueue();
      }
    } catch (e) {}
    setInterval(checkCloudQueueOnce, 2200);
  }, 400);
})();
