// Perfected Master Shots for GTA 6 Episode 1 with Black Tactical Gear & Active City Life
window.__GTA6_EP1_SHOTS = [
  {
    "shot_id": "001",
    "scene": "Scene 0 - City Intro",
    "location": "street",
    "characters": "",
    "extras": "police helicopters, active harbor yachts",
    "camera": "extreme wide aerial night shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, high-angle aerial night view of sprawling coastal neon metropolis Leonida, illuminated causeway bridges packed with moving car headlights, luxury yachts docked in harbor with deck lights, distant police helicopters with searchlights sweeping across skyscrapers, natural ocean reflections"
  },
  {
    "shot_id": "002",
    "scene": "Scene 0 - City Intro",
    "location": "street",
    "characters": "",
    "extras": "busy coastal boulevard traffic",
    "camera": "wide high-angle cinematic shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, busy coastal avenue at dusk filled with active traffic, luxury sports cars and classic muscle cars driving along palm-lined shoreline, sidewalks bustling with evening pedestrians outside brightly lit Art-Deco hotels, warm ambient twilight sky"
  },
  {
    "shot_id": "003",
    "scene": "Scene 0 - City Intro",
    "location": "street",
    "characters": "",
    "extras": "pedestrians, outdoor cafes, nightlife",
    "camera": "street-level tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, vibrant coastal avenue at early night, lively crowds of pedestrians walking naturally with shopping bags, couples chatting at outdoor cafe tables under glowing umbrellas, wet asphalt reflecting warm streetlamps after light rain, city nightlife in full swing"
  },
  {
    "shot_id": "004",
    "scene": "Scene 0 - City Intro",
    "location": "hq",
    "characters": "",
    "extras": "dispatcher console in action",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of female police dispatcher hand gripping heavy two-way radio microphone, glowing multi-monitor console in background showing busy city GIS map with flashing red emergency dispatch status lights, realistic office environment"
  },
  {
    "shot_id": "005",
    "scene": "Scene 0 - City Intro",
    "location": "hq",
    "characters": "",
    "extras": "emergency dispatch operations floor",
    "camera": "wide interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, busy police emergency operations dispatch floor, fluorescent lights, uniformed operators seated at glowing multi-screen stations with headsets talking into radios, active tense police headquarters atmosphere"
  },
  {
    "shot_id": "006",
    "scene": "Scene 0 - City Intro",
    "location": "street",
    "characters": "",
    "extras": "jewelry store exterior with people and guard",
    "camera": "street-level wide establishing shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, exterior of luxury store MARQUISE AND SONS JEWELERS at night, warm golden chandeliers blazing through massive glass display windows, pedestrians walking casually along sidewalk, parked luxury sports cars at curb, an armed uniformed security guard standing vigilant outside near entrance"
  },
  {
    "shot_id": "007",
    "scene": "Scene 0 - City Intro",
    "location": "street",
    "characters": "",
    "extras": "glittering display window and guard reflection",
    "camera": "medium close-up window shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, luxury display window of Marquise and Sons Jewelers, glittering diamond necklaces and luxury gold watches on black velvet pedestals under warm golden spotlights, armed security guard standing outside visible in window reflection, pedestrians walking past"
  },
  {
    "shot_id": "008",
    "scene": "Scene 0 - City Intro",
    "location": "street",
    "characters": "guard",
    "extras": "security guard on front steps",
    "camera": "low-angle street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, armed security guard in grey uniform standing alert on granite front steps outside jewelry store entrance, radio on shoulder, warm golden light spilling out from store doors, pedestrians walking past on sidewalk unaware"
  },
  {
    "shot_id": "009",
    "scene": "Scene 1 - Vault",
    "location": "street",
    "characters": "dre",
    "extras": "getaway SUV waiting outside",
    "camera": "wide low-angle exterior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, exterior of Marquise and Sons Jewelers at night, black heavy muscle SUV idling along curb with glowing red tail lights and exhaust steam, Dre alone visible through driver window gripping steering wheel, watching street nervously"
  },
  {
    "shot_id": "010",
    "scene": "Scene 1 - Vault",
    "location": "street",
    "characters": "dre",
    "extras": "Dre alone inside SUV",
    "camera": "medium interior vehicle shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside black muscle SUV, Dre alone in driver seat wearing full black tactical gear: neat braids, gold chain over black tactical combat shirt, black tactical vest, black driving gloves, focused intense eyes, both hands gripping steering wheel, checking side mirrors with hyper-focused adrenaline expression, glowing green police scanner on dashboard, nobody else in vehicle"
  },
  {
    "shot_id": "011",
    "scene": "Scene 1 - Vault",
    "location": "street",
    "characters": "dre",
    "extras": "Dre hand on floor shifter",
    "camera": "close-up interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Dre black gloved hand resting tense on automatic floor shifter of muscle SUV, red tactical dash lights reflecting on his gold chain and black combat shirt, ready to launch vehicle"
  },
  {
    "shot_id": "012",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason",
    "extras": "Jason pressing tactical earpiece",
    "camera": "macro close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, macro close-up of Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves, fingers in black tactical glove pressing sleek communications earpiece with blinking red LED, intense blue-grey eyes focused, warm golden chandeliers and jewelry sparkle in background"
  },
  {
    "shot_id": "013",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason,lucia,tony,bucky",
    "extras": "full robbery crew takeover",
    "camera": "wide interior establishing shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, full robbery takeover in progress: Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves aiming rifle at staff, Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves moving swiftly with canvas bag, Tony in full black tactical gear: wavy brown hair, aviator sunglasses, black tactical combat shirt with rolled sleeves, black tactical vest, black tactical cargo pants, black gloves, holding assault rifle covering rear corridor, Bucky in full black tactical gear: tan bucket hat, dark sunglasses, mustache, heavy black tactical body-armor vest over black combat shirt, black tactical cargo pants, black fingerless gloves, holding heavy shotgun covering front door, staff and customers kneeling on marble with hands on heads in terror"
  },
  {
    "shot_id": "014",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "guard,bucky",
    "extras": "multiple guards subdued",
    "camera": "wide action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, two security guards subdued: one heavy security guard in grey uniform lying face-down on polished marble with hands zip-tied and smashed radio beside head, second security guard pinned against glass display counter by Bucky in full black tactical gear: tan bucket hat, dark sunglasses, mustache, heavy black tactical body-armor vest over black combat shirt, black tactical cargo pants, black fingerless gloves, holding heavy shotgun with shotgun at chest, hands raised in surrender"
  },
  {
    "shot_id": "015",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "guard",
    "extras": "zip-tied guard on marble floor",
    "camera": "low-angle floor shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, heavy security guard in grey uniform lying face-down on polished white marble floor, hands bound tightly behind back with white plastic zip-ties, his heavy radio crushed and cracked beside his head with loose batteries, display cases glowing above"
  },
  {
    "shot_id": "016",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "tony",
    "extras": "Tony holding showroom",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, Tony in full black tactical gear: wavy brown hair, aviator sunglasses, black tactical combat shirt with rolled sleeves, black tactical vest, black tactical cargo pants, black gloves, holding assault rifle, standing dominant in center aisle, assault rifle at low-ready, aviator sunglasses reflecting chandeliers, commanding staff to stay flat on marble floor"
  },
  {
    "shot_id": "017",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason",
    "extras": "Jason confronting cashier",
    "camera": "over-the-shoulder medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, over the shoulder of a trembling store clerk kneeling behind counter, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves, holding black tactical pistol steady with calm commanding authority, diamond display trays visible on glass"
  },
  {
    "shot_id": "018",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia",
    "extras": "Lucia looting diamond trays",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves, long ponytail swinging as she swiftly sweeps heavy gold Cuban-link chains and diamond rings from velvet display trays into rugged black canvas duffel bag, sharp determined eyes"
  },
  {
    "shot_id": "019",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia",
    "extras": "stuffing loot bag",
    "camera": "close-up action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Lucia hands in black tactical gloves stuffing bundles of gold necklaces and diamond watches into heavy canvas duffel bag, sparkling crystal refractions on black fabric"
  },
  {
    "shot_id": "020",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "owner",
    "extras": "Mr. Marquise sweating in suit",
    "camera": "medium portrait shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, Mr. Marquise jeweler in his 60s, slicked-back silver hair, tailored navy suit, sweating profusely with trembling hands clutching gold cufflinks, eyes wide with pure panic as robbers approach"
  },
  {
    "shot_id": "021",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia,owner",
    "extras": "Lucia interrogating owner",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves, grabbing Mr. Marquise navy suit lapel firmly, pressing handgun lightly under his trembling chin, demanding vault code with cold fierce gaze, owner shaking in terror"
  },
  {
    "shot_id": "022",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason,owner",
    "extras": "Jason ordering vault open",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves stepping beside Lucia, pointing gun toward heavy reinforced steel vault door at rear of marble corridor, owner raising trembling hands pleading"
  },
  {
    "shot_id": "023",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "owner",
    "extras": "owner trembling finger on keypad",
    "camera": "extreme close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, extreme close-up of Mr. Marquise wrinkled trembling finger hovering over illuminated digital keypad on heavy steel vault door frame"
  },
  {
    "shot_id": "024",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "owner",
    "extras": "entering vault digital code",
    "camera": "close-up keypad shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, digital keypad glowing soft green as 6-digit code is entered, heavy industrial vault door frame surrounding lock"
  },
  {
    "shot_id": "025",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "vault bolts retracting",
    "camera": "extreme close-up mechanical shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, macro shot of three heavy cylindrical steel locking bolts retracting inside vault frame, pneumatic hiss of pressurized cold air venting"
  },
  {
    "shot_id": "026",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "vault door swinging open",
    "camera": "wide corridor shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, heavy circular steel vault door swinging slowly open into dark room, cold white mist rolling out across white marble floor, faint amber incandescent glow inside"
  },
  {
    "shot_id": "027",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason,lucia",
    "extras": "entering the vault",
    "camera": "over-the-shoulder entrance shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves and Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves stepping cautiously through vault doorway from behind, black tactical combat boots cutting through low swirling mist, weapons raised"
  },
  {
    "shot_id": "028",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "vault interior shelves",
    "camera": "wide interior vault shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of hidden steel vault: dusty metal shelving units stacked with yellowed paper ledgers, old document boxes, and wall of vintage brass safe-deposit lockers under dim incandescent bulbs"
  },
  {
    "shot_id": "029",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "corkboard archive photos",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, corkboard on vault wall pinned with black-and-white 1990s archive photographs of ten men in suits around boardroom table, handwritten notes with faded red ink"
  },
  {
    "shot_id": "030",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "macro archive photo Black Crown",
    "camera": "macro close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, macro shot of vintage photograph showing 1990s crime figures around table, faces half in shadow, bottom stamped 'BLACK CROWN ARCHIVE 1992'"
  },
  {
    "shot_id": "031",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "locker wall single open compartment",
    "camera": "wide shot inside vault",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, wall of numbered deposit lockers inside vault, all doors hanging rusted and empty except one small locker near bottom glowing with faint golden reflection"
  },
  {
    "shot_id": "032",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia",
    "extras": "Lucia discovering locker",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside vault, Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves kneeling before the single closed deposit locker, black gloved hand reaching forward to turn tiny brass latch with curiosity"
  },
  {
    "shot_id": "033",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia",
    "extras": "opening velvet-lined locker",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Lucia black gloved hand swinging open small dented locker door, reveal of faded dark burgundy velvet lining inside"
  },
  {
    "shot_id": "034",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "silver key with cracked crown",
    "camera": "extreme macro shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, extreme macro shot of small antique silver key resting on worn velvet, ornate head shaped like a royal crown with visible clean crack split down the middle"
  },
  {
    "shot_id": "035",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia",
    "extras": "Lucia holding silver key",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside vault, Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves holding silver cracked-crown key up to overhead filament bulb, awe and bewilderment in her eyes, gold hoop earrings reflecting light"
  },
  {
    "shot_id": "036",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason",
    "extras": "Jason inspecting key",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside vault, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves leaning over Lucia shoulder inspecting silver key in her palm, brow furrowed with confusion behind black mask"
  },
  {
    "shot_id": "037",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "owner",
    "extras": "owner terrified reaction in doorway",
    "camera": "medium shot in doorway",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Mr. Marquise standing frozen in vault doorway, face drained of all color, staring at silver key as if seeing his own death sentence"
  },
  {
    "shot_id": "038",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason,owner",
    "extras": "Jason confronting terrified owner",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside vault, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves stepping toward Mr. Marquise holding key forward: Jason narrowing eyes accusingly, owner stammering with hands held defensively"
  },
  {
    "shot_id": "039",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "owner",
    "extras": "owner secret foot alarm button",
    "camera": "extreme close-up floor shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, extreme close-up of Mr. Marquise polished Italian leather dress shoe covertly pressing a concealed brass alarm button beneath bottom shelf"
  },
  {
    "shot_id": "040",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "",
    "extras": "silent alarm red light pulsing",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, red silent alarm strobe pulsing rhythmically high on concrete vault wall, casting deep red shadows across ledgers"
  },
  {
    "shot_id": "041",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "lucia",
    "extras": "Lucia noticing red alarm",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside vault, Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves turning sharply toward pulsing red light, eyes widening with urgency, grabbing Jason tactical vest"
  },
  {
    "shot_id": "042",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason",
    "extras": "Jason pocketing key and raising weapon",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves securing silver key inside tactical pocket, raising rifle toward corridor, shouting urgent command to crew to move out"
  },
  {
    "shot_id": "043",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason,lucia,tony,bucky",
    "extras": "crew sprinting toward front",
    "camera": "wide corridor tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, interior of high-end luxury store Marquise and Sons Jewelers, polished white marble floor reflecting sparkling crystal chandeliers, warm golden spotlights on glass display cases filled with gold jewelry and diamonds, heavy steel vault door with round wheel visible at back, all four robbers in black tactical gear sprinting down marble corridor past glass cases, loot bag swinging, staff cowering on floor"
  },
  {
    "shot_id": "044",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "guard",
    "extras": "guard on floor smirking",
    "camera": "close-up floor shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, zip-tied security guard on marble floor lifting head, subtle smirk on face as distant police sirens begin wailing outside"
  },
  {
    "shot_id": "045",
    "scene": "Scene 1 - Vault",
    "location": "shop",
    "characters": "jason,lucia",
    "extras": "bursting front glass doors",
    "camera": "wide shot at entrance",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, front glass double doors of Marquise and Sons bursting open outward as Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves and Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves run out onto exterior granite steps"
  },
  {
    "shot_id": "046",
    "scene": "Scene 1 - Vault",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "freezing under police sirens",
    "camera": "wide exterior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, outside on store steps at night, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves and Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves freezing as intense flashing blue and red emergency lights suddenly flood their black gear"
  },
  {
    "shot_id": "047",
    "scene": "Scene 1 - Vault",
    "location": "street",
    "characters": "",
    "extras": "police cruisers screeching to halt",
    "camera": "high-angle street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, high-angle view of street outside jewelry store, dozen police cruisers skidding to halt forming barricade arc across wet asphalt with flashing lights"
  },
  {
    "shot_id": "048",
    "scene": "Scene 1 - Vault",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "trapped robbery couple",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, warm golden interior lighting, realistic textures, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, on store steps, Jason in full black tactical robbery gear: black backwards cap, black cloth face mask, black tactical combat shirt, black body-armor vest, black tactical cargo pants, black combat boots, black tactical gloves and Lucia in full black tactical robbery gear: long dark ponytail, gold hoop earrings, black bandana face mask, fitted black tactical combat top, black tactical vest with pouches, black tactical pants, black combat boots, black gloves standing back to back with weapons lowered, hands slowly rising, flashing red-blue siren lights reflecting on their black masks"
  },
  {
    "shot_id": "049",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "cop",
    "extras": "police line",
    "camera": "wide eye-level shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, line of Leonida police officers in dark-blue uniforms and tactical vests taking cover behind open cruiser doors, shotguns and handguns aimed forward"
  },
  {
    "shot_id": "050",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "cop",
    "extras": "sniper on roof",
    "camera": "low-angle silhouette shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police sniper crouched on Art-Deco rooftop silhouette against purple-blue twilight sky, long-range rifle scope trained on jewelry store steps"
  },
  {
    "shot_id": "051",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "",
    "extras": "crowd of bystanders",
    "camera": "medium crowd shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, crowd of curious pedestrians gathered on opposite sidewalk, holding up smartphones filming standoff, flashing lights reflecting on mobile screens"
  },
  {
    "shot_id": "052",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "",
    "extras": "news van satellite",
    "camera": "medium street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, local news broadcast van parked at intersection curb, satellite dish raised, female television reporter adjusting microphone headset"
  },
  {
    "shot_id": "053",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "chief",
    "extras": "Chief Dunmore megaphone",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Police Chief Dunmore standing behind hood of command cruiser, megaphone raised, white uniform shirt with silver badges, stern grizzled face"
  },
  {
    "shot_id": "054",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "chief",
    "extras": "giving orders",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore speaking into radio microphone with intense gaze, warning officers to hold fire due to hostages inside"
  },
  {
    "shot_id": "055",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "cop",
    "extras": "finger on trigger",
    "camera": "extreme close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, extreme close-up of a nervous young police officer trembling finger resting along trigger guard of black duty pistol, sweat bead on knuckle"
  },
  {
    "shot_id": "056",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "whispering back to back",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia back to back with hands raised chest-high, Jason whispering calmly while Lucia eyes dart across police barricade calculating exits"
  },
  {
    "shot_id": "057",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "lucia",
    "extras": "touching key pocket",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Lucia denim shorts pocket where corner of silver cracked-crown key glints under flashing emergency lights"
  },
  {
    "shot_id": "058",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "jason",
    "extras": "eyes scanning street",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Jason blue-grey eyes reflecting red and blue flashing sirens, jaw set with determined focus"
  },
  {
    "shot_id": "059",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "cop",
    "extras": "aimed shotgun barrels",
    "camera": "POV shot from store steps",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, POV from store entrance looking out: sea of blinding cruiser headlights, red-blue lightbars flashing, dozens of gun barrels trained forward"
  },
  {
    "shot_id": "060",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "dre",
    "extras": "distant SUV headlights",
    "camera": "deep focus street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, empty dark cross-street two blocks away, sudden flash of high-beam headlights appearing through rain mist, engine roar vibrating"
  },
  {
    "shot_id": "061",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "",
    "extras": "standoff tension",
    "camera": "extreme wide overhead shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, overhead bird-eye view of jewelry store entrance surrounded in a half-circle by twelve flashing police cruisers, total standoff stillness"
  },
  {
    "shot_id": "062",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "chief",
    "extras": "checking watch",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore checking wristwatch, radio crackling with SWAT ETA updates, red light sweeping across his badges"
  },
  {
    "shot_id": "063",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "lucia",
    "extras": "tense breathing",
    "camera": "close-up portrait",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia tense breathing, bandana around neck, ponytail strands loose in wind, staring down police line with defiance"
  },
  {
    "shot_id": "064",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "jason",
    "extras": "subtle nod",
    "camera": "close-up portrait",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason giving subtle barely perceptible nod toward left alleyway, muscles coiled ready to spring"
  },
  {
    "shot_id": "065",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "cop",
    "extras": "officer hearing engine",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police officer at cruiser barricade suddenly turning head toward intersection sound, eyes widening in alarm"
  },
  {
    "shot_id": "066",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "",
    "extras": "tire smoke appearing",
    "camera": "low-angle corner shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, asphalt corner two blocks away, smoke pouring from screeching heavy tires as black muscle vehicle accelerates around turn"
  },
  {
    "shot_id": "067",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "bracing for impact",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia dropping their raised hands slightly, preparing to dive for cover, knowing rescue is arriving"
  },
  {
    "shot_id": "068",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "chief",
    "extras": "turning to megaphone",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore lowering megaphone abruptly, shouting into radio as headlights illuminate his cruiser"
  },
  {
    "shot_id": "069",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "",
    "extras": "shadow of speeding vehicle",
    "camera": "street-level fast shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, speeding black shadow of heavy SUV slicing across wet pavement reflections, engine roaring at full throttle"
  },
  {
    "shot_id": "070",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "jason",
    "extras": "smirk of recognition",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason face breaking into a quick relieved grin as the familiar exhaust rumble echoes across the street"
  },
  {
    "shot_id": "071",
    "scene": "Scene 2 - Standoff",
    "location": "street",
    "characters": "",
    "extras": "cut to black screen",
    "camera": "graphic shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, pure black screen, center glowing with faint silver outline of cracked crown key symbol"
  },
  {
    "shot_id": "072",
    "scene": "Intro - Title Card",
    "location": "street",
    "characters": "",
    "extras": "cracked crown graphic",
    "camera": "cinematic title graphic shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, cinematic title sequence: massive golden-silver royal crown fractured cleanly in two halves, floating against dark neon Miami skyline at sunset, atmospheric smoke"
  },
  {
    "shot_id": "073",
    "scene": "Intro - Title Card",
    "location": "street",
    "characters": "jason,lucia,niko",
    "extras": "three silhouettes",
    "camera": "graphic silhouette shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, stylized montage frame: dark silhouettes of Jason, Lucia, and Niko Bellic standing back-to-back, single glowing silver key suspended between them"
  },
  {
    "shot_id": "074",
    "scene": "Intro - Title Card",
    "location": "street",
    "characters": "",
    "extras": "neon city grid map",
    "camera": "aerial graphic shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, graphic render of coastal Leonida city map overlayed with glowing red grid lines connecting Miami to Karachi shipping routes"
  },
  {
    "shot_id": "075",
    "scene": "Intro - Title Card",
    "location": "street",
    "characters": "",
    "extras": "title card finish",
    "camera": "dramatic title shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, clean title visual with cracked crown emblem gleaming in 4K, dark stormy clouds rolling over ocean in background"
  },
  {
    "shot_id": "076",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "dre",
    "extras": "SUV smashing cones",
    "camera": "wide action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black heavy muscle SUV smashing through orange traffic barricades at 60 mph, headlights blinding police line, Dre gripping steering wheel with focused rage"
  },
  {
    "shot_id": "077",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "police diving away",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police officers diving sideways onto wet asphalt as the heavy SUV sideswipes cruiser front bumpers with explosive shower of sparks"
  },
  {
    "shot_id": "078",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "tony",
    "extras": "Tony leaning out window",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony leaning halfway out front passenger window of speeding SUV, wavy brown hair flying, aviator sunglasses, firing automatic assault rifle into police engine blocks"
  },
  {
    "shot_id": "079",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "diving behind planter",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason grabbing Lucia and tackling her behind heavy concrete ornamental flower planter as bullets shred leaves above them"
  },
  {
    "shot_id": "080",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "bucky",
    "extras": "Bucky popping through sunroof",
    "camera": "low-angle hero action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky standing up through open SUV sunroof with bucket hat held on with one hand, firing heavy shotgun in other hand, black tactical vest flapping"
  },
  {
    "shot_id": "081",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "cruiser windshield shattering",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, cruiser windshield spider-webbing into thousand glass fragments under shotgun blast, police officer ducking behind steering wheel"
  },
  {
    "shot_id": "082",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "dre",
    "extras": "SUV drifting sideways",
    "camera": "wide street action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black muscle SUV executing a massive power-slide across wet intersection, tire smoke billowing, blocking police line of sight to jewelry store steps"
  },
  {
    "shot_id": "083",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "Jason returning fire",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason leaning around concrete planter, firing semi-automatic rifle with sharp tactical precision, empty brass casings flying in slow-motion"
  },
  {
    "shot_id": "084",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "lucia",
    "extras": "Lucia covering left flank",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia kneeling behind Jason, dual-wielding handguns, firing controlled bursts toward police flanking cruiser, hoop earrings swinging violently"
  },
  {
    "shot_id": "085",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "chief",
    "extras": "Dunmore taking cover",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore crouched behind open driver door of his cruiser, shards of glass in his hair, furiously shouting code red into radio"
  },
  {
    "shot_id": "086",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "tony",
    "extras": "Tony laughing mid-firefight",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony reloading assault rifle with practiced ease, wild grinning expression behind aviator sunglasses, brass casings bouncing off SUV roof"
  },
  {
    "shot_id": "087",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "bucky",
    "extras": "Bucky ducking inside sunroof",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky ducking back into sunroof as bullets punch holes in SUV metal roof, chuckling as he adjusts his green alien Hawaiian shirt"
  },
  {
    "shot_id": "088",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "dre",
    "extras": "Dre ramming police cruiser",
    "camera": "wide impact shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, front reinforced steel push-bar of black SUV slamming directly into side of police cruiser, spinning cruiser 180 degrees across wet road"
  },
  {
    "shot_id": "089",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "cruiser fuel tank exploding",
    "camera": "wide explosion shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police cruiser fuel line igniting into massive towering orange fireball, shockwave throwing debris and smoke across intersection"
  },
  {
    "shot_id": "090",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "running through smoke",
    "camera": "medium tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia silhouetted against glowing orange fireball, sprinting full speed down dark service alley beside jewelry store"
  },
  {
    "shot_id": "091",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "tony,bucky,dre",
    "extras": "SUV decoy turn",
    "camera": "wide street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black SUV roaring away to the left at intersection, drawing fire of three pursuing police cruisers away from alley entrance"
  },
  {
    "shot_id": "092",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "cruisers chasing SUV",
    "camera": "tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, three police cruisers with sirens screaming speeding down main boulevard in hot pursuit of black SUV, tires spraying water"
  },
  {
    "shot_id": "093",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "entering dark alley",
    "camera": "wide alley shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia entering narrow dark brick alleyway, rain steam rising from manhole, distant sirens echoing behind them"
  },
  {
    "shot_id": "094",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason",
    "extras": "reloading in alley",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason pausing behind dumpster, slapping fresh magazine into pistol, sweat glistening on jawline under baseball cap"
  },
  {
    "shot_id": "095",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "lucia",
    "extras": "checking canvas bag",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia checking canvas bag zippers, patting her pocket to ensure silver cracked-crown key is securely inside, breathing heavily"
  },
  {
    "shot_id": "096",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "bucky",
    "extras": "Bucky waving from SUV window",
    "camera": "medium shot from SUV",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky waving mockingly out SUV rear window at pursuing cruisers as SUV speeds toward highway on-ramp"
  },
  {
    "shot_id": "097",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "dre",
    "extras": "Dre shifting gears",
    "camera": "close-up vehicle interior",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre hand slamming floor gear shifter forward, gold chain swinging, engine RPM needle bouncing off redline"
  },
  {
    "shot_id": "098",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "tony",
    "extras": "Tony spotting alley clear",
    "camera": "medium interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony glancing at side-mirror, radioing Jason that alley escape route is clear of pursuit for next 60 seconds"
  },
  {
    "shot_id": "099",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "reaching back of alley",
    "camera": "medium tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia running toward rear alley courtyard where a large weathered canvas tarp is draped over equipment"
  },
  {
    "shot_id": "100",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "chief",
    "extras": "Dunmore regrouping units",
    "camera": "wide street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore standing beside burning cruiser wreckage, waving backup tactical vans toward boulevard and sealing perimeter"
  },
  {
    "shot_id": "101",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "tactical team advancing",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, SWAT officers in heavy body armor advancing down jewelry store sidewalk with assault rifles at low-ready"
  },
  {
    "shot_id": "102",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason",
    "extras": "grabbing tarp",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason reaching out and gripping edge of heavy green canvas tarp, muscles tensed, ready to rip it away"
  },
  {
    "shot_id": "103",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "lucia",
    "extras": "guarding alley corner",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia with back against brick wall, aiming pistol back toward alley mouth, watching for any pursuing officers"
  },
  {
    "shot_id": "104",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "",
    "extras": "tarp flying off bikes",
    "camera": "wide action reveal shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, canvas tarp flying into air in slow-motion, revealing two sleek matte-black high-performance sport motorcycles hidden underneath"
  },
  {
    "shot_id": "105",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason",
    "extras": "turning bike ignition",
    "camera": "close-up mechanical shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason gloved hand inserting key and turning motorcycle ignition, digital blue instrument cluster lighting up instantly"
  },
  {
    "shot_id": "106",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "mounting sport bike",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason straddling black sport bike, kicking up side-stand, Lucia jumping onto pillion seat behind him, wrapping arms around his chest"
  },
  {
    "shot_id": "107",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "lucia",
    "extras": "arms locked around Jason",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia arms wrapped tight around Jason waist, head tucked against his back, eyes fierce and ready for escape"
  },
  {
    "shot_id": "108",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason",
    "extras": "revving bike throttle",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason twisting rubber hand throttle, rear tire spinning against wet alley cobblestones, launching bike forward"
  },
  {
    "shot_id": "109",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "",
    "extras": "bike bursting from alley",
    "camera": "wide low-angle shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black sport motorcycle rocketing out of narrow alleyway into coastal avenue, front wheel lifting slightly in powerful wheelie"
  },
  {
    "shot_id": "110",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "cruisers spotting motorcycle",
    "camera": "wide street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, two police cruisers on coastal avenue slamming brakes and executing handbrake turns to pursue speeding motorcycle"
  },
  {
    "shot_id": "111",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "tony",
    "extras": "SUV leading cruisers away",
    "camera": "wide highway shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black muscle SUV roaring onto elevated highway ramp miles away, three cruisers still chasing after the decoy"
  },
  {
    "shot_id": "112",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "bucky",
    "extras": "Bucky celebrating in SUV",
    "camera": "medium interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky holding up two soda cans in victory inside SUV, bucket hat tilted back, grinning broadly"
  },
  {
    "shot_id": "113",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "dre",
    "extras": "Dre eyes in rearview mirror",
    "camera": "close-up mirror shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre calm focused eyes in rearview mirror, watching highway police lights fall behind as he plans detour"
  },
  {
    "shot_id": "114",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "motorcycle speeding down avenue",
    "camera": "wide tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black motorcycle weaving between evening traffic along palm-lined coastal boulevard, neon signs reflecting in wet asphalt"
  },
  {
    "shot_id": "115",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "cop",
    "extras": "cruisers closing distance",
    "camera": "tracking action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, lead police cruiser with sirens wailing accelerating within three car lengths of the fleeing motorcycle"
  },
  {
    "shot_id": "116",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "exchanging glances",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia leaning close to Jason helmetless ear shouted above wind noise, Jason grinning with adrenaline rush"
  },
  {
    "shot_id": "117",
    "scene": "Scene 3 - Gunfight",
    "location": "street",
    "characters": "",
    "extras": "approaching drawbridge signs",
    "camera": "wide environmental shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, overhead highway gantry signs flashing yellow warning lights: 'MARINA DRAWBRIDGE OPENING - ALL TRAFFIC STOP'"
  },
  {
    "shot_id": "118",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "weaving beach boardwalk",
    "camera": "wide tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black sport bike weaving at high speed between tourist cafes and colorful beach boardwalk benches, ocean waves crashing nearby"
  },
  {
    "shot_id": "119",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "roller-skater dodging bike",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, roller-skater leaping onto grass verge in surprise, dropped ice cream cone flying through air as motorcycle streaks past"
  },
  {
    "shot_id": "120",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "lucia",
    "extras": "Lucia shooting backwards",
    "camera": "medium hero action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia leaning backward off sport bike passenger seat, one arm around Jason, firing semi-auto pistol one-handed at pursuing cruiser"
  },
  {
    "shot_id": "121",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "cruiser hitting hot-dog cart",
    "camera": "wide comedy-action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, lead police cruiser swerving to avoid Lucia bullets, crashing head-on into a curbside hot-dog umbrella stand, buns and sausages flying"
  },
  {
    "shot_id": "122",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "officer inside wrecked cruiser",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police officer inside deployed airbag cruiser coughing on white powder, shouting into microphone as bike disappears ahead"
  },
  {
    "shot_id": "123",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "approaching lifting drawbridge",
    "camera": "wide high-angle shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, massive steel Marina Drawbridge ahead with flashing red bells, twin road deck plates slowly pivoting upward toward night sky"
  },
  {
    "shot_id": "124",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "drawbridge black water gap",
    "camera": "low-angle dramatic shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, widening twenty-foot black gap between steel bridge deck halves, dark churning ocean harbor water far below"
  },
  {
    "shot_id": "125",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "lucia",
    "extras": "Lucia shouting at bridge",
    "camera": "close-up profile shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia shouting warning into Jason ear, eyes wide at opening steel abyss, gripping his shoulders with white knuckles"
  },
  {
    "shot_id": "126",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason",
    "extras": "Jason accelerating toward ramp",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason leaning forward over bike handlebars, eyes locked on upward-angled steel bridge ramp, pinning throttle to maximum"
  },
  {
    "shot_id": "127",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "hitting drawbridge ramp",
    "camera": "medium action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, motorcycle front tire hitting the incline of the lifting steel plate, suspension compressing, shower of sparks as exhaust drags"
  },
  {
    "shot_id": "128",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "airborne over drawbridge",
    "camera": "extreme wide cinematic jump shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, breathtaking slow-motion silhouette: black sport bike soaring forty feet in mid-air across open bridge gap against purple dusk sky, ocean below"
  },
  {
    "shot_id": "129",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "close-up mid-air jump",
    "camera": "medium close-up in flight",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Jason and Lucia suspended mid-air: wind tearing at Lucia ponytail, Jason calm focused grip, neon skyline glowing behind them"
  },
  {
    "shot_id": "130",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "landing on far bridge side",
    "camera": "wide landing impact shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, motorcycle rear tire slamming down on far bridge plate with violent crack and explosion of sparks, bike wobbling then straightening out"
  },
  {
    "shot_id": "131",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "cruiser falling off bridge",
    "camera": "dramatic action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, second pursuing police cruiser hitting bridge too late, tires locking up, sliding sideways off lifted steel plate into open air"
  },
  {
    "shot_id": "132",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "cruiser splashing into harbor",
    "camera": "wide water impact shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police cruiser plunging into dark ocean harbor water with massive white geyser splash, red-blue emergency lights glowing underwater"
  },
  {
    "shot_id": "133",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "speeding off bridge ramp",
    "camera": "wide tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, black sport bike racing down opposite bridge ramp safely onto mainland industrial boulevard, leaving sirens behind"
  },
  {
    "shot_id": "134",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "police helicopter overhead",
    "camera": "high-angle aerial shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Leonida police search helicopter banking steeply across night skyscraper skyline, twin rotor wash rippling harbor water"
  },
  {
    "shot_id": "135",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "helicopter searchlight",
    "camera": "low-angle night shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police helicopter hovering low, powerful million-candlepower white searchlight beam slicing through warehouse rooftops"
  },
  {
    "shot_id": "136",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "helicopter cockpit view",
    "camera": "medium interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside police helicopter cockpit: pilot and tactical observer looking down through night-vision equipment, tracking fleeing motorcycle"
  },
  {
    "shot_id": "137",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "dre,bucky",
    "extras": "SUV entering car wash",
    "camera": "wide exterior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, across town, black muscle SUV speeding into entrance of commercial automatic car wash with spinning blue brushes and foam spray"
  },
  {
    "shot_id": "138",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "cop",
    "extras": "cruisers jamming inside car wash",
    "camera": "medium interior car wash shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, three pursuing police cruisers piled up inside automatic car wash, giant spinning foam brushes pinning doors, soapy water blasting windshields"
  },
  {
    "shot_id": "139",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "bucky",
    "extras": "Bucky laughing in car wash exit",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky leaning out SUV window covered in white soap bubbles, laughing hysterically as SUV exits clean on far side of car wash"
  },
  {
    "shot_id": "140",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "helicopter spotlight hits bike",
    "camera": "medium high-contrast shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, intense white helicopter spotlight illuminating Jason and Lucia on motorcycle, casting long pitch-black shadows across industrial road"
  },
  {
    "shot_id": "141",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason",
    "extras": "spotting drain tunnel",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason squinting through blinding spotlight beam, spotting hidden concrete flood-drainage tunnel opening behind chained security fence"
  },
  {
    "shot_id": "142",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "smashing through chain-link fence",
    "camera": "wide action impact shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, motorcycle crashing directly through chain-link security fence, steel wire snapping with sparks, diving into black tunnel mouth"
  },
  {
    "shot_id": "143",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "inside concrete drain tunnel",
    "camera": "wide interior tunnel shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, inside massive curved concrete storm tunnel, damp yellow service lights hanging from ceiling, shallow water spraying beneath tires"
  },
  {
    "shot_id": "144",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "spotlight missing tunnel mouth",
    "camera": "exterior tunnel shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, helicopter searchlight sweeping rapidly past fence opening without detecting motorcycle, continuing down open street"
  },
  {
    "shot_id": "145",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "bike slowing down in tunnel",
    "camera": "medium tracking shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, motorcycle slowing to a gentle idle inside dimly lit concrete tunnel, water dripping steadily from curved ceiling"
  },
  {
    "shot_id": "146",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "lucia",
    "extras": "Lucia resting head on Jason",
    "camera": "close-up two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia resting forehead against Jason shoulder blade, eyes closed in profound relief, adrenaline subsiding, water dripping"
  },
  {
    "shot_id": "147",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason",
    "extras": "Jason cutting bike engine",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason switching off bike headlights and engine, complete quiet settling inside tunnel save for distant muffled sirens fading away"
  },
  {
    "shot_id": "148",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "lucia",
    "extras": "checking key in dark",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia pulling silver cracked-crown key from pocket, holding it in faint yellow tunnel amber light, whispering to Jason"
  },
  {
    "shot_id": "149",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason",
    "extras": "smiling in dark",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason turning head back to look at Lucia, tired smile spreading across his stubbled face under backwards cap"
  },
  {
    "shot_id": "150",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "tunnel exit view",
    "camera": "wide environmental shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, far exit of storm tunnel opening out onto secluded marsh canal on outskirts of city, quiet blue moonlight over water"
  },
  {
    "shot_id": "151",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "riding out to canal",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia coasting quietly out of tunnel mouth along dirt canal service road, city skyline glowing in deep distance"
  },
  {
    "shot_id": "152",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "dre,tony",
    "extras": "SUV meeting point",
    "camera": "wide night shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, deserted industrial container yard where black SUV is parked in shadows, headlights off, Tony leaning against hood waiting"
  },
  {
    "shot_id": "153",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "arriving at container yard",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason motorcycle pulling up alongside black SUV, headlights flashing once in friendly recognition, crew reunited"
  },
  {
    "shot_id": "154",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "tony,jason",
    "extras": "fist bump",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony and Jason exchanging solid fist bump through open car window, both smiling after surviving massive police dragnet"
  },
  {
    "shot_id": "155",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "bucky,lucia",
    "extras": "Bucky saluting Lucia",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky tipping his bucket hat respectfully toward Lucia, holding up bag of stolen burgers, Lucia laughing shaking her head"
  },
  {
    "shot_id": "156",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "dre",
    "extras": "Dre leading convoy",
    "camera": "medium vehicle shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre turning SUV around onto secluded service road leading to laundromat hideout, bike following closely behind"
  },
  {
    "shot_id": "157",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "abandoned streetscape",
    "camera": "wide landscape shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, quiet deserted streets of outer industrial district at 11 PM, flickering sodium streetlights, completely empty of police"
  },
  {
    "shot_id": "158",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "",
    "extras": "laundromat alley approach",
    "camera": "medium street shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, convoy turning into dark overgrown alley behind closed commercial strip mall, trash cans and old pallets lining brick walls"
  },
  {
    "shot_id": "159",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason",
    "extras": "parking bike under shelter",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason parking sport bike under corrugated metal lean-to behind laundromat, covering it with dirty tarp once more"
  },
  {
    "shot_id": "160",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "dre",
    "extras": "parking SUV in garage bay",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre backing battered black SUV into rusted service garage bay, pulling chain to lower heavy roller shutter"
  },
  {
    "shot_id": "161",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "approaching hideout door",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia carrying canvas duffel bag toward hidden metal basement hatch door behind broken industrial washing machines"
  },
  {
    "shot_id": "162",
    "scene": "Scene 4 - Bike Chase",
    "location": "street",
    "characters": "jason",
    "extras": "unlocking hatch padlock",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason turning heavy brass key in heavy industrial padlock securing metal floor hatch, hinges creaking in quiet alley"
  },
  {
    "shot_id": "163",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "laundromat exterior sign",
    "camera": "exterior close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, exterior rusted neon sign 'SUNNY SPIN LAUNDROMAT', half letters buzzing with broken neon, peeling window paint, dark alley"
  },
  {
    "shot_id": "164",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "descending wooden stairs",
    "camera": "medium interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason leading Lucia down creaking wooden basement staircase into warm amber glow of underground bunker hideout, dust floating in air"
  },
  {
    "shot_id": "165",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "hideout establishing wide",
    "camera": "wide interior panoramic shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, underground hideout below laundromat: concrete walls, worn brown leather sofas, vintage CRT TV, soft glowing neon beer sign, crates of ammo and cash"
  },
  {
    "shot_id": "166",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "wall map with red pins",
    "camera": "medium wall shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, large maritime navigation map of Florida and Gulf Coast pinned to wall with red yarn and push pins, subtle hand-drawn cracked crown symbol in corner"
  },
  {
    "shot_id": "167",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "ammo crates and fridge",
    "camera": "medium corner shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, wooden military ammo crates stacked beside humming retro green refrigerator, ticking vintage clock on wall showing 11:35 PM"
  },
  {
    "shot_id": "168",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "lucia",
    "extras": "collapsing on leather sofa",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia collapsing backward onto worn leather couch, throwing canvas bag onto wooden coffee table, sighing with total exhaustion"
  },
  {
    "shot_id": "169",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "fetching first aid kit",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason opening metal first-aid box on workshop shelf, pulling out antiseptic bottle and white cotton gauze pads"
  },
  {
    "shot_id": "170",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "cleaning graze on arm",
    "camera": "medium close-up two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason gently dabbing antiseptic on small bleeding bullet graze on Lucia forearm, Lucia pretending it doesn't sting, soft tender gaze between them"
  },
  {
    "shot_id": "171",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia looking at Jason",
    "camera": "close-up portrait",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Lucia face in warm amber lamplight, dark ponytail loose over shoulder, grateful smile touching her lips"
  },
  {
    "shot_id": "172",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "taping bandage",
    "camera": "close-up hands shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason fingers carefully wrapping clean white medical tape around Lucia arm, silver wristwatch glinting in lamp light"
  },
  {
    "shot_id": "173",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "lucia",
    "extras": "mentioning store owner",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia leaning forward on sofa, talking quietly about Mr. Marquise terrified reaction when they opened the deposit locker"
  },
  {
    "shot_id": "174",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "taking out the key",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason pulling silver key from inner vest pocket, holding it delicately under yellow desk lamp, studying the cracked crown head"
  },
  {
    "shot_id": "175",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "key shadow on desk",
    "camera": "macro close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, macro shot of cracked crown key on rough wooden table, desk lamp casting elongated dramatic crown-shaped shadow across scratched wood"
  },
  {
    "shot_id": "176",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "storing key in metal tin",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason placing silver key inside a small dented metal tobacco tin, snapping lid shut, sliding tin into deep pocket"
  },
  {
    "shot_id": "177",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "hatch door banging open",
    "camera": "medium wide shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, wooden basement staircase door banging open loudly at top of stairs, three loud voices echoing down as crew arrives"
  },
  {
    "shot_id": "178",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "tony,bucky,dre",
    "extras": "crew tumbling down stairs",
    "camera": "wide action shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony, Bucky and Dre bursting down basement stairs in high spirits, sooty smudges on their faces, carrying bags of food and drink"
  },
  {
    "shot_id": "179",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky throwing hat on table",
    "camera": "medium comedy shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky collapsing onto armchair, tossing sweat-stained bucket hat onto table, wiping forehead: shouting for cold drinks and medals"
  },
  {
    "shot_id": "180",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony leaning against post",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony leaning against wooden support pillar, aviator sunglasses pushed up onto wavy brown hair, laughing about police shooting accuracy"
  },
  {
    "shot_id": "181",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "dre",
    "extras": "Dre handing out cold cans",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre opening old cooler, handing chilled soda cans and bottles to everyone, gold chain swinging, smiling with quiet relief"
  },
  {
    "shot_id": "182",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason,tony",
    "extras": "reunited crew greeting",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Tony greeting each other warmly with shoulder clasps, adrenaline giving way to camaraderie"
  },
  {
    "shot_id": "183",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "lucia,bucky",
    "extras": "banter about hot dog cart",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia teasing Bucky from sofa about taking down a police cruiser with a hot-dog stand, Bucky gesturing defensively with soda can"
  },
  {
    "shot_id": "184",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "tony",
    "extras": "asking about jewelry loot",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony looking at canvas bag and small metal tin on table, jokingly asking if all they got from largest jewelry store was one tiny key"
  },
  {
    "shot_id": "185",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "bucky",
    "extras": "complaining about watch",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky complaining with animated hand gestures that he asked for a big ugly diamond watch and got nothing"
  },
  {
    "shot_id": "186",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "laughing with crew",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason laughing heartily, leaning back against workbench, raising soda can in toast: announcing that tonight they celebrate"
  },
  {
    "shot_id": "187",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "bucky",
    "extras": "cheering celebration",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky jumping up from armchair cheering that finally someone made a good executive decision to throw a party"
  },
  {
    "shot_id": "188",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "dre",
    "extras": "unpacking food cartons",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre unpacking steam-hot cardboard takeout containers of biryani, grilled chicken kebabs, and pizza boxes onto workbench"
  },
  {
    "shot_id": "189",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "food table steam",
    "camera": "close-up food shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of table laden with savory biryani rice with whole spices, seekh kebabs, pizza slices, and ice-cold soda cans"
  },
  {
    "shot_id": "190",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia smiling at crew",
    "camera": "medium portrait shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia leaning against sofa arm, watching her crew friends celebrate, relaxed and happy for the first time in hours"
  },
  {
    "shot_id": "191",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony adjusting music speaker",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony plugging aux cord into old portable boombox speaker on shelf, funky bassline starting to thump softly through basement"
  },
  {
    "shot_id": "192",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "Jason opening cold drink",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason popping tab on cold soda can, foam hissing, eyes looking across at Lucia with deep affection"
  },
  {
    "shot_id": "193",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky eating biryani",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky happily digging into large plate of biryani with plastic fork, bucket hat resting beside plate, nodding in satisfaction"
  },
  {
    "shot_id": "194",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "dre",
    "extras": "Dre inspecting vehicle keys",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre hanging SUV keys on wall hook, jotting down damaged parts list on notepad: windshield, front bumper, alignment"
  },
  {
    "shot_id": "195",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "quiet moment amid noise",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason sitting beside Lucia on sofa, clinking cans together quietly while music and banter echo around the room"
  },
  {
    "shot_id": "196",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "basement party atmosphere",
    "camera": "wide interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, wide view of underground hideout transformed into cozy celebration: string lights twinkling along overhead pipes, music playing"
  },
  {
    "shot_id": "197",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony sharing funny story",
    "camera": "medium group shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony enthusiastically reenacting car-wash escape with hand gestures, Bucky and Dre bursting out laughing"
  },
  {
    "shot_id": "198",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia glancing at metal tin",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia gaze drifting from laughing crew down to dented metal tin on coffee table, curiosity returning to her face"
  },
  {
    "shot_id": "199",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "jason",
    "extras": "Jason noticing her gaze",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason noticing Lucia staring at tin, nudging her gently with elbow, offering reassuring smile"
  },
  {
    "shot_id": "200",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "clock ticking midnight",
    "camera": "close-up clock shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, vintage wooden wall clock pendulum swinging, hands crossing midnight 12:00 AM, gears clicking"
  },
  {
    "shot_id": "201",
    "scene": "Scene 5 - Hideout",
    "location": "hideout",
    "characters": "",
    "extras": "fade to city exterior",
    "camera": "environmental transition shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, exterior shot of quiet nighttime city skyline, transitions from warm underground hideout to cold sterile police headquarters"
  },
  {
    "shot_id": "202",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "",
    "extras": "police headquarters exterior",
    "camera": "wide exterior night shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, exterior of massive Leonida Police Headquarters at midnight, blue tinted glass facade, fleet of cruisers in parking lot, rain mist"
  },
  {
    "shot_id": "203",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "",
    "extras": "briefing room wide",
    "camera": "wide interior briefing shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police briefing room: long wooden conference table strewn with paper files and cold coffee mugs, wall-sized screens showing CCTV robbery footage"
  },
  {
    "shot_id": "204",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "chief",
    "extras": "Dunmore pacing room",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore pacing angrily in front of wall screens, uniform shirt rumpled, dark circles under eyes, gesturing at robbery freeze-frame"
  },
  {
    "shot_id": "205",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "",
    "extras": "CCTV freeze frame of Jason Lucia",
    "camera": "screen close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, high-resolution CCTV freeze-frame on digital wall screen showing Jason and Lucia inside jewelry store, faces circled with red digital tracking boxes"
  },
  {
    "shot_id": "206",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "hale",
    "extras": "Agent Hale standing calm",
    "camera": "medium portrait shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, FBI Agent Hale in sharp tailored black pantsuit, blonde hair pulled into slick ponytail, cold calm calculating eyes studying evidence board"
  },
  {
    "shot_id": "207",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "hale",
    "extras": "Hale pinning photos to corkboard",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Agent Hale pinning vintage black-and-white 1992 boardroom photo to corkboard, connecting it with red string to Mr. Marquise profile"
  },
  {
    "shot_id": "208",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "chief,hale",
    "extras": "Dunmore confronting Hale",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore leaning hands on table demanding answers about why six officers were injured over a single key, Hale responding with quiet authority"
  },
  {
    "shot_id": "209",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "hale",
    "extras": "explaining Black Crown",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Agent Hale speaking softly: explaining that the vault was under federal surveillance for years and the key unlocks international archives"
  },
  {
    "shot_id": "210",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "chief",
    "extras": "Chief ordering Most Wanted",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Chief Dunmore grabbing red rubber stamp, pressing it down hard onto file folder on table"
  },
  {
    "shot_id": "211",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "",
    "extras": "MOST WANTED stamp",
    "camera": "macro close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, macro shot of red ink bleeding across white case file header: 'PRIORITY ONE - STATE MOST WANTED - REWARD $250,000'"
  },
  {
    "shot_id": "212",
    "scene": "Scene 6 - Police HQ",
    "location": "hq",
    "characters": "cop",
    "extras": "detective printing wanted posters",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, police detective at laser printer collecting fresh glossy wanted posters showing Jason and Lucia sketches and $250,000 bounty banner"
  },
  {
    "shot_id": "213",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "owner",
    "extras": "Marquise alone in car",
    "camera": "medium exterior-in vehicle shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, outside in pouring rain, Mr. Marquise sitting alone in parked Mercedes sedan two blocks from police HQ, windshield streaked with rain"
  },
  {
    "shot_id": "214",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "owner",
    "extras": "trembling hands on steering wheel",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Mr. Marquise pale sweating face illuminated by glow of cheap black burner flip phone in his shaking hand, rain drumming on roof"
  },
  {
    "shot_id": "215",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "owner",
    "extras": "burner phone screen",
    "camera": "extreme macro shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, macro close-up of burner flip phone screen showing outgoing call to 'UNKNOWN CALLER', faint embossed crown watermark on phone case"
  },
  {
    "shot_id": "216",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "owner",
    "extras": "whispering into phone",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Mr. Marquise whispering in terrified urgent voice into phone: confessing that the Miami key has been stolen by two robbers"
  },
  {
    "shot_id": "217",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "",
    "extras": "mysterious caller penthouse",
    "camera": "wide architectural shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, luxurious dark penthouse apartment high above glittering city skyline, rain lashing floor-to-ceiling glass windows"
  },
  {
    "shot_id": "218",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "",
    "extras": "hooded figure in shadow",
    "camera": "medium silhouette shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, tall figure in dark tailored trenchcoat and hood standing with back to camera, holding sleek phone to ear, watching lightning flash over ocean"
  },
  {
    "shot_id": "219",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "",
    "extras": "distorted voice response",
    "camera": "close-up silhouette shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up silhouette of hooded figure jawline, cold metallic ring on finger, whispering single chilling command: 'Find them. Alive.'"
  },
  {
    "shot_id": "220",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "owner",
    "extras": "Marquise dropping phone",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Mr. Marquise slumping back against car seat as burner line goes dead, terror etched deep into every wrinkle of his face"
  },
  {
    "shot_id": "221",
    "scene": "Scene 6 - Police HQ",
    "location": "street",
    "characters": "",
    "extras": "rain on car roof",
    "camera": "cinematic transition shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, overhead shot of rain pouring over black sedan in dark street, distant city lights blurring into watery abstract bokeh"
  },
  {
    "shot_id": "222",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "tony,bucky,dre",
    "extras": "party in full swing",
    "camera": "wide interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, underground hideout filled with party energy: string fairy lights glowing, music playing, table piled with empty food cartons and soda cans"
  },
  {
    "shot_id": "223",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky standing on chair toast",
    "camera": "medium hero comedy shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky standing on wooden chair raising soda can high in air, bucket hat tilted at wild angle, shouting celebratory toast to Jason and Lucia"
  },
  {
    "shot_id": "224",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony cheering toast",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony clinking soda can against Dre cup, laughing loudly, black tactical shirt sleeves rolled up, enjoying the post-heist rush"
  },
  {
    "shot_id": "225",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "clinking cans",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia sitting close together on couch, clinking cold cans together with genuine smiles, feeling invincible"
  },
  {
    "shot_id": "226",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason",
    "extras": "reaching for metal tin",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason reaching onto coffee table, picking up dented metal tin and popping open the lid to show the crew"
  },
  {
    "shot_id": "227",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason",
    "extras": "placing key on table",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason taking out silver cracked-crown key and setting it down gently in center of table under bright incandescent desk lamp"
  },
  {
    "shot_id": "228",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "tony,bucky,dre",
    "extras": "crew crowding table",
    "camera": "medium group shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony, Bucky and Dre leaning in over table shoulder-to-shoulder, staring with curiosity and amusement at tiny ornate silver key"
  },
  {
    "shot_id": "229",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky mocking key",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky leaning down squinting with round sunglasses, jokingly saying it looks like an antique spoon with big ambitions"
  },
  {
    "shot_id": "230",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony inspecting key head",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony picking up key by its stem, rotating it between fingers: commenting that the cracked crown looks like pure trouble"
  },
  {
    "shot_id": "231",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia taking key from Tony",
    "camera": "close-up hands shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia taking silver key carefully from Tony fingers, holding it closer to the warm filament bulb of desk lamp"
  },
  {
    "shot_id": "232",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia squinting at side of key",
    "camera": "close-up portrait shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Lucia face, eyes narrowing with sharp analytical focus, noticing fine microscopic engraving along side of key blade"
  },
  {
    "shot_id": "233",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "",
    "extras": "macro key engraving 1/2",
    "camera": "extreme macro shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, extreme macro shot of silver key shaft: tiny worn serif engraving etched into tarnished metal reading '1/2' alongside a small crescent symbol"
  },
  {
    "shot_id": "234",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia announcing engraving",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia looking up from key, voice turning serious and quiet: 'Wait... there are tiny numbers carved on the side. One of two.'"
  },
  {
    "shot_id": "235",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "dre",
    "extras": "Dre turning down music",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre immediately reaching over to boombox and turning volume knob down to dead silence, room turning quiet and tense"
  },
  {
    "shot_id": "236",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony asking two what",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony lowering aviator glasses to nose bridge: 'One of two? Two what? Two vaults or two keys?'"
  },
  {
    "shot_id": "237",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason",
    "extras": "Jason realizing the truth",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason face turning solemn as realization hits: 'Two keys. Which means somewhere out there in the world... there is another key.'"
  },
  {
    "shot_id": "238",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky scratching head",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky scratching mustache under bucket hat, looking between Jason and Lucia with furrowed brow"
  },
  {
    "shot_id": "239",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "dre",
    "extras": "Dre leaning over map",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Dre walking over to wall map, eyes scanning international shipping lines marked with old red pins"
  },
  {
    "shot_id": "240",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia examining crescent mark",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia running fingertip along tiny crescent mark beside '1/2', wondering aloud what part of the world it belongs to"
  },
  {
    "shot_id": "241",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "silent realization",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia looking at each other across table, knowing they have stumbled into something far bigger than a county jewelry heist"
  },
  {
    "shot_id": "242",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony picking up bottle",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony taking slow sip from glass bottle, looking at key with newfound respect and caution"
  },
  {
    "shot_id": "243",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason",
    "extras": "locking key back in tin",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason placing key back on velvet pad in tin, closing latch firmly, placing tin in his inner jacket pocket next to his heart"
  },
  {
    "shot_id": "244",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "",
    "extras": "party winding down",
    "camera": "wide interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, atmosphere in hideout shifting from loud party to quiet thoughtful strategy, friends leaning back in sofas, string lights glowing softly"
  },
  {
    "shot_id": "245",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky falling asleep on chair",
    "camera": "medium comedy shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky snoring softly in armchair with bucket hat tilted over eyes, empty soda can resting on belly"
  },
  {
    "shot_id": "246",
    "scene": "Scene 7 - Party",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "standing up to leave room",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason quietly standing up, extending hand to Lucia, nodding toward upstairs exit hatch to get fresh air"
  },
  {
    "shot_id": "247",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "climbing roof ladder",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason pushing open rooftop access hatch of old laundromat building, helping Lucia climb out onto flat asphalt rooftop"
  },
  {
    "shot_id": "248",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "rooftop skyline view",
    "camera": "wide panoramic night shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia standing on laundromat rooftop edge, entire coastal city skyline glowing like sea of orange and purple embers in distance"
  },
  {
    "shot_id": "249",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "sitting on roof ledge",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia sitting side-by-side on low brick roof parapet, warm night ocean breeze gently rustling Lucia dark ponytail"
  },
  {
    "shot_id": "250",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "lucia",
    "extras": "Lucia resting head on shoulder",
    "camera": "close-up two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia resting head gently on Jason shoulder, looking out at distant glittering bridges, quiet vulnerable expression on her face"
  },
  {
    "shot_id": "251",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "lucia",
    "extras": "asking about future",
    "camera": "close-up portrait",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Lucia face in soft moonlight, dark eyes searching Jason: softly asking if he ever thinks they will get out of this criminal life"
  },
  {
    "shot_id": "252",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "jason",
    "extras": "Jason smiling softly",
    "camera": "close-up portrait",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Jason face, looking down at Lucia with warm sincere smile, cap off, speaking softly of a quiet house and a normal life"
  },
  {
    "shot_id": "253",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "lucia",
    "extras": "Lucia smiling at wedding mention",
    "camera": "close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia lips curling into genuine hopeful smile as Jason mentions a quiet wedding where nobody knows their names"
  },
  {
    "shot_id": "254",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "jason",
    "extras": "touching her cheek",
    "camera": "close-up tender shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason hand gently cupping Lucia cheek, thumb tracing her cheekbone, tender romantic intimacy under starlit sky"
  },
  {
    "shot_id": "255",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "jason,lucia",
    "extras": "rooftop kiss silhouette",
    "camera": "medium silhouette shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, beautiful cinematic silhouette of Jason and Lucia kissing on rooftop edge against backdrop of deep indigo and golden city lights"
  },
  {
    "shot_id": "256",
    "scene": "Scene 8 - Romance",
    "location": "street",
    "characters": "",
    "extras": "stars over coastal city",
    "camera": "wide environmental shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, wide peaceful view of night sky over ocean coast, shooting star streaking across upper horizon above distant city skyscrapers"
  },
  {
    "shot_id": "257",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "",
    "extras": "morning light in laundromat",
    "camera": "medium interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, morning: thin golden rays of dawn sunlight cutting through dusty basement transom window, motes of dust dancing in warm beam"
  },
  {
    "shot_id": "258",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "coffee mugs on table",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia sitting on leather couch in morning light, hair slightly messy, holding steaming ceramic mugs of coffee, relaxed"
  },
  {
    "shot_id": "259",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "",
    "extras": "CRT TV humming on",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, old CRT television on corner shelf flickering on, morning news broadcast graphic opening with bold red 'BREAKING NEWS' banner"
  },
  {
    "shot_id": "260",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "",
    "extras": "TV screen with Jason Lucia sketch",
    "camera": "close-up TV screen shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, CCTV freeze-frames of Jason and Lucia displayed on television screen beside bold bold graphic: 'MOST WANTED DUO - $250,000 REWARD'"
  },
  {
    "shot_id": "261",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia reacting to reward",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia covering mouth in half-shocked half-amused disbelief, looking at television screen: 'A quarter million dollars... we are famous!'"
  },
  {
    "shot_id": "262",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "jason",
    "extras": "Jason smirking with coffee mug",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason leaning back on sofa with wry smirk, raising coffee mug toward screen in mock salute: 'We made it, babe. We made it.'"
  },
  {
    "shot_id": "263",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "tony,bucky,dre",
    "extras": "crew waking up",
    "camera": "wide shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony stretching on folding cot, Bucky waking up rubbing eyes, and Dre pouring coffee, all three turning heads toward television in disbelief"
  },
  {
    "shot_id": "264",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "bucky",
    "extras": "Bucky pointing at TV",
    "camera": "medium comedy shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Bucky pointing spoon at television screen shouting that his burger cost more than the robbery but the reward is insane"
  },
  {
    "shot_id": "265",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "tony",
    "extras": "Tony shaking head at bounty",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony shaking head with impressed whistle: '$250,000... every bounty hunter from Miami to Liberty City is going to hunt this room.'"
  },
  {
    "shot_id": "266",
    "scene": "Scene 9 - Morning News",
    "location": "hideout",
    "characters": "jason",
    "extras": "Jason expression turning serious",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason smile fading into serious tactical calculation, setting coffee mug down, realizing the entire state law enforcement is active"
  },
  {
    "shot_id": "267",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "",
    "extras": "dead silence in room",
    "camera": "wide interior shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, total dead silence falling over underground hideout, TV muted, all five crew members freezing in place"
  },
  {
    "shot_id": "268",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "",
    "extras": "heavy steel gate knocks",
    "camera": "low-angle exterior gate shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, heavy reinforced steel alley gate at top of basement stairs, morning sunlight leaking through cracks, three slow heavy knocks vibrating steel"
  },
  {
    "shot_id": "269",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia drawing pistol",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia instantly setting coffee mug down without a sound, drawing black pistol from holster, eyes locked on basement staircase"
  },
  {
    "shot_id": "270",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "jason",
    "extras": "Jason signaling crew",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason holding up flat palm to crew, signaling Tony and Bucky to take cover behind wooden ammo crates while he approaches stairs"
  },
  {
    "shot_id": "271",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "tony,bucky,dre",
    "extras": "taking tactical cover",
    "camera": "medium group shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Tony, Bucky and Dre silently ducking behind heavy equipment crates, cocking rifles with muted mechanical clicks"
  },
  {
    "shot_id": "272",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "",
    "extras": "security monitor grainy figure",
    "camera": "close-up monitor shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, grainy black-and-white CRT security monitor on wall showing rear camera view: a tall broad-shouldered man in brown bomber jacket standing alone at gate"
  },
  {
    "shot_id": "273",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia calling out who is it",
    "camera": "medium shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia standing at bottom of stairs aiming pistol upward with steady two-handed grip, calling out firm challenge: 'Who is it?'"
  },
  {
    "shot_id": "274",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "",
    "extras": "shadow at top of stairs",
    "camera": "low-angle staircase shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, top of wooden stairs outside gate, deep calm gravelly Eastern European accented voice echoing down: 'Just a man. Alone. I have business with Jason and Lucia.'"
  },
  {
    "shot_id": "275",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "exchanging tense glance",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia exchanging sharp questioning look: Jason whispering to Lucia to cover him while he unlocks the gate"
  },
  {
    "shot_id": "276",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "jason",
    "extras": "unlocking heavy bolt",
    "camera": "close-up gate shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason gloved hand sliding heavy steel gate bolt back with sharp metallic clack, hinges groaning as gate swings slowly inward"
  },
  {
    "shot_id": "277",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "niko",
    "extras": "tall silhouette in morning sun",
    "camera": "wide backlit silhouette shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, open doorway flooded with bright morning sunlight, casting tall broad-shouldered silhouette of mysterious stranger across wooden steps"
  },
  {
    "shot_id": "278",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "lucia",
    "extras": "Lucia studying stranger",
    "camera": "medium close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Lucia lowering pistol slightly, squinting against bright morning glare, studying the rugged weathered posture of the lone visitor"
  },
  {
    "shot_id": "279",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "niko",
    "extras": "Niko stepping out of shadow",
    "camera": "medium hero shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Niko Bellic stepping forward into basement light: rugged Eastern European face in his 40s, short brown hair, brown leather bomber jacket with tan sheepskin collar"
  },
  {
    "shot_id": "280",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "niko",
    "extras": "close-up on Niko tired eyes",
    "camera": "intense cinematic close-up shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, intense cinematic close-up of Niko Bellic face: stern tired eyes that have seen too many wars, faint scar across left brow, short dark stubble, calm grim expression"
  },
  {
    "shot_id": "281",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "niko",
    "extras": "introducing himself",
    "camera": "medium close-up hero shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Niko Bellic standing tall in open gate doorway, hands resting calmly in bomber jacket pockets, speaking with slow iconic heavy Slavic accent: 'Hello. My name is Niko Bellic.'"
  },
  {
    "shot_id": "282",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "jason,lucia",
    "extras": "stunned reaction",
    "camera": "medium two-shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, Jason and Lucia frozen in absolute shock, guns half-lowered, staring in disbelief at the legendary Liberty City veteran standing in their hideout"
  },
  {
    "shot_id": "283",
    "scene": "Scene 10 - Niko Reveal",
    "location": "hideout",
    "characters": "niko",
    "extras": "pulling on fingerless gloves",
    "camera": "close-up final hero shot",
    "prompt": "photorealistic cinematic video-game render, GTA 6 style, natural muted color grading, realistic lighting, candid natural body language, 16:9 widescreen, sharp focus, no text overlay, no watermark, close-up of Niko Bellic hands methodically pulling on black fingerless tactical gloves, slow smirk appearing, morning light catching his jacket"
  }
];
